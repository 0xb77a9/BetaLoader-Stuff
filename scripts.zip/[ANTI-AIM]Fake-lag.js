/***************************************************************************/
var _$_655b = ["Anti-Aim", "Fake-Lag", "Limit", "GetValue", "Jitter", "Trigger limit", "GetScreenSize", "Realtime", "limit min", "AddSliderInt", "limit max", "jitter min", "jitter max", "tigger limit min", "tigger limit max", "cycle", "AddSliderFloat", "Misc", "JAVASCRIPT", "Script items", "random", "floor", "SetValue", " ", "String", "ANTI-L M", "-", "Draw", "main", "RegisterCallback"];
var limit = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[2]);
var jitter = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[4]);
var tlimit = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[5]);
var nlimit = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[2]);
var njitter = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[4]);
var ntlimit = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[5]);
var screen_size = Global[_$_655b[6]]();
var lasttime = Global[_$_655b[7]]();
var realtime = Global[_$_655b[7]]();
var r = 255;
var g = 255;
var b = 255;
var r1 = 255;
var g1 = 255;
var b1 = 255 ;

function render_arc(x, y, radius, radius_inner, start_angle, end_angle, segments, color)
    {
        while(360 % segments != 0)
        {
            segments++;
        }

        segments = 360 / segments;

        for (var i = start_angle; i < start_angle + end_angle; i = i + segments)
        {

            var rad = i * Math.PI / 180;
            var rad2 = (i + segments) * Math.PI / 180;

            var rad_cos = Math.cos(rad)
            var rad_sin = Math.sin(rad)

            var rad2_cos = Math.cos(rad2);
            var rad2_sin = Math.sin(rad2);

            var x1_outer = x + rad_cos * radius;
            var y1_outer = y + rad_sin * radius;

            var x2_outer = x + rad2_cos * radius;
            var y2_outer = y + rad2_sin * radius;

            var x1_inner = x + rad_cos * radius_inner;
            var y1_inner = y + rad_sin * radius_inner;

            var x2_inner = x + rad2_cos * radius_inner;
            var y2_inner = y + rad2_sin * radius_inner;

            Render.Polygon( [
                [ x1_outer, y1_outer ],
                [ x2_outer, y2_outer ],
                [ x1_inner, y1_inner ] ],
                color
            );

            Render.Polygon( [
                [ x1_inner, y1_inner ],
                [ x2_outer, y2_outer ],
                [ x2_inner, y2_inner ] ],
                color
            );
        }
    }

function addtomenu() {
    UI[_$_655b[9]](_$_655b[8], 0, 14);
    UI[_$_655b[9]](_$_655b[10], 0, 14);
    UI[_$_655b[9]](_$_655b[11], 0, 100);
    UI[_$_655b[9]](_$_655b[12], 0, 100);
    UI[_$_655b[9]](_$_655b[13], 0, 14);
    UI[_$_655b[9]](_$_655b[14], 0, 14);
    UI[_$_655b[16]](_$_655b[15], 0, 5)
}

function SFAKE() {
    var _0x1BE0B = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[8]);
    var _0x1BDE5 = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[10]);
    var _0x1BE31 = _0x1BE0B + Math[_$_655b[21]](Math[_$_655b[20]]() * (_0x1BDE5 - _0x1BE0B + 1));
    UI[_$_655b[22]](_$_655b[0], _$_655b[1], _$_655b[2], _0x1BE31);
    var _0x1BE0B = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[11]);
    var _0x1BDE5 = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[12]);
    var _0x1BE31 = _0x1BE0B + Math[_$_655b[21]](Math[_$_655b[20]]() * (_0x1BDE5 - _0x1BE0B + 1));
    UI[_$_655b[22]](_$_655b[0], _$_655b[1], _$_655b[4], _0x1BE31);
    var _0x1BE0B = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[13]);
    var _0x1BDE5 = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[14]);
    var _0x1BE31 = _0x1BE0B + Math[_$_655b[21]](Math[_$_655b[20]]() * (_0x1BDE5 - _0x1BE0B + 1));
    UI[_$_655b[22]](_$_655b[0], _$_655b[1], _$_655b[5], _0x1BE31)
}

function check() {
    var _0x1BE0B = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[8]);
    var _0x1BDE5 = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[10]);
    if (_0x1BE0B > _0x1BDE5) {
        UI[_$_655b[22]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[8], _0x1BDE5)
    };
    var _0x1BE0B = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[11]);
    var _0x1BDE5 = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[12]);
    if (_0x1BE0B > _0x1BDE5) {
        UI[_$_655b[22]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[11], _0x1BDE5)
    };
    var _0x1BE0B = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[13]);
    var _0x1BDE5 = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[14]);
    if (_0x1BE0B > _0x1BDE5) {
        UI[_$_655b[22]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[13], _0x1BDE5)
    }
}
var screen_size = Render.GetScreenSize( );
function main() {
    check();
	limit = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[2]);
    jitter = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[4]);
    tlimit = UI[_$_655b[3]](_$_655b[0], _$_655b[1], _$_655b[5]);
	max_angle = 25.715*limit;
	Center = Render.GetScreenSize();
	CenterX = Center[0] / 2
	CenterY = Center[1] / 2
	var difference = Math.abs( Local.GetRealYaw( ) - Local.GetFakeYaw( ) );
	Render.String( 6, screen_size[1] - 344, 0,"   "+"FL: "+limit+" - "+jitter+" - "+tlimit.toString(), [0, 0, 0, 255], 4);
	Render.String( 5, screen_size[1] - 345, 0,"   "+"FL: "+limit+" - "+jitter+" - "+tlimit.toString(), [255, 255, 255, 255], 4);
	de = UI[_$_655b[3]](_$_655b[17], _$_655b[18], _$_655b[19], _$_655b[15]);
    r = 255;
    g = 255;
    b = 255;
    if (r == 1) {
        r1 = -r1
    };
    if (g == 1) {
        g1 = -g1
    };
    if (b == 1) {
        b1 = -b1
    };
    if (r == 255) {
        r1 = -r1
    };
    if (g == 255) {
        g1 = -g1
    };
    if (b == 255) {
        b1 = -b1
    };
    realtime = Global[_$_655b[7]]();
    if (realtime - lasttime >= de) {
        SFAKE();
        lasttime = realtime
    };
    if (realtime < lasttime) {
        lasttime = Global[_$_655b[7]]();
        realtime = Global[_$_655b[7]]()
    }
}
addtomenu();
Cheat[_$_655b[29]](_$_655b[27], _$_655b[28])