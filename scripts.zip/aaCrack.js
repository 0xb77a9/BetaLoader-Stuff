var isInverted, screen_size = Global.GetScreenSize(),
  drawDangerous = 1,
  fakelag_cache = UI.GetValue("Anti-Aim", "Fake-Lag", "Limit"),
  jitter_cache = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset"),
  yaw_cashe = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset");
UI.AddLabel("       \x63\x72\x61\x63\x6b\x65\x64\x20\x62\x79\x20\x78\x38\x36\x23\x30\x30\x38\x36\x20\x6c\x6f\x6c        "), UI.AddCheckbox("Enable"), UI.AddCheckbox("Autowall fix");
const autowall_modes = UI.AddMultiDropdown("Futures", ["Early when holding mindmg"]),
  early_weapons = UI.AddMultiDropdown("Early weapons", ["Auto", "Scout", "Awp", "Pistol", "Heavy pistol"]);
UI.AddCheckbox("Open note"), UI.AddLabel("Early autostop makes you stop at"), UI.AddLabel("first pixel of player model"), UI.AddCheckbox("Indicators"), UI.AddDropdown("Select indicators type", ["Default", "Skeet styled"]), UI.AddColorPicker("Choose color");
const skeetstyled_modes = UI.AddMultiDropdown("Futures ", ["Hotkeys list", "Spectator list"]),
  keybinds_x = UI.AddSliderInt("keybinds_x", 0, Global.GetScreenSize()[0]),
  keybinds_y = UI.AddSliderInt("keybinds_y", 0, Global.GetScreenSize()[1]),
  keybinds_xx = UI.AddSliderInt("keybinds_xx", 0, Global.GetScreenSize()[0]),
  keybinds_yy = UI.AddSliderInt("keybinds_yy", 0, Global.GetScreenSize()[1]);
UI.AddCheckbox("DT speed boost"), UI.AddDropdown("DT type", ["Offensive", "Deffensive"]), UI.AddCheckbox("Better onshot (scout/awp) [beta]"), UI.AddSliderInt("Fake-lag limit", 0, 4), UI.AddLabel("Better onshot works well only"), UI.AddLabel("with quick peek"), UI.AddHotkey("Pingspike on key"), UI.AddLabel("                    "), UI.AddLabel("          Minimum dmg on key            "), UI.AddCheckbox("Enable  "), UI.AddCheckbox("Show currently mindamage"), UI.AddHotkey("Minimum Damage Override"), UI.AddSliderInt("Pistol Mindmg", 0, 130), UI.AddSliderInt("Heavy Pistol Mindmg", 0, 130), UI.AddSliderInt("Scout Mindmg", 0, 130), UI.AddSliderInt("AWP Mindmg", 0, 130), UI.AddSliderInt("Auto Mindmg", 0, 130), UI.AddLabel("_______________________________________ "), UI.AddSliderInt("Pistol Mindmg [on key]", 0, 130), UI.AddSliderInt("Heavy Pistol Mindmg [on key]", 0, 130), UI.AddSliderInt("Scout Mindmg [on key]", 0, 130), UI.AddSliderInt("AWP Mindmg [on key]", 0, 130), UI.AddSliderInt("Auto Mindmg [on key]", 0, 130), UI.AddLabel("                    "), UI.AddLabel("                 Anti-Aim            "), UI.AddCheckbox("Enable Anti-Aim"), UI.AddHotkey("Freestand fake on key"), UI.AddDropdown("Freestanding type", ["Safe head", "Peek out"]), UI.AddHotkey("Sync fake on key"), UI.AddHotkey("Reset fake on key"), UI.AddHotkey("Freestand on Key"), UI.AddHotkey("Legit AA on Key"), UI.AddCheckbox("Trigger jitter when unsafe"), UI.AddCheckbox("Safe head"), UI.AddDropdown("Safe head type", ["Adaptive", "Custom", "On key"]);
const safehead_modes = UI.AddMultiDropdown("Safe head modes", ["Slow walk", "Low HP", "Standing"]);
UI.AddHotkey("Safe head on key"), UI.AddLabel("                    "), UI.AddLabel("               Magic key            "), UI.AddCheckbox("Enable magic key"), UI.AddHotkey("Magic key bind"), UI.AddDropdown("Magic key type", ["Max dmg", "Force head"]), UI.AddCheckbox("Use custom head scale for magic key"), UI.AddDropdown("Select weapon ", ["Auto", "Scout", "AWP", "Pistol", "Heavy pistol"]), UI.AddSliderInt("Set value", 1, 100), UI.AddSliderInt("Set value ", 1, 100), UI.AddSliderInt("Set value  ", 1, 100), UI.AddSliderInt("Set value   ", 1, 100), UI.AddSliderInt("Set value    ", 1, 100), UI.AddLabel("                    "), UI.AddLabel("               Safe point            "), UI.AddCheckbox("Enable   "), UI.AddCheckbox("Prefer safe point on limbs"), UI.AddLabel("                    "), UI.AddLabel("       shoppy.gg/@Kitty1337             ");
var heavy_body_multipoint_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Heavy pistol config", "Body pointscale"),
  scout_body_multipoint_cache = UI.GetValue("Rage", "SCOUT", "Scout config", "Body pointscale"),
  awp_body_multipoint_cache = UI.GetValue("Rage", "AUTOSNIPER", "Auto config", "Body pointscale"),
  auto_body_multipoint_cache = UI.GetValue("Rage", "AWP", "AWP config", "Body pointscale"),
  pistol_body_multipoint_cache = UI.GetValue("Rage", "PISTOL", "Pistol config", "Body pointscale");

function HSVtoRGB(e, t, i) {
  var a, s, n, c, o, r, l, u;
  switch (r = i * (1 - t), l = i * (1 - (o = 6 * e - (c = Math.floor(6 * e))) * t), u = i * (1 - (1 - o) * t), c % 6) {
    case 0:
      a = i, s = u, n = r;
      break;
    case 1:
      a = l, s = i, n = r;
      break;
    case 2:
      a = r, s = i, n = u;
      break;
    case 3:
      a = r, s = l, n = i;
      break;
    case 4:
      a = u, s = r, n = i;
      break;
    case 5:
      a = i, s = r, n = l
  }
  var p = {};
  return p.r = Math.round(255 * a), p.g = Math.round(255 * s), p.b = Math.round(255 * n), p
}

function get_velocity(e) {
  var t = Entity.GetProp(e, "CBasePlayer", "m_vecVelocity[0]");
  return Math.sqrt(t[0] * t[0] + t[1] * t[1])
}
const is_jumping = function (e) {
  return Entity.GetProp(e, "CBasePlayer", "m_hGroundEntity")
};

function get_health(e) {
  return health_override = Entity.GetProp(e, "CBasePlayer", "m_iHealth"), health_override
}

function SetEnabled() {
  var e = new Array;
  Array.prototype.indexOf = function () {
    return !0
  };
  const t = UI.GetValue.apply(null, autowall_modes); - 1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Futures ", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Futures ", 0), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Open note", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Futures", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Open note", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Futures", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") && 1 & t ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Early weapons", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Early weapons", 0), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Open note") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Early autostop makes you stop at", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "first pixel of player model", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Early autostop makes you stop at", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "first pixel of player model", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Better onshot (scout/awp) [beta]") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Better onshot works well only", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "with quick peek", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Fake-lag limit", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Better onshot works well only", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "with quick peek", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Fake-lag limit", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Select indicators type", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Select indicators type", 0), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Choose color", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Choose color", 0), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Freestanding type", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Sync fake on key", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Reset fake on key", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Freestand on Key", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Trigger jitter when unsafe", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Freestanding type", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Sync fake on key", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Reset fake on key", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Freestand on Key", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Trigger jitter when unsafe", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Autowall fix", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Indicators", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "DT speed boost", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Better onshot (scout/awp) [beta]", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pingspike on key", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "DT type", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Autowall fix", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Indicators", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "DT speed boost", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Better onshot (scout/awp) [beta]", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pingspike on key", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Better onshot works well only", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "with quick peek", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "DT type", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable  ") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Show currently mindamage", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "_______________________________________ ", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pistol Mindmg", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Heavy Pistol Mindmg", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Scout Mindmg", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "AWP Mindmg", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Auto Mindmg", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pistol Mindmg [on key]", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Heavy Pistol Mindmg [on key]", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Scout Mindmg [on key]", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "AWP Mindmg [on key]", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Auto Mindmg [on key]", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Show currently mindamage", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "_______________________________________ ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pistol Mindmg", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Heavy Pistol Mindmg", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Scout Mindmg", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "AWP Mindmg", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Auto Mindmg", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pistol Mindmg [on key]", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Heavy Pistol Mindmg [on key]", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Scout Mindmg [on key]", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "AWP Mindmg [on key]", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Auto Mindmg [on key]", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable   ") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Prefer safe point on limbs", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Prefer safe point on limbs", 0), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head type", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head type", 0), -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head type") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head modes", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head on key", 0)) : -1 == e.indexOf(Cheat.GetUsername()) && 2 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head type") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head modes", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head on key", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head modes", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Safe head on key", 0)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Magic key bind", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Magic key type", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Magic key bind", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Magic key type", 0)), -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key", 0), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Select weapon ", 1) : UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Select weapon ", 0), -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select weapon ") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value  ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value   ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value    ", 0)) : -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select weapon ") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value ", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value  ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value   ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value    ", 0)) : -1 == e.indexOf(Cheat.GetUsername()) && 2 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select weapon ") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value  ", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value   ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value    ", 0)) : -1 == e.indexOf(Cheat.GetUsername()) && 3 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select weapon ") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value  ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value   ", 1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value    ", 0)) : -1 == e.indexOf(Cheat.GetUsername()) && 4 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select weapon ") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value  ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value   ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value    ", 1)) : (UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value  ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value   ", 0), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Set value    ", 0))
}

function LegitAA() {
  var e = new Array;
   UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") ? (UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Restrictions", 0), UI.SetValue("Anti-Aim", "Extra", "Pitch", 0), UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 180)) : (UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Restrictions", 1), UI.SetValue("Anti-Aim", "Extra", "Pitch", 1), UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", yaw_cashe))
}

function PingSpike() {
  var e = new Array;
   -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Pingspike on key") && localplayer_alive ? (UI.SetValue("Misc", "GENERAL", "Miscellaneous", "Extended backtracking", 1), isPing = !0) : (UI.SetValue("Misc", "GENERAL", "Miscellaneous", "Extended backtracking", 0), isPing = !1)
}

function isActive(e) {
  return UI.IsHotkeyActive("Script items", e)
}

function setValue(e, t) {
  UI.SetValue("Rage", e.toUpperCase(), "Targeting", "Minimum damage", t)
}

function isHeavyPistol(e) {
  if ("r8 revolver" == e || "desert eagle" == e) return !0
}

function isPistol(e) {
  if ("glock 18" == e || "five seven" == e || "dual berettas" == e || "p250" == e || "tec 9" == e || "usp s" == e || "cz75 auto" == e || "p2000" == e) return !0
}

function isAutoSniper(e) {
  if ("scar 20" == e || "g3sg1" == weapon_name) return !0
}

function BetterOnshot() {
  weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), BO_weapons = !1, DT_weapons = !1;
  var e = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Fake-lag limit");
  "ssg 08" == weapon_name || "awp" == weapon_name ? BO_weapons = !0 : BO_weapons = !1, isAutoSniper(weapon_name) || isPistol(weapon_name) ? DT_weapons = !0 : DT_weapons = !1, UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Better onshot (scout/awp) [beta]") && 1 == BO_weapons && UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap") ? UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", e) : (DT_weapons = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "DT type") && UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap") && UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap")) ? UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", 14) : (DT_weapons = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "DT type") && UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap") && UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap")) ? UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", 0) : UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", fakelag_cache)
}

function onCM() {
  var e = new Array;
  pistol_value = UI.GetValue("Script items", "Pistol Mindmg [on key]"), heavy_value = UI.GetValue("Script items", "Heavy Pistol Mindmg [on key]"), scout_value = UI.GetValue("Script items", "Scout Mindmg [on key]"), awp_value = UI.GetValue("Script items", "AWP Mindmg [on key]"), auto_value = UI.GetValue("Script items", "Auto Mindmg [on key]");
  var t = UI.GetValue("Script items", "Heavy Pistol Mindmg"),
    i = UI.GetValue("Script items", "Pistol Mindmg"),
    a = UI.GetValue("Script items", "Scout Mindmg"),
    s = UI.GetValue("Script items", "AWP Mindmg"),
    n = UI.GetValue("Script items", "Auto Mindmg");
  weapon_name = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), -1 == e.indexOf(Cheat.GetUsername()) && isActive("Minimum Damage Override") && isPistol(weapon_name) ? setValue("PISTOL", pistol_value) : -1 == e.indexOf(Cheat.GetUsername()) && isActive("Magic key bind") && isPistol(weapon_name) && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (setValue("PISTOL", 100), UI.SetValue("Rage", "HEAVY PISTOL", "Accuracy", "Prefer body aim", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isMagicKey = !0, isDoubletap = !1) : setValue("PISTOL", i), -1 == e.indexOf(Cheat.GetUsername()) && isActive("Minimum Damage Override") && isHeavyPistol(weapon_name) ? setValue("HEAVY PISTOL", heavy_value) : -1 == e.indexOf(Cheat.GetUsername()) && isActive("Magic key bind") && isHeavyPistol(weapon_name) && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (setValue("HEAVY PISTOL", 100), UI.SetValue("Rage", "HEAVY PISTOL", "Accuracy", "Prefer body aim", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isMagicKey = !0, isDoubletap = !1) : setValue("HEAVY PISTOL", t), -1 == e.indexOf(Cheat.GetUsername()) && isActive("Minimum Damage Override") && "ssg 08" == weapon_name ? setValue("SCOUT", scout_value) : -1 == e.indexOf(Cheat.GetUsername()) && isActive("Magic key bind") && "ssg 08" == weapon_name && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (setValue("SCOUT", 100), UI.SetValue("Rage", "SCOUT", "Accuracy", "Prefer body aim", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isMagicKey = !0, isDoubletap = !1) : setValue("SCOUT", a), -1 == e.indexOf(Cheat.GetUsername()) && isActive("Minimum Damage Override") && "awp" == weapon_name ? setValue("AWP", awp_value) : -1 == e.indexOf(Cheat.GetUsername()) && isActive("Magic key bind") && "awp" == weapon_name && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (setValue("AWP", 100), UI.SetValue("Rage", "AWP", "Accuracy", "Prefer body aim", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isMagicKey = !0, isDoubletap = !1) : setValue("AWP", s), -1 == e.indexOf(Cheat.GetUsername()) && isActive("Minimum Damage Override") && isAutoSniper(weapon_name) ? setValue("AUTOSNIPER", auto_value) : -1 == e.indexOf(Cheat.GetUsername()) && isActive("Magic key bind") && isAutoSniper(weapon_name) && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") ? (setValue("AUTOSNIPER", 100), UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Prefer body aim", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isMagicKey = !0, isDoubletap = !1) : setValue("AUTOSNIPER", n)
}

function indicator() {
  var e = new Array;
  screen = Render.GetScreenSize();
  const t = render_get_screen_size()[1];
  wep = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())), pistol = UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage"), heavy = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage"), scout = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage"), awp = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage"), auto = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage"), font = Render.AddFont("Verdana", 18, 700), render_get_screen_size = Render.GetScreenSize;
  var i = ""; - 1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable  ") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Show currently mindamage") && Entity.IsValid(Entity.GetLocalPlayer()) && Entity.IsAlive(Entity.GetLocalPlayer()) && (isPistol(wep) ? i = pistol : isHeavyPistol(wep) ? i = heavy : "ssg 08" == wep ? i = scout : "awp" == wep ? i = awp : isAutoSniper(wep) ? i = auto : (Render.StringCustom(18, t - 312, 0, "0", [0, 0, 0, 255], font), Render.StringCustom(17, t - 312, 0, "0", [255, 255, 255, 255], font))), Render.StringCustom(18, t - 312, 0, i + "", [0, 0, 0, 255], font), Render.StringCustom(17, t - 312, 0, i + "", [255, 255, 255, 255], font)
}

function Safe_Head() {
  var e = new Array;
  g_Local = Entity.GetLocalPlayer(), g_Local_weapon = Entity.GetWeapon(g_Local), weapon_name = Entity.GetName(g_Local_weapon), g_Local_classname = Entity.GetClassName(g_Local_weapon), localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index);
  const t = UI.GetValue.apply(null, safehead_modes);
  var i = get_velocity(localplayer_index),
    a = get_health(localplayer_index),
    s = !1,
    n = !1,
    c = !1; - 1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head type") ? (n = !!UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk"), s = a < 50, c = i < 3) : -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head type") ? (n = !!(1 & t && UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk")), s = !!(2 & t && a < 50), c = !!(4 & t && i < 3)) : -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && 2 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head type") && (n = !!UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key")), 1 == c || 1 == s || 1 == n && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && -1 == e.indexOf(Cheat.GetUsername()) ? (UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 10), UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", 0), AntiAim.SetOverride(1), AntiAim.SetFakeOffset(0), AntiAim.SetRealOffset(-20)) : (UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", 0), AntiAim.SetOverride(0))
}

function JitterUnsafe() {
  var e = new Array;
  g_Local = Entity.GetLocalPlayer(), g_Local_weapon = Entity.GetWeapon(g_Local), weapon_name = Entity.GetName(g_Local_weapon), g_Local_classname = Entity.GetClassName(g_Local_weapon), localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index);
  var t = get_velocity(localplayer_index),
    i = (get_health(localplayer_index), !1); - 1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Trigger jitter when unsafe") && (i = t < 150), 1 == i && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && -1 == e.indexOf(Cheat.GetUsername()) ? UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", 20) : UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Jitter offset", jitter_cache)
}

function drawString() {
  var e = new Array;
   isDoubletap = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap"), isInverted = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter"), isHideReal = UI.GetValue("Anti-Aim", "Fake angles", "Hide real angle"), isHideShots = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Hide shots"), isMagicKey = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Magic key bind"), isFreestand = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand on Key"), isFakeDuck = UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck"), isIndicators = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators"), isSyncFake = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Sync fake on key"), isResetFake = UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Reset fake on key"), isIndFb = UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim"), isIndSp = UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point"), isIndLag = UI.GetValue("Anti-Aim", "Fake-Lag", "Enabled"), isIndAwall_auto = 0 == UI.GetValue("Rage", "AUTOSNIPER", "Auto config", "Disable autowall"), isPing = UI.GetValue("Misc", "GENERAL", "Miscellaneous", "Extended backtracking"), render_get_screen_size = Render.GetScreenSize, -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Hide shots") ? (UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Hide shots", !0), UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Prefer body aim", !1), isDoubletap = !1, isHideShots = !0, isIndLag = !1) : -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") ? (UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !0), UI.SetValue("Rage", "GENERAL", "Exploits", "Hide shots", !1), UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Prefer body aim", !0), isDoubletap = !0, isHideShots = !1, isIndLag = !1) : UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Prefer body aim", !1), g_Local = Entity.GetLocalPlayer(), g_Local_weapon = Entity.GetWeapon(g_Local), weapon_name = Entity.GetName(g_Local_weapon), g_Local_classname = Entity.GetClassName(g_Local_weapon), localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index), -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Hide shots") ? (UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isDoubletap = !1) : -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand on Key") ? (UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", !0), isFreestand = !0) : (UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", !1), isFreestand = !1), -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck") && 1 == localplayer_alive && (UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), UI.SetValue("Rage", "GENERAL", "Exploits", "Hide shots", !1), isDoubletap = !1, isHideShots = !1), -1 == e.indexOf(Cheat.GetUsername()) && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Magic key bind") && 1 == localplayer_alive && (UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap", !1), isDoubletap = !1), -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && (isIndicators = !0);
  const t = render_get_screen_size()[1],
    i = Render.AddFont("Verdana", 8, 100);
  font = Render.AddFont("Verdana", 18, 700), fontmagickey = Render.AddFont("Verdana", 10, 700), -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && 1 == localplayer_alive && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") && (Render.StringCustom(12, t - 342, 0, "fb", [0, 0, 0, 255], font), Render.StringCustom(75, t - 314, 0, "sp", [0, 0, 0, 255], font), Render.StringCustom(64, t - 342, 0, "lag", [0, 0, 0, 255], font), Render.StringCustom(11, t - 342, 0, (isIndFb, "fb"), isIndFb ? [150, 212, 15, 255] : [255, 0, 0, 255], font), Render.StringCustom(74, t - 314, 0, (isIndSp, "sp"), isIndSp ? [150, 212, 15, 255] : [255, 0, 0, 255], font), Render.StringCustom(63, t - 342, 0, (isIndLag, "lag"), isIndLag ? [150, 212, 15, 255] : [255, 0, 0, 255], font)), -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 1 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key") ? Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 25, 1, "IDEAL YAW", [255, 135, 35, 255], i) : -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key") ? Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 25, 1, "FAKE YAW", [207, 177, 255, 255], i) : -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 1 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head") && 2 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Safe head type") ? Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 25, 1, "DANGEROUS", [255, 0, 0, 255], i) : -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key") && 1 == localplayer_alive && Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 25, 1, "LEGIT AA", [207, 177, 255, 255], i), -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 1 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Sync fake on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive ? (UI.SetValue("Anti-Aim", "Rage Anti-Aim", "At targets", 1), isSyncFake = !0, Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 38, 1, "DYNAMIC", [207, 177, 255, 255], i)) : -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Sync fake on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && (Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 38, 1, "DEFAULT", [255, 0, 0, 255], i), UI.SetValue("Anti-Aim", "Rage Anti-Aim", "At targets", 0)), -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 1 == isInverted && 1 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key") ? (Render.StringCustom(screen_size[0] / 2 - 55, screen_size[1] / 2 - 20, 1, "<", [255, 255, 255, 255], 13), Render.StringCustom(screen_size[0] / 2 + 55, screen_size[1] / 2 - 20, 1, ">", [255, 135, 35, 255], 13)) : -1 == e.indexOf(Cheat.GetUsername()) && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && 0 == isInverted && 1 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 == localplayer_alive && 0 == UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Safe head on key") && (Render.StringCustom(screen_size[0] / 2 - 55, screen_size[1] / 2 - 20, 1, "<", [255, 135, 35, 255], 13), Render.StringCustom(screen_size[0] / 2 + 55, screen_size[1] / 2 - 20, 1, ">", [255, 255, 255, 255], 13)), -1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && 0 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") && 1 == localplayer_alive && (Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 51, 1, (isDoubletap, "DT"), isDoubletap ? [65, 105, 225, 255] : [255, 0, 0, 0], i), Render.StringCustom(screen_size[0] / 2, screen_size[1] / 2 + 51, 1, (isHideShots, "AA"), isHideShots ? [65, 105, 225, 255] : [255, 0, 0, 0], i), Render.StringCustom(880, t - 799, 0, (isMagicKey, "WARNING!"), isMagicKey ? [255, 0, 0, 255] : [255, 0, 0, 0], fontmagickey), Render.StringCustom(965, t - 800, 0, (isMagicKey, "delay shot"), isMagicKey ? [110, 200, 15, 255] : [0, 204, 0, 0], fontmagickey), Render.StringCustom(screen_size[0] / 2 - 893, screen_size[1] / 2 + 450, 1, (isFreestand, "Freestand"), isFreestand ? [255, 255, 255, 255] : [0, 204, 0, 0], 4))
}
var olDoubleTapick = 0,
  lastPressed = 0;

function player_connect() {
  var e = Event.GetInt("userid");
  Entity.GetEntityFromUserID(e) == Entity.GetLocalPlayer() && (lastPressed = Global.Tickcount(), olDoubleTapick = Global.Tickcount())
}
var _0x4a1dfa = {
    get: function () {
      return UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")
    },
    reverse: function () {
      return UI.ToggleHotkey("Anti-Aim", "Fake angles", "Inverter")
    }
  },
  inverter = _0x4a1dfa;

function deg2rad(e) {
  return e * Math.PI / 180
}

function angle_to_vec(e, t) {
  var i = deg2rad(e),
    a = deg2rad(t),
    s = Math.sin(i),
    n = Math.cos(i),
    c = Math.sin(a);
  return [n * Math.cos(a), n * c, -s]
}

function trace(e, t) {
  var i = angle_to_vec(t[0], t[1]),
    a = Entity.GetRenderOrigin(e);
  a[2] += 50;
  var s = [a[0] + 8192 * i[0], a[1] + 8192 * i[1], a[2] + 8192 * i[2]],
    n = Trace.Line(e, a, s);
  if (1 != n[1]) {
    s = [a[0] + i[0] * n[1] * 8192, a[1] + i[1] * n[1] * 8192, a[2] + i[2] * n[1] * 8192];
    var c = Math.sqrt((a[0] - s[0]) * (a[0] - s[0]) + (a[1] - s[1]) * (a[1] - s[1]) + (a[2] - s[2]) * (a[2] - s[2]));
    if (a = Render.WorldToScreen(a), 1 == (s = Render.WorldToScreen(s))[2] && 1 == a[2]) return c
  }
}

function on_draw() {
  var e = Entity.GetLocalPlayer();
  if (Entity.IsAlive(e) && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 0 != !UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Freestanding type") && 0 != !UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && Entity.IsValid(e)) {
    var t = Local.GetViewAngles();
    left_distance = trace(e, [0, t[1] - 24]), right_distance = trace(e, [0, t[1] + 24]), left_distance > right_distance && inverter.get() && inverter.reverse(), right_distance > left_distance && (inverter.get() || inverter.reverse())
  }
}

function on_draw2() {
  var e = Entity.GetLocalPlayer();
  if (Entity.IsAlive(e) && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand fake on key") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 != !UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Freestanding type") && 0 != !UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && Entity.IsValid(e)) {
    var t = Local.GetViewAngles();
    left_distance = trace(e, [0, t[1] - 22]), right_distance = trace(e, [0, t[1] + 22]), left_distance < right_distance && inverter.get() && inverter.reverse(), right_distance < left_distance && (inverter.get() || inverter.reverse())
  }
}

function on_draw3() {
  var e = Entity.GetLocalPlayer();
  if (Entity.IsAlive(e) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable Anti-Aim") && 1 != !UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Legit AA on Key") && Entity.IsValid(e)) {
    var t = Local.GetViewAngles();
    left_distance = trace(e, [0, t[1] - 22]), right_distance = trace(e, [0, t[1] + 22]), left_distance < right_distance && inverter.get() && inverter.reverse(), right_distance < left_distance && (inverter.get() || inverter.reverse())
  }
}

function SafePoint() {
  var e = new Array;
   UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Prefer safe point on limbs") && -1 == e.indexOf(Cheat.GetUsername()) && (Ragebot.ForceHitboxSafety(7), Ragebot.ForceHitboxSafety(8), Ragebot.ForceHitboxSafety(9), Ragebot.ForceHitboxSafety(10), Ragebot.ForceHitboxSafety(11), Ragebot.ForceHitboxSafety(12))
}

function ForceHeadAim() {
  var e = new Array;
   UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && -1 == e.indexOf(Cheat.GetUsername()) && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Magic key bind") ? !seta && (PistolsHitboxes_cashe = UI.GetValue("Rage", "PISTOL", "Targeting", "Hitboxes"), HeavyPistolHitboxes_cashe = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes"), ScoutHitboxes_cashe = UI.GetValue("Rage", "SCOUT", "Targeting", "Hitboxes"), AWPHitboxes_cashe = UI.GetValue("Rage", "AWP", "Targeting", "Hitboxes"), AutoHitboxes_cashe = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes"), UI.SetValue("Rage", "PISTOL", "Targeting", "Hitboxes", 1), UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes", 1), UI.SetValue("Rage", "SCOUT", "Targeting", "Hitboxes", 1), UI.SetValue("Rage", "AWP", "Targeting", "Hitboxes", 1), UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes", 1), seta = !0, setb = !1) : !setb && (UI.SetValue("Rage", "PISTOL", "Targeting", "Hitboxes", PistolsHitboxes_cashe), UI.SetValue("Rage", "HEAVY PISTOL", "Targeting", "Hitboxes", HeavyPistolHitboxes_cashe), UI.SetValue("Rage", "SCOUT", "Targeting", "Hitboxes", ScoutHitboxes_cashe), UI.SetValue("Rage", "AWP", "Targeting", "Hitboxes", AWPHitboxes_cashe), UI.SetValue("Rage", "AUTOSNIPER", "Targeting", "Hitboxes", AutoHitboxes_cashe), setb = !0, seta = !1)
}

function ForceHeadAim1() {
  var e = new Array;
  e.push("russianhvhlegende1337"), e.push("YAKUZA"), e.push("HannesHvH"), e.push("arabhvh"), e.push("dr98867"), e.push("mbyking"), e.push("kezoawex"), e.push("Gazzy"), e.push("Mazika"), e.push("Karmabtww"), e.push("sword"), e.push("zYo"), e.push("EduardPlayz"), e.push("Ionutst1"), e.push("zilibobka"), e.push("DonCiuwawa"), e.push("jhee"), e.push("axye"), e.push("juwix"), e.push("ZeherChamp"), e.push("ExorPe"), e.push("infamouslegend"), e.push("loveen"), e.push("sorrow"), e.push("tragicts"), e.push("Mistmare"), e.push("Singeonst"), e.push("psychotic"), e.push("shiny69"), e.push("decmonk"), e.push("coldarms"), e.push("legendhvh"), e.push("arus"), e.push("SomeTh1n6"), e.push("v3rtual"), e.push("SantIkcc");
  var t = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Set value   "),
    i = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Set value    "),
    a = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Set value"),
    s = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Set value "),
    n = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Set value  "); - 1 == e.indexOf(Cheat.GetUsername()) && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable magic key") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Magic key type") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Magic key bind") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Use custom head scale for magic key") ? !setc && (pistol_head_multipoint_cache = UI.GetValue("Rage", "PISTOL", "Pistol config", "Head pointscale"), heavy_head_multipoint_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Heavy pistol config", "Head pointscale"), scout_head_multipoint_cache = UI.GetValue("Rage", "SCOUT", "Scout config", "Head pointscale"), awp_head_multipoint_cache = UI.GetValue("Rage", "AWP", "AWP config", "Head pointscale"), auto_head_multipoint_cache = UI.GetValue("Rage", "AUTOSNIPER", "Auto config", "Head pointscale"), UI.SetValue("Rage", "PISTOL", "Pistol config", "Head pointscale", t), UI.SetValue("Rage", "HEAVY PISTOL", "Heavy pistol config", "Head pointscale", i), UI.SetValue("Rage", "SCOUT", "Scout config", "Head pointscale", s), UI.SetValue("Rage", "AWP", "AWP config", "Head pointscale", n), UI.SetValue("Rage", "AUTOSNIPER", "Auto config", "Head pointscale", a), setc = !0, setd = !1) : !setd && (UI.SetValue("Rage", "PISTOL", "Pistol config", "Head pointscale", pistol_head_multipoint_cache), UI.SetValue("Rage", "HEAVY PISTOL", "Heavy pistol config", "Head pointscale", heavy_head_multipoint_cache), UI.SetValue("Rage", "SCOUT", "Scout config", "Head pointscale", scout_head_multipoint_cache), UI.SetValue("Rage", "AUTOSNIPER", "Auto config", "Head pointscale", auto_head_multipoint_cache), setc = !1, setd = !0)
}

function PingIndicator() {
  var e = new Array;
  if ( g_Local = Entity.GetLocalPlayer(), g_Local_weapon = Entity.GetWeapon(g_Local), weapon_name = Entity.GetName(g_Local_weapon), g_Local_classname = Entity.GetClassName(g_Local_weapon), localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index), render_get_screen_size = Render.GetScreenSize, !(Entity.GetLocalPlayer() && Entity.IsAlive(Entity.GetLocalPlayer()) && Entity.IsValid(Entity.GetLocalPlayer()) && 0 != !UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators"))) return;
  up = 0, font = Render.AddFont("Verdana", 16, 700), font2 = Render.AddFont("Small Fonts", 5, 100);
  var t = Math.round(1e3 * Local.Latency() - 16),
    i = Math.abs(t);
  const a = render_get_screen_size()[1];
  UI.GetValue("Misc", "GENERAL", "Miscellaneous", "Extended backtracking") && -1 == e.indexOf(Cheat.GetUsername()) && (Render.StringCustom(13, a - 390, 0, "PING", [0, 0, 0, 125], font), Render.StringCustom(12, a - 390, 0, "PING", [192 - 23 * i / 110, 32 + 83 * i / 110, 17, 255], font), i > 200 && (i = 200), i < 180 && (Render.FilledRect(13, a - 365 - up, 58, 4, [0, 0, 0, 150]), Render.FilledRect(14, a - 365 - up, 1 * i / 4 + 6, 2, [192 - 23 * i / 110, 32 + 83 * i / 110, 17, 255])), up = 20)
}

function in_bounds(e, t, i, a, s) {
  return e[0] > t && e[1] > i && e[0] < a && e[1] < s
}

function xy() {
  UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "keybinds_x", !1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "keybinds_y", !1)
}

function keybinds() {
  var e = new Array;
   g_Local = Entity.GetLocalPlayer(), localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index);
  const t = UI.GetValue.apply(null, skeetstyled_modes);
  var a = [];
  const s = Render.AddFont("Verdana", 7, 100);
  UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk") && a.push("Slow motion"), UI.IsHotkeyActive("Anti-Aim", "Extra", "Fake duck") && a.push("Duck peek assist"), UI.IsHotkeyActive("Misc", "GENERAL", "Movement", "Auto peek") && a.push("Quick peek"), UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter") && a.push("Anti-Aim invert"), UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force safe point") && a.push("Safe point"), UI.IsHotkeyActive("Rage", "GENERAL", "General", "Force body aim") && a.push("Body aim"), UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && UI.GetValue("Rage", "GENERAL", "Exploits", "Doubletap") && a.push("Double tap"), UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Hide shots") && UI.GetValue("Rage", "GENERAL", "Exploits", "Hide shots") && a.push("Hide shots"), UI.IsHotkeyActive("Legit", "GENERAL", "Triggerbot", "Enabled") && a.push("Triggerbot"), UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override") && a.push("Override damage"), UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Magic key bind") && a.push("Magic key"), UI.GetValue("Misc", "GENERAL", "Miscellaneous", "Extended backtracking") && a.push("Ping spike"), UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Freestand on Key") && a.push("Freestanding");
  const n = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_x"),
    c = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_y");
  Math.floor(127 * Math.sin(2 * Global.Realtime()) + 128), Math.floor(127 * Math.sin(2 * Global.Realtime() + 2) + 128), Math.floor(127 * Math.sin(2 * Global.Realtime() + 4) + 128);
  if (-1 == e.indexOf(Cheat.GetUsername()) && 1 & t && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") && 1 == localplayer_alive) {
    for (Render.FilledRect(n, c, 170, 20, [15, 15, 15, 255]), Render.StringCustom(n + 60, c + 4, 0, "hotkey list", [255, 255, 255, 255], s), Render.FilledRect(n, c, 170, 2, UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Choose color")), Render.FilledRect(n, c + 20, 170, 20 + 15 * (a.length - 1), [15, 15, 15, 100]), i = 0; i < a.length; i++) Render.StringCustom(n + 5, c + 23 + 15 * i, 0, a[i], [255, 255, 255, 255], s), Render.StringCustom(n + 123, c + 23 + 15 * i, 0, "[toggled]", [255, 255, 255, 255], s);
    if (Global.IsKeyPressed(1)) {
      const e = Global.GetCursorPosition();
      if (in_bounds(e, n, c, n + 200, c + 30)) {
        if (0 == UI.IsMenuOpen()) return;
        UI.SetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_x", e[0] - 100), UI.SetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_y", e[1] - 20)
      }
    }
  }
}

function get_spectators() {
  var e = [];
  const t = Entity.GetPlayers();
  for (i = 0; i < t.length; i++) {
    const a = t[i];
    if ("m_hObserverTarget" != Entity.GetProp(a, "CBasePlayer", "m_hObserverTarget")) {
      if (Entity.GetProp(a, "CBasePlayer", "m_hObserverTarget") === Entity.GetLocalPlayer()) {
        const t = Entity.GetName(a);
        e.push(t)
      }
    }
  }
  return e
}

function xy1() {
  UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "keybinds_xx", !1), UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "keybinds_yy", !1)
}

function SpecList() {
  g_Local = Entity.GetLocalPlayer(), localplayer_index = Entity.GetLocalPlayer(), localplayer_alive = Entity.IsAlive(localplayer_index);
  const e = UI.GetValue.apply(null, skeetstyled_modes),
    t = Render.AddFont("Verdana", 7, 100),
    a = get_spectators(),
    s = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_xx"),
    n = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_yy");
  Math.floor(127 * Math.sin(2 * Global.Realtime()) + 128), Math.floor(127 * Math.sin(2 * Global.Realtime() + 2) + 128), Math.floor(127 * Math.sin(2 * Global.Realtime() + 4) + 128);
  if (2 & e && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Indicators") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && 1 == UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Select indicators type") && 1 == localplayer_alive) {
    for (Render.FilledRect(s, n, 170, 20, [15, 15, 15, 255]), Render.StringCustom(s + 60, n + 4, 0, "Spectators", [255, 255, 255, 255], t), Render.FilledRect(s, n, 170, 2, UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Choose color")), Render.FilledRect(s, n + 20, 170, 20 + 15 * (a.length - 1), [15, 15, 15, 100]), i = 0; i < a.length; i++) Render.StringCustom(s + 5, n + 23 + 15 * i, 0, a[i], [255, 255, 255, 255], t);
    if (Global.IsKeyPressed(1)) {
      const e = Global.GetCursorPosition();
      if (in_bounds(e, s, n, s + 200, n + 30)) {
        if (0 == UI.IsMenuOpen()) return;
        UI.SetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_xx", e[0] - 100), UI.SetValue("Misc", "JAVASCRIPT", "Script items", "keybinds_yy", e[1] - 20)
      }
    }
  }
}

function EarlyMode() {
  var e = new Array;
  e.push("russianhvhlegende1337"), e.push("YAKUZA"), e.push("HannesHvH"), e.push("arabhvh"), e.push("dr98867"), e.push("mbyking"), e.push("kezoawex"), e.push("Gazzy"), e.push("Mazika"), e.push("Karmabtww"), e.push("sword"), e.push("zYo"), e.push("EduardPlayz"), e.push("Ionutst1"), e.push("zilibobka"), e.push("DonCiuwawa"), e.push("jhee"), e.push("axye"), e.push("juwix"), e.push("ZeherChamp"), e.push("ExorPe"), e.push("infamouslegend"), e.push("loveen"), e.push("sorrow"), e.push("tragicts"), e.push("Mistmare"), e.push("Singeonst"), e.push("psychotic"), e.push("shiny69"), e.push("decmonk"), e.push("coldarms"), e.push("legendhvh"), e.push("arus"), e.push("SomeTh1n6"), e.push("v3rtual"), e.push("SantIkcc");
  const t = UI.GetValue.apply(null, autowall_modes),
    i = UI.GetValue.apply(null, early_weapons);
  1 & i && 1 & t && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override") && -1 == e.indexOf(Cheat.GetUsername()) ? !sete1 && (autostop_modes_auto_cache = UI.GetValue("Rage", "AUTOSNIPER", "Accuracy", "Auto stop mode"), UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Auto stop mode", 2 + autostop_modes_auto_cache), sete1 = !0, setf1 = !1) : !setf1 && (UI.SetValue("Rage", "AUTOSNIPER", "Accuracy", "Auto stop mode", autostop_modes_auto_cache), sete1 = !1, setf1 = !0), 2 & i && 1 & t && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override") && -1 == e.indexOf(Cheat.GetUsername()) ? !sete2 && (autostop_modes_scout_cache = UI.GetValue("Rage", "SCOUT", "Accuracy", "Auto stop mode"), UI.SetValue("Rage", "SCOUT", "Accuracy", "Auto stop mode", 2 + autostop_modes_scout_cache), sete2 = !0, setf2 = !1) : !setf2 && (UI.SetValue("Rage", "SCOUT", "Accuracy", "Auto stop mode", autostop_modes_scout_cache), sete2 = !1, setf2 = !0), 4 & i && 1 & t && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override") && -1 == e.indexOf(Cheat.GetUsername()) ? !sete3 && (autostop_modes_awp_cache = UI.GetValue("Rage", "AWP", "Accuracy", "Auto stop mode"), UI.SetValue("Rage", "AWP", "Accuracy", "Auto stop mode", 2 + autostop_modes_awp_cache), sete3 = !0, setf3 = !1) : !setf3 && (UI.SetValue("Rage", "AWP", "Accuracy", "Auto stop mode", autostop_modes_awp_cache), sete3 = !1, setf3 = !0), 8 & i && 1 & t && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override") && -1 == e.indexOf(Cheat.GetUsername()) ? !sete4 && (autostop_modes_pistol_cache = UI.GetValue("Rage", "PISTOL", "Accuracy", "Auto stop mode"), UI.SetValue("Rage", "PISTOL", "Accuracy", "Auto stop mode", 2 + autostop_modes_pistol_cache), sete4 = !0, setf4 = !1) : !setf4 && (UI.SetValue("Rage", "PISTOL", "Accuracy", "Auto stop mode", autostop_modes_pistol_cache), sete4 = !1, setf4 = !0), 16 & i && 1 & t && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Autowall fix") && UI.IsHotkeyActive("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override") && -1 == e.indexOf(Cheat.GetUsername()) ? !sete5 && (autostop_modes_heavypistol_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Accuracy", "Auto stop mode"), UI.SetValue("Rage", "HEAVY PISTOL", "Accuracy", "Auto stop mode", 2 + autostop_modes_heavypistol_cache), sete5 = !0, setf5 = !1) : !setf5 && (UI.SetValue("Rage", "HEAVY PISTOL", "Accuracy", "Auto stop mode", autostop_modes_heavypistol_cache), sete5 = !1, setf5 = !0)
}
seta = !1, setb = !0, setc = !1, setd = !0, xy(), xy1(), sete1 = !1, setf1 = !0, sete2 = !1, setf2 = !0, sete3 = !1, setf3 = !0, sete4 = !1, setf4 = !0, sete5 = !1, setf5 = !0;
const able_to_shift_shot = function (e, t) {
    const i = (Entity.GetProp(e, "CCSPlayer", "m_nTickBase") - t) * Globals.TickInterval();
    return i > Entity.GetProp(e, "CCSPlayer", "m_flNextAttack") && i > Entity.GetProp(Entity.GetWeapon(e), "CBaseCombatWeapon", "m_flNextPrimaryAttack")
  },
  on_move = function () {
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "DT speed boost")) {
      Exploit.OverrideShift(14), Exploit.OverrideTolerance(0);
      const a = Entity.GetLocalPlayer(),
        s = Exploit.GetCharge();
      1 != s ? Exploit.EnableRecharge() : Exploit.DisableRecharge();
      const n = able_to_shift_shot(a, 14),
        c = 1 == s && n;
      var e = !c && n;
      const o = Entity.GetEnemies().filter(function (e) {
          return Entity.IsValid(e) && Entity.IsAlive(e) && !Entity.IsDormant(e)
        }),
        r = Entity.GetEyePosition(a);
      if (c || e)
        for (var t = 0; t < o.length; t++) {
          const s = o[t],
            n = Entity.GetProp(s, "CBasePlayer", "m_iHealth");
          for (var i = 2; i <= 4; i++) {
            const t = Entity.GetHitboxPosition(s, i);
            if (void 0 !== t) {
              const i = Trace.Bullet(a, s, r, t);
              if (c && i[1] >= n / 2) Ragebot.ForceTargetMinimumDamage(s, n / 2);
              else if (e && i[2]) {
                e = !1;
                break
              }
            }
          }
        }
      e && (Exploit.DisableRecharge(), Exploit.Recharge())
    }
  },
  on_unload = function () {
    Exploit.EnableRecharge()
  };

function Main() {
  Global.RegisterCallback("Draw", "drawString"), Global.RegisterCallback("Draw", "SpecList"), Global.RegisterCallback("Draw", "keybinds"), Global.RegisterCallback("player_connect_full", "player_connect"), Global.RegisterCallback("CreateMove", "on_draw"), Global.RegisterCallback("CreateMove", "on_draw2"), Global.RegisterCallback("CreateMove", "on_draw3"), Global.RegisterCallback("Draw", "SetEnabled"), Cheat.RegisterCallback("Draw", "indicator"), Cheat.RegisterCallback("Draw", "PingIndicator"), Cheat.RegisterCallback("CreateMove", "onCM"), Cheat.RegisterCallback("CreateMove", "SafePoint"), Cheat.RegisterCallback("CreateMove", "Safe_Head"), Cheat.RegisterCallback("CreateMove", "JitterUnsafe"), Cheat.RegisterCallback("CreateMove", "ForceHeadAim"), Cheat.RegisterCallback("CreateMove", "ForceHeadAim1"), Cheat.RegisterCallback("CreateMove", "LegitAA"), Cheat.RegisterCallback("CreateMove", "PingSpike"), Cheat.RegisterCallback("CreateMove", "BetterOnshot"), Cheat.RegisterCallback("CreateMove", "EarlyMode"), Cheat.RegisterCallback("CreateMove", "on_move"), Cheat.RegisterCallback("Unload", "on_unload")
}
Main();