/*
    Minesweeper Game
    by kseny
*/

var screenSize = Global.GetScreenSize();

var boxSize = 200;

var playingGame = false;
var revealBombs = false;
var gameMatrix = [];
var bombsCount = 20;


function onCellClick(i, j)
{
    switch(gameMatrix[i][j])
    {
        case -1:
        {
            playingGame = false;
            revealBombs = true;
            break;
        }
        case -2:
        {
            mineCount = 0;

            for (a = Math.max(i-1, 0); a <= Math.min(i+1, 9); a++)
                for(b = Math.max(j-1, 0); b <= Math.min(j+1, 9); b++)
                    if(gameMatrix[a][b] == -1)
                        mineCount ++;

            gameMatrix[i][j] = mineCount;  

            if(mineCount == 0)
                for (a = Math.max(i-1, 0); a <= Math.min(i+1, 9); a++)
                    for(b = Math.max(j-1, 0); b <= Math.min(j+1, 9); b++)
                        onCellClick(a, b);
        }
    }

    gameCompleted = true;

    for(i = 0; i < 10; i++)
        for(j = 0; j < 10; j++)
            if(gameMatrix[i][j] == -2)
                gameCompleted = false;

    if(gameCompleted)
        playingGame = false;  
}

function onDrawEvent()
{
    if(!UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Play Minesweeper Game") || !UI.IsMenuOpen())
        return;

    Render.GradientRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 - boxSize/2 - 34 - 2, boxSize + 10, 4, 1, [217, 157, 86, 255], [223, 174, 97, 255]);
    Render.FilledRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 - boxSize/2 - 30 - 2, boxSize + 10, 25, [44, 48, 55, 255]);
    Render.String(screenSize[0]/2, screenSize[1]/2 - boxSize/2 - 25 - 2, 1, "Minesweeper", [255, 255, 255, 255]);

    Render.FilledRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 - boxSize/2 - 5, boxSize + 10, boxSize + 10, [44, 48, 55, 255]);
    Render.Rect(screenSize[0]/2 - boxSize/2, screenSize[1]/2 - boxSize/2, boxSize, boxSize, [100, 100, 100, 150]);

    for(i = 0; i < 10; i++)
    {
        for(j = 0; j < 10; j++)
        {
            if(gameMatrix[i][j] == -1 && revealBombs)
                Render.FilledRect(screenSize[0]/2 - boxSize/2 + i * 20, screenSize[1]/2 - boxSize/2 + j * 20, 19, 19, [255, 0, 0, 255]);

            if(gameMatrix[i][j] > -1)
                Render.String(screenSize[0]/2 - boxSize/2 + i * 20 + 10, screenSize[1]/2 - boxSize/2 + j * 20 + 7, 1, gameMatrix[i][j].toString(), [255, 255, 255, 255], 2);

            Render.Rect(screenSize[0]/2 - boxSize/2 + i * 20, screenSize[1]/2 - boxSize/2 + j * 20, 20, 20, [255, 255, 255, 255]);
        }
    }

    if(playingGame)
    {
        var cursorPosition = Global.GetCursorPosition();

        if(Global.IsKeyPressed(0x01))
            for(i = 0; i < 10; i++)
                for(j = 0; j < 10; j++)
                    if(cursorPosition[0] >= screenSize[0]/2 - boxSize/2 + i * 20 && cursorPosition[0] <= screenSize[0]/2 - boxSize/2 + (i+1) * 20 && cursorPosition[1] >= screenSize[1]/2 - boxSize/2 + j * 20 && cursorPosition[1] <= screenSize[1]/2 - boxSize/2 + (j+1) * 20)
                        onCellClick(i, j);
    }
    else
    {
        Render.FilledRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 + boxSize/2 + 15, boxSize + 10, 47, [0, 0, 0, 120]);

        if(revealBombs == true)
            Render.String(screenSize[0]/2, screenSize[1]/2 + boxSize/2 + 22.5, 1, "You lost", [255, 0, 0, 255]);
        else
            Render.String(screenSize[0]/2, screenSize[1]/2 + boxSize/2 + 22.5, 1, "You Won", [0, 255, 0, 255]);

        Render.String(screenSize[0]/2, screenSize[1]/2 + boxSize/2 + 38, 1, "Press ENTER to start a new game", [255, 255, 255, 255]);

        if(Global.IsKeyPressed(0x0D))
            startNewGame();
    }
}

function startNewGame()
{
    gameMatrix = [];

    for(i = 0; i < 10; i++)
    {
        gameMatrix[i] = [];

        for(j = 0; j < 10; j++)
            gameMatrix[i][j] = -2;
    }

    for(i = 0; i < bombsCount; i++)
        gameMatrix[Math.floor(Math.random() * 10)][Math.floor(Math.random() * 10)] = -1;

    playingGame = true;
    revealBombs = false;
}


startNewGame();
UI.AddCheckbox("Play Minesweeper Game");
Global.RegisterCallback("Draw", "onDrawEvent");
Discord: Ksenon#6969
 Like
Reply
Report
LikeLove Reactions:AbortedFetus, Darth, Tilestra and 2 others
ReDneZ
Member
Subscriber
Dec 6, 2019
New
Add bookmark
#2
Nice, great work again!
 Like
Reply
Report
Rory
Rory
Member
Subscriber
Dec 6, 2019
New
Add bookmark
#3
Another big brain script from ksenon as always.
GitHub
 Like
Reply
Report
Like Reactions:rtkpX
dummy
dummy
Member
Subscriber
Dec 6, 2019
New
Add bookmark
#4
time for staff to move to approved scripts
great release
 Like
Reply
Report
Like Reactions:rtkpX
MrDansku
MrDansku
Member
Dec 6, 2019
New
Add bookmark
#5
Nice one, as always!
Could you do Flappy Bird next?
 Like
Reply
Report
ksenon
ksenon
Member
Dec 6, 2019
New
Add bookmark
#6
MrDansku said:
Nice one, as always!
Could you do Flappy Bird next?
We can't draw "custom" textures (images) with the current api limitations and if I will do it with rectangles it will be ugly af.
Discord: Ksenon#6969
 Like
Reply
Report
dummy
dummy
Member
Subscriber
Dec 6, 2019
New
Add bookmark
#7
ksenon said:
We can't draw "custom" textures (images) with the current api limitations and if I will do it with rectangles it will be ugly af.
if you want i can make a way to draw it using rectangles then send you the function like draw_bird( x, y, size )
 Like
Reply
Report
ksenon
ksenon
Member
Dec 6, 2019
New
Add bookmark
#8
dummy said:
if you want i can make a way to draw it using rectangles then send you the function like draw_bird( x, y, size )
It would be ugly with rectangles.
Discord: Ksenon#6969
 Like
Reply
Report
MrDansku
MrDansku
Member
Dec 6, 2019
New
Add bookmark
#9
ksenon said:
It would be ugly with rectangles.
true, i quess
 Like
Reply
Report
dummy
dummy
Member
Subscriber
Dec 6, 2019
New
Add bookmark
#10
ksenon said:
It would be ugly with rectangles.
i could make it look like the real thing bb only problem would be rotating the bird
 Like
Reply
Report
rtkpX
rtkpX
Well-Known Member
Dec 6, 2019
New
Add bookmark
#11
ksenon said:




Some of you requested a Minesweeper JS.
The cheat menu needs to be opened in order to play the game.
Have fun!

/*
    Minesweeper Game
    by kseny
*/

var screenSize = Global.GetScreenSize();

var boxSize = 200;

var playingGame = false;
var revealBombs = false;
var gameMatrix = [];
var bombsCount = 20;


function onCellClick(i, j)
{
    switch(gameMatrix[i][j])
    {
        case -1:
        {
            playingGame = false;
            revealBombs = true;
            break;
        }
        case -2:
        {
            mineCount = 0;

            for (a = Math.max(i-1, 0); a <= Math.min(i+1, 9); a++)
                for(b = Math.max(j-1, 0); b <= Math.min(j+1, 9); b++)
                    if(gameMatrix[a][b] == -1)
                        mineCount ++;

            gameMatrix[i][j] = mineCount; 

            if(mineCount == 0)
                for (a = Math.max(i-1, 0); a <= Math.min(i+1, 9); a++)
                    for(b = Math.max(j-1, 0); b <= Math.min(j+1, 9); b++)
                        onCellClick(a, b);
        }
    }

    gameCompleted = true;

    for(i = 0; i < 10; i++)
        for(j = 0; j < 10; j++)
            if(gameMatrix[i][j] == -2)
                gameCompleted = false;

    if(gameCompleted)
        playingGame = false; 
}

function onDrawEvent()
{
    if(!UI.GetValue("MISC", "JAVASCRIPT", "Script Items", "Play Minesweeper Game") || !UI.IsMenuOpen())
        return;

    Render.GradientRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 - boxSize/2 - 34 - 2, boxSize + 10, 4, 1, [217, 157, 86, 255], [223, 174, 97, 255]);
    Render.FilledRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 - boxSize/2 - 30 - 2, boxSize + 10, 25, [44, 48, 55, 255]);
    Render.String(screenSize[0]/2, screenSize[1]/2 - boxSize/2 - 25 - 2, 1, "Minesweeper", [255, 255, 255, 255]);

    Render.FilledRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 - boxSize/2 - 5, boxSize + 10, boxSize + 10, [44, 48, 55, 255]);
    Render.Rect(screenSize[0]/2 - boxSize/2, screenSize[1]/2 - boxSize/2, boxSize, boxSize, [100, 100, 100, 150]);

    for(i = 0; i < 10; i++)
    {
        for(j = 0; j < 10; j++)
        {
            if(gameMatrix[i][j] == -1 && revealBombs)
                Render.FilledRect(screenSize[0]/2 - boxSize/2 + i * 20, screenSize[1]/2 - boxSize/2 + j * 20, 19, 19, [255, 0, 0, 255]);

            if(gameMatrix[i][j] > -1)
                Render.String(screenSize[0]/2 - boxSize/2 + i * 20 + 10, screenSize[1]/2 - boxSize/2 + j * 20 + 7, 1, gameMatrix[i][j].toString(), [255, 255, 255, 255], 2);

            Render.Rect(screenSize[0]/2 - boxSize/2 + i * 20, screenSize[1]/2 - boxSize/2 + j * 20, 20, 20, [255, 255, 255, 255]);
        }
    }

    if(playingGame)
    {
        var cursorPosition = Global.GetCursorPosition();

        if(Global.IsKeyPressed(0x01))
            for(i = 0; i < 10; i++)
                for(j = 0; j < 10; j++)
                    if(cursorPosition[0] >= screenSize[0]/2 - boxSize/2 + i * 20 && cursorPosition[0] <= screenSize[0]/2 - boxSize/2 + (i+1) * 20 && cursorPosition[1] >= screenSize[1]/2 - boxSize/2 + j * 20 && cursorPosition[1] <= screenSize[1]/2 - boxSize/2 + (j+1) * 20)
                        onCellClick(i, j);
    }
    else
    {
        Render.FilledRect(screenSize[0]/2 - boxSize/2 - 5, screenSize[1]/2 + boxSize/2 + 15, boxSize + 10, 47, [0, 0, 0, 120]);

        if(revealBombs == true)
            Render.String(screenSize[0]/2, screenSize[1]/2 + boxSize/2 + 22.5, 1, "You lost", [255, 0, 0, 255]);
        else
            Render.String(screenSize[0]/2, screenSize[1]/2 + boxSize/2 + 22.5, 1, "You Won", [0, 255, 0, 255]);

        Render.String(screenSize[0]/2, screenSize[1]/2 + boxSize/2 + 38, 1, "Press ENTER to start a new game", [255, 255, 255, 255]);

        if(Global.IsKeyPressed(0x0D))
            startNewGame();
    }
}

function startNewGame()
{
    gameMatrix = [];

    for(i = 0; i < 10; i++)
    {
        gameMatrix[i] = [];

        for(j = 0; j < 10; j++)
            gameMatrix[i][j] = -2;
    }

    for(i = 0; i < bombsCount; i++)
        gameMatrix[Math.floor(Math.random() * 10)][Math.floor(Math.random() * 10)] = -1;

    playingGame = true;
    revealBombs = false;
}


startNewGame();
UI.AddCheckbox("Play Minesweeper Game");
Global.RegisterCallback("Draw", "onDrawEvent");
Click to expand...cool but next time do some useful script hhh
 Like
Reply
Report
ksenon
ksenon
Member
Dec 6, 2019
New
Add bookmark
#12
rtkpX said:
cool but next time do some useful script hhh
ty, working on smth
streamable.com
2019-12-05 01-19-02 - Streamable
Check out this video on Streamable using your phone, tablet or desktop.
streamable.com streamable.com
Discord: Ksenon#6969
 Like
Reply
Report
Like Reactions:rtkpX
rtkpX
rtkpX
Well-Known Member
Dec 6, 2019
New
Add bookmark
#13
ksenon said:
ty, working on smth
streamable.com
2019-12-05 01-19-02 - Streamable
Check out this video on Streamable using your phone, tablet or desktop.
streamable.com streamable.com
p100

PS: Do smth for enemy and teammate grenade tracer and for having that for seeing where ur grenade went
 Like
Reply
Report
Bop32
Member
Subscriber
Dec 6, 2019
New
Add bookmark
#14
you are insane lmao thanks mate
 Like
Reply
Report
factor
factor
Well-Known Member
Subscriber
Dec 6, 2019
New
Add bookmark
#15
ksenon said:
ty, working on smth
streamable.com
2019-12-05 01-19-02 - Streamable
Check out this video on Streamable using your phone, tablet or desktop.
streamable.com streamable.com
dude this looks insane
 Like
Reply
Report
Tilestra
Tilestra
Well-Known Member
Subscriber
Dec 6, 2019
New
Add bookmark
#16
Nice job as always :cool:
 Like
Reply
Report


Write your reply...

 Post reply

Preview
CSGO
Scripting
Approved Scripts
Contact Us
Terms of Use
Privacy Policy
Help
RSS
Copyright © 2019 Onetap. All rights reserved.
