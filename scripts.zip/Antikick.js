UI.AddCheckbox( "Enable Anti-Kick" );

UI.AddSliderInt( "Threshold", 1, 100 );
UI.SetValue( "MISC", "JAVASCRIPT", "Script Items", "Threshold", 80 );

var KickLastCommandTime;
var KickPotentialVotes = 0;

var KickYesVoters = 0;
var KickGettingKicked = false;

function GetValue( Name )
{
    var Value = UI.GetValue( "Misc", "JAVASCRIPT", "Script Items", Name );
    return Value;
}

function GetLastCommandTime()
{
    KickLastCommandTime = null;
}

function GetPtentialVotes()
{
    KickPotentialVotes = Event.GetInt("potentialVotes");
}

function Main()
{
    var CurrentMap = Global.GetMapName();
    var Me = Entity.GetLocalPlayer();

    if ( !GetValue("Enable Anti-Kick") || CurrentMap == null || Me == null )
        return;

    var VoteOption = Event.GetInt("vote_option");
    var VoteEid = Event.GetInt("entityid");

    if ( Me != VoteEid && VoteOption == 0 ) {
        KickYesVoters = KickYesVoters + 1;
    }

    if ( Me == VoteEid && VoteOption == 1 ) {
        KickGettingKicked = true;
        KickYesVoters = 1;
    }

    if ( KickGettingKicked == false ) {
        return;
    }

    var KickPercentage = ( (KickYesVoters - 1) / ( KickPotentialVotes / 2 ) * 100 );

    if ( KickYesVoters > 0 && KickPotentialVotes > 0 && KickPercentage >= GetValue("Threshold")
        && ( KickLastCommandTime == null || Global.Curtime() - KickLastCommandTime > 300 ) )
    {
        Global.ExecuteCommand( "callvote ChangeLevel " + CurrentMap );
        KickLastCommandTime = Global.Curtime();
    }

}

Global.RegisterCallback( 'game_start', 'GetLastCommandTime' );
Global.RegisterCallback( 'vote_changed', 'GetPtentialVotes' );
Global.RegisterCallback( 'vote_cast', 'Main' );