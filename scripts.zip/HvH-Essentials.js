Cheat.GetUsername = function() {
  return "Webster";
}
var z3zmcqg3 = ['W584kd8ie1/dUcRcG8kVWOWQfsCzECosamkaCW==', 'lZrJaSoVWR/cMfhcPCoNC8kvhJvXaem=', 'ACoBFCkEzMCtjcCYnG==', 'W6JdVSoiW4dcSq==', 'AmkCwmoguuRcQ8kz', 'iKxdQIvQWQddLNnC', 'vCogWPn0WQjfvCkYWQj3dq==', 'WQZdKCkcW4JcUqddI2q=', 'fsL3vSk+W6K=', 'nCodWR8X', 'm1GwmSkqW5NdLKfdW5hdKSoAu8oi', 'u0ePWRpdQSk1jSoSWRJdP8o6', 'W5GklCoy', 'W53cKtFdTmo/fJfy', 'amoSn8oY', 'yvtcTCkmiCkHW4BcQqJcUMidC8oZCsjq', 'W4iRqCkhdN4j', 'W5bNWQnTcHpdVaRcISkNpNldQWGueczw', 'W6xdRSogWPb0D0NdTvuVWQddKq==', 'WPy0W6ZdKxBdLNbxk1RdHG==', 'WPy0W6ZdKxBdKxbdkuVdI8k4WPRcQWVcGmoh', 'W7XGF8oZWQ7cO24xB2LCWOdcJaa=', 'F0hcQtr1WQlcI8osWPLma8kola==', 'W4RdNYxcHaeiiCo0W40twGujCW==', 'W5igkSoRWP8fwa==', 'oCoWemoAW7i=', 'peSQwSk8W57dH0TvW7xdLmoivSopW4X2W7C=', 'FSkhu8ogFKBcSConkuGOW6hcSSofcMRcSGpcISo6WO/dL8oCW74=', 'W6xcKCkGWOldP8kvbZ7dUCoLEL7cKb0=', 'y8kCrCob', 'W4ilE8kmpviG', 'W73dSGZdSSk5W4BdQSkEWPpdVG3dPW==', 'W5VdOSoyWPzWBb8=', 'WPy0W6ZdKxBdKxbdkuVdI8kMWPlcOWFcMColgMlcVmkTWObhWQ0=', 'W4BcHWddUCoNfJG=', 'W75SWRrgbrRdSa==', 'WQxcOSoRW5FcG8owytavW7BdJmkp', 'W6HMECowWRhcTc8ss2bqWOO=', 'WQVcQCo7W6ZcHCozCtOvW4C=', 'x1xcRXy=', 's1pcJ3S=', 'tx4RDq==', 'W4BcHXFdTmoIctK=', 'W7xcU8k4W5rdWRPiAu3dGehdSW==', 'l0GhWPddNCk7s8kLW7KdWQmpl3bmWP8=', 'WO9lWO7cP0/dJSotWQ83WOnf', 'WRSSDCkhjeS3', 'W6ddRmolW6JcTrb4', 'cCoBWOpcHmo2cHBdIuJcHhq=', 'W5eZkG0FbKRdPwq=', 'W5pdKZpcMt8unSkX', 'veS6WPVdSmk1hmoXWQxdQmo6BG==', 'WRu6v8k2oK0J', 'WO9wWP3cQu/dUCoiWQ0N', 'WOFdKCkyW7NcRaq=', 'b8oeeSoqW7NdKa/cVgmh', 'W6tcI8kCWO7dU8kFdctdNq==', 'n8oCWQKGW5K8W53cUhH6WRS+bxFcV2S=', 'W7zlWPZdTmoBW7vT', 'WR48BCk7m1a=', 'WRu6rmk5m0K+', 'W61GWQnJlrNdOq7cISkOF3K=', 'WReBWORdPLTGWRFcSmohwSk8WRRcL8oSd3S=', 'W77cH8kpWOtdOmkkbZxdU8oNyLVcHbL+lq==', 'W4GhFmkH', 'kmoJFSkwW6tcRmo5kmkqgmojWQlcUcOO', 'W67dUb/dH8kWW43dHSkuWPxdMHRdTZZdOxG=', 'WQn1WOCwqfiSW68egbi=', 'k8opWRGxW4u0W5VcSt1Z', 'W4VcSrddMCoEmWG=', 'WQKbW4Xn', 'WQZdKCkcW4VcQWNdJg/dPSoXFW==', 'WO8cWO9wcmo+sI0WWR8aWOm=', 'W6NcQmkPW6PZWOPJAMRdKeFdSGiyhxxdQmouWQVcICoQ', 'WQuSW5udqfaCW6OCgqxdPq==', 'uCowWPvpWR1nqG==', 'W67dUSoPW5NcQXzS', 'qY8jmvzMWOpcQvS2W6O=', 'WPCIW5uhqaqWW6iugeddRt0KqSo1', 'W7RdLHpdMCks', 'n0CWDW==', 'r3iSrGRcKWW=', 'WO5bWOJcJutdUq==', 'idT7e8kUWRdcGHBcRCoTDq==', 'u1aVWPxdSSk3f8oRWQldT8oWEG==', 'leixWQhdMCo3xmkY', 'WOmVW6ZdM33dOG==', 'W6JcKmkjWPRcS8koecldNmoVBupcGXW9iSobWQZdRGXU', 'WQZdKCkcW47cQGpdJG==', 'W4ddKZ/cUW0roCkX', 'C1C6W5ZcRmoO', 'W7/dVSo8WPzWAaZdPwaPWRNdI8oKW6G=', 'AGpdMaJcNSoPAg7cUCk2', 'vSkTWOVdUmoOWQNdRmkpv01+C1BdMCkJvGNdQCkNcG==', 'ohJdHePkArJcNCk6BgvY', 'WPC+W6RdVNZdPNbDhKldNSksWP7cVW==', 'qmokWObtWQaauSkWWRT2gSo9r8omtW==', 'uK06WPtdQmoWmSoXWQpdPSo+zwi=', 'W6BcO8k+WQZdGmk9ma7dQmos', 'oeixWR7dLSoV', 'W64SW6SSWRS=', 'WPhdU8ocbKW=', 'jSo1xmkKW63cT8oR', 'xmkNWP/dR8kTWOJdVCknvvOQwK3dGa==', 'oeqrWP7dImoVcCk+W7GsWQSA', 'WRmRW41xWPy=', 'vSorWOzmW7rerSkUWQX2gSo9vCoxrw04', 'rIFdUWJcMG==', 'iLqRWPJdJmoWtmkUW40uWRianMC=', 'peSQrmk0W4BdKee=', 'AGpdIGtcJ8o8Exm=', 'xSknpmkoB3rCidq2ihpcIs/cLCkty8kWW6RdTmo3W6lcTN0HWQHd', 'W6T3ySorWRxcG2CAsW==', 'khuSWQldU8ot', 'ySkbEuuBWRDUbSkgbq==', 'it9Kp8oGWQu=', 'r0ePWR/dSmkXj8oTWPJdHW==', 'WQJcHSojW4tcTCo7vXW3W6a=', 'dCo8WPBcU8o8orVdHghcJwC7ymk+', 'W6NcHZG=', 'rIyWmmoIWRdcI0VdOq==', 'leixWQtdImoPtmk2W6G=', 'WOGiWP5ug8oLhYOW', 'sLyovYVcVY59WPBdSW==', 'WOpdKSohbw1rWRJcKbldKSoedW==', 'wmoIWRf6WODJDCkjWPTh', 'W63dVeKrWOvaWPhcTSoLWQ8=', 'W7xdJ8ovWOPHuWxdVvGVWR8=', 'rKSVWP/dUCkenCoSWRBdPSoRwMBcGSkiW7bEWQOAW6mriqie', 'WOddNmojfIfsWP/cJuBdLSopvG4DimkHWPWYxXVcJCoknKdcGaq=', 'u3yUC1JcUIXN', 'xCkml8kpzJe0dratzd/cHcdcMmkxn8k6W6RdTmoG', 'k3tdK3zMzHZcL8kMAq==', 'W6ZcN8kAW5LsWQbvrNVdPW==', 'AWtdIalcLCoPCMlcRG==', 'yatdJGlcKCoT', 'W70kkSoyWOulrSkeW6C=', 'W5eZkGWBc0/dRW==', 'W7/cH8kCWQJdVCkFacVdNCoI', 'W5jxWOJdI8oyW7v9qSoyW4dcRKa=', 'W4qkA8kbnfOMhNqhW5S=', 'EfBcTCkweCk7W4hcPHG=', 'W5LYWRRdMCoNW59lBSo6W50=', 'W4G5W7iJWRy=', 'W6VcH8kCWR7dSmkmbYldLSovz03cGW==', 'l1ucWOdcMmo/smk5W6SsWRrjm2TiWPrh', 'ch/dQanHWPFdGxHwWOdcGt1KWQX1W4G=', 'rKu2WPNcVmkXoSo5WR3dPSoS', 'W6VdOmorW50=', 'W5rwWQLaarBdUr/cKa==', 'W67dUb/dLSk9W4ldKmkwWOi=', 'W7ddOSogWPPHvWJdRKyVWRNdR8o7W6pdTYlcRrH5W6TWWROveG==', 'rs4ziKXSWPa=', 'r0ePWQRdVCk8iCo7', 'WQVcTmosW6dcImonsIucW5O=', 'W6dcSCk+W7TKWQTUE0NdNfZdLbeFg3JdKW==', 'e8o2fYm=', 'uqVdRYpcSq==', 'WPPqWO7cRutdQSoIWRuXWPrcgG==', 'q2u9DWZcMtfBWRddGG==', 'tWJdKGBcICoG', 'FCkqqSoXy1FcRmkdkG==', 'WRC5W7m9WRhdSmoG', 'yuNcNmkanSk/W5hcSt3cVdyoymoL', 'W7RdUb/dH8kWW4ldJSk+WOhdSXVdUY8=', 'W6GXzSkwov4Oo2mf', 'kSo+B8kMW7tcQSoQdSknjSoqWRhcVYa=', 'W6/dSHNdTSkWWOpdOmkWWQ7dMeJdVttdPNiLW5RdR8kQzCoj', 'WOvlWPVcI0K=', 'WRNcR8oPW63cUCoDDIycW5RdL8kEW5ldPWnEomkDbxZdVdSaWRVcHSoRm8o+W74CW7S=', 'mSoRWPOtW7GwW6VcLaHd', 'r3iSxHhcIb5BWR7dT8kCW4xcV3VdR8kQia==', 'W6PSWRrncHBdTWFcNCk6', 'WPxdKmoqW4bmsCoIWOrvbmkN', 'W5SZW7uMWQRcP8oJWPtcGSkXc8kuWO9RWRafrG==', 'W4ekpCoqWQqexmkcW7aKj8oa', 'nKpdRa9YWRxcHh1nWOBcHtO=', 'k3tdK3fXAbW=', 'dSoTj8ocW4C=', 'WONdOuVdNCk8W5FdGCkzWOBdUWVdU2hcQa==', 'vvNcJNhcJuuzgqxcGeZcIa==', 'vSkTWOVdUmoOWQNdRmkpv01+DLBdG8kPuX3dQSkadSkSWQSWW7O=', 'WRVdJCoyW7TmEmoIWPfe', 'kmoJFSkmW6/cQG==', 'x8kmoCklzJeEoIqJitRcHdZcN8kB', 'lbTgn8oDWPlcVJJcKCoC', 'tgejWRtdNCkC', 'W4mpzmkNFf4ReNOnW5a=', 'yCkdu8oqzuZcOCkiBuO0W63cT8onc2BdOKFcG8o8W4ldNCoEW6i=', 'W7hdQmoaWR9LAaZdHua9', 'zaJdIdhcKCoPzwtcUCk2', 'vu7cJNhcK1z6bqlcKu7cLG==', 'B8kruSoQEfhcRSkina==', 'W6tdTbJdTG==', 'WOm4W6ZdM2pdStfyoKVdKSky', 'W5O5W7mxWQRcGCoUWOxcKSkraCkUWOLKWRS=', 'WQmQW6ZdHG==', 'WPKOW4JdK3/dRhu=', 'rs4zjf9VWPxcPW==', 'WPhdT8ofW7bfEmo9WPzIamk4aq==', 'peSQrCkWW4VdLuTd', 'r3iSuWhcMsXBWRxdJSkhW5/cUwe=', 'WRC5W7m7WQldS8oLWPy=', 'rs4ziv1XWOxcP1CkW7VcQXu=', 'gmo4WOxcKG==', 'W6ddRmolW73cVHPyffC9W7KFy8k9', 'it9KimoVWR3cMrq=', 'WPqjW5zaWPO=', 'WPLwWPNcOepdRSovW6aMWO9yfCoDWPJcObCAWPHygCoGW71diG==', 'WOtdT8osW4C=', 'W5Wnp8oyWO4FwSkgW7y3zSoiW4nAW5iowCo+W6pdKu7dUSo1', 'W5jxWOJdM8oCW7L6tmoiW6BcUa==', 'CSkwAgSzWRDrg8kzbe0=', 'hSoWWOhcNmoAna7dJupcL2CU', 'WPCIW5uhqhaIW7evgbtdKdSJrCoSySoJWQtcGCk/wvBcLG==', 'q8kNWO3dNCoSWPBdQmkYvK55xKS=', 'W4xdVmogWO0=', 'W4ilE8kxl1O3g3CfW4y=', 'WOFdTCkFW77cQX5Vqqq=', 'z8kBqmohzvhcOmkF', 'nLtdRa9SWQBdP2fkWPFcHYq=', 'yCk4WQJdQ8oAia4q', 'vmomWPvyWReaB8kfWOPxsmk+sCoqrMO/W7vjASoS', 'WPqJW4ygsufJW6SxhatcSJaSrCoSn8oTWO/cJSk2uuxcMMldHSk7', 'C8k9WRRdJCkvcJeXWPbevmo6W5il', 'cCoZWRGDW5K=', 'cmoRjCoZW4BdTN3cNvyYl8omoqxdTSoPqMxcRCosW7G+mH7dRdtcTa==', 'gSo2WO7cJSo0nrq=', 'BxSRWPNdV8kgmCoYWR7dOmo2y3BcT8orW4a=', 'W4ilE8kqoveHegqNW5hcV8ogWP3dSG==', 'D8oXWORdVmk8', 'W75SWRrfcWhdSaBcNCkWAG==', 'W6hdPSonW5VcOL9koM0zWQ0vy8k9W5pcRtxdG8k2WPBcHW==', 'WQugW4ThW4pdTSklgq==', 'WRqeW55x', 'rJKmbq==', 'BGtdJWi=', 'WPGJW4mnrKu3W6WadG==', 'W4ilE8kupvmWea==', 'WPFdVmofW5OewmoNWOG=', 'W5tdKZ/cQaiClSk4W4Ww', 'kKmhWRhdL8o1xq==', 'F8kWWQ3dRq==', 'jZ50o8o7WR3cMbJcHCo6ACkhfJ9YdW==', 'W6HGF8o6WQ/cOw0xwMe=', 'WP8JWPXmhCoAbIu9WR8F', 'yCoaWOzjW7qsfW==', 'WPWKW5qh', 'W7jeWPW=', 'usGFg053W4dcQ008W7/cOG==', 'i8oNFSkGW6/cVCo2', 'ACkqqSo0DKNcSmki', 'p3tdK2jSAWpcIG==', 'W5FdVXJcUsmX', 'FSkhx8omy2BcQSkbiLu=', 'W5KUW6yYW6/cVmolWQBcPCo+fCkRWO9QWQy=', 'WROMC8k0m2WUzmobputdS8kNWQ4lWO5k', 'WR8kuSkhoKu+DCor', 'WQ8DqmkzeM0jvW==', 'W7tcU8kVW6W=', 'kmoJFSktW6dcSSo6ka==', 'W6dcSCk+W7TKW4nftMldVGtdPb8xgMxdNSosWQVcLmoT', 'WPy6W7xdLZpdPh9wiKVdJa==', 'W6eKdXe8', 'rs4zn1bMWO3cQ1WQ', 'AvZcRq5ZWQ7cImoG', 'BLxcPSkmj8kaW5xcUHVcUJyVF8o0AYrsW6JcQ20=', 'WP/dVmocW4DiD8o6W4vidSkGbHGVWQldV3S=', 'hSo4WPdcKmo2lLRdI0pcJNmHBCkLW5bKWPK1WR3cKxn6W68TWRu=', 'WRynW5HhWP3dG8khbJ7dR3yoWPZcQbldOq==', 'qmocWObE', 'rs4zo1b3', 'zmk0ymoJrgBcL8kKhxm=', 'W6VcT8k/W7S=', 'W6hcU8k4W51VWOzQzK7dGa==', 'smkgkCkPBxaEjdqZ', 'W5RdRGZcTCoLWPS=', 'W7PVW7qIW74=', 'AfBcVbu8WPtcVCovWRilcCkhpJq6', 'thVcQLNcRNjRoshcSq==', 'W4ilE8kknuSNgM44W4ZcPCoiWOddTr/cTG==', 'A0hcQs5ZWQtcNCo/WQDhdSksoIe=', 'WPJdI8ofehnDWPtcMJxdKCoieaK=', 'W4JcKsldM8oJhI5ACG==', 'W47dHqRcGqulkq==', 'F0xcQWC8WOhcRmoa', 'W5xdLYZcIa4somkyW4yvra==', 'W5pdNYJcHH4ComkX', 'x8kmkmkoB3qikse=', 'W7XGF8oPWQdcRhOE', 'x8k0WPZdQCo/WPtdQCkyzeDMxK3dJmkUxq0=', 'W4ddKZ/cPaij', 'W6dcSCk+W7TKWRDMFuZdLLddIHKxf2hdN8owWOdcM8oZWQX4CG==', 'dmoHimosW4ldTJ7cNLe8mW==', 'rKu2WPNcVmk0iCo9WRO=', 'W5ddLYlcMuWBi8kMWOKDwuqDFNhcVfldN8kllmkCaXpdL8kplW==', 'WReFWORdQG==', 'ACkqqSoREve=', 'dCo8WPBcP8oHnqO=', 'W5a1W7qM', 'W4CgoCosWP4EtCkvW4eZkSoaW4riW4Gl', 'zMxcIYnpWOtcRSoAWQD/', 'xCkml8kpzJe+crGAzd/cHcdcMmkxn8k6W6RdTmoG', 'W5rwWPJdNConW7LjsmozW6dcTf3cLmkF', 'W7tdQSonW5hcTWSOeLaXW6af', 'WQZdKCkcW4NcVq3dJM7dQq==', 'F0hcQsDYWQBcNSo/WPjp', 'W7PHB8oSWQ3cQwSEtuXtWO0=', 'dCoEiGu=', 'WO8eWOLZoSotjsiIWQKiWOq=', 'xmonfSoqCLpcQSkbo0iV', 'W7bNWQrHbXBdOqtcISkT', 'kCoPEmkMW6tdVSohcmkJd8kDWRpcVIORWQldQ1FcRcBcMq==', 'WPyOW5mYreG2W6y=', 'WPpdQSobW59gCmo6WPy=', 'W5DCWPNdUSoyW7LTrSoA', 'tr0OigXkWQtcHW==', 'yGNdMclcLCoTF2RcQCkQAW==', 'WQiAWONdJebXWRhcQCoMvmkO', 'WO5bWOJcIexdRSoaWQWsWOXmdSouWO8=', 'WQelWOhdO01G', 'WO5bWOJcIKVdOmoe', 'W4WDrmkNjw83eguBW4BcSG==', 'WPSeWOLVcSoLgG==', 'fmowoqLBaq==', 'rvWTWPddS8k5imoT', 'W5D2WQRdMCoHW5bn', 'W6xcT8k+W7TTWOy=', 'W40yr8oIguW2ehGCW4RcT8onWOC=', 'WQ/cRSoSW6y=', 'WPOAW4JdS0ddHKn4hNO=', 'WP0fWPL8emoVcs8MWRuv', 'WQBdNCkfW70=', 'WQmnW4T+WPZdMmks', 'W6xcKCk+WOZdV8kxbG==', 'W6BdK2S5W7TcWQRcKG==', 'w0WRWPtdG8k1j8oTWRtdRCoRFM7cGmksW4alWOe3W7azjeusamkuWPSTnIxdHa==', 'W4ygkSoRWP8fwa==', 'wCkXWR3dTmo/WPddRmktra==', 'xmkhWQ3dK8omWRe=', 'BmkAB0C=', 'BKNcQdfR', 'qY8jmvfVWO/cSgKWW7hcUHuc', 'W6/cUmoSW6T1WOjPA0ldNum=', 'WQOyW43dO01GWRRcO8oO', 'q1tcNxRcKvqzgbtcHexdLd4imGOBbwVcLuCeWPruWR3dPSov', 'xmkgkCk6yN0jlq==', 'W713ASosWQtcK3SAwga=', 'kSodWQS6W591W5hcVdzZ', 'W7/cGCkAWOtdO8kkqI7dJmoJy0q=', 'E1VcOSkkySksW6tcMW==', 'WQ4PW6LVWR3dTmkWps3dMG==', 'W6ddMgSaWQrSWRm=', 'w8oqWQPEWRPvAmkWWQ59', 'rNGQDr3dNc91WOddOSkJW7NcN0hdKSoLlCo+eSoXiCoWkbtdJa4=', 'WQxdT8oDW7jQ', 'W6LSBmoxWRxdOgKuuhe=', 'W7xcQSkJW6HmWOPKFutdG0ZdQb4C', 'W71MWQrVavFdTXNcJCkQE3pdTH8zfa==', 'vv/cIf3cK1bBhbtcGq==', 'WOBdQ8kqW5JcTa3dMxi=', 'WRlcQmoZW7ZcGCoxAW==', 'rxJcNwVcMgfveqJcGfm=', 'vCogWPnRWQzpvW==', 'W4BcMIddVCo5cZLp', 'q8kNWO3dNSoJWPZdR8krvuW=', 'WPJdVCkrW4bkDSo+WOamcCk8ebCIWRFdSgH9', 'W7zSEmoC', 'rYumefjMWRlcP1OXW7pcOXCv', 'WPhdT8ofW79gESoVWOL8dCk0hre4', 'W5m4pZGwaHRdOM/cG8k5W5eNaZ1uoSoEa8kbzvdcJtRcIWBcGW==', 'tLpcIhVcLvbxeXq=', 'WPBdQmo0lvj6WRNcRYpdQW==', 'W5ZcKsldNCoLhJ5rCSkB', 'kfOSE8k7W43dPLfEW5hdLmow', 'kN7dLujMjW7cL8kSyYr/W64Y', 'vSkklSkp', 'WP7dK8owb3naWPxcJuBdMmotbbicpa==', 'zqJdNrxcImo6ExldQ8kXFfKprCkhW5mup8ob', 'W5xdKYZcHb8jkCkMW6OtwWGmD33cOW==', 'WRKVW5emWQ/dTSo0', 'WQS+W7P8WRZdVSkMmq==', 'tmkSDwWkWRnphCky', 'iKxdQJbJWQ3dKxe=', 'WPy6W7xdLZpdOwrsjq==', 't8kcrG==', 'rLy8WPhdUCkEmCoQWOtdS8o7DNVcICkYW6LkWRuQ', 'hSoMnSo4W5RdP33cNeC2jSkq', 'WRKVW48cWRFdTmo1WORdLxWpjrZdLG==', 'cSoGmmohW4pdTIRcTf00j8kgka==', 'W5byWO7dU8oE', 'l0C9ECkCW4tdKufFW5pdMSox', 'W5qVW48QWRVcHmoVWPNcOCk9b8kUWPHO', 'BCk3v8orCNxcQCkmneiV', 'W47dHqBcIaiia8kKW4WC', 'qua5WRtdS8kKp8o7WQG=', 'WOtdMmoungbyWOxcMG==', 'W67dUb/dMCk6W4ddG8kDWRFdUqNdPZ7dUG==', 'C8k9WRRdG8kpcIOQWOrFwmoHW5mwgIO=', 'W75SWRradqpdTWtcGmkoCwBdSbKthIW=', 'CqZdMWtcN8oNAchcRCkSyrXlqmkBW4ql', 'C8ksE0enWR1xsCkwcvPesNWbbSos', 'z8kgFSony07cOmkudeqPW6RcQmof', 'W6hdJ349WRnqWRFcNSosWP4=', 'W6pdU8oEW4/dPW96hKa9W64cACk3WPFcOcddH8k4WP/cKq==', 'A0hcQtr9WQVcICo2', 'cSoGmmogW4/dSI3cML0=', 'W4JcP8kCWPFdTq==', 'W4bqWP7dSCoeW6G5tSoEW6ZcRuC=', 'WRaBWPNdIKz1WRdcRSoHxW==', 'WRJdKCkcW5VcTG3dNg3dOSo4', 'WPddMmoob3nvWPW=', 'WPSeWOLPgCoMhYe=', 'W7/dO8ocWPX2DWZdRGeRWR/dKmo9W7RdRw/cUXPrW6vV', 'lu4pWPVdNCo/ASk+W74uWQOm', 'W5jxWOJdNmogW7nPq8ofW77cRG==', 'zvFcNa51WRhcMq==', 'WPKOW5/dNNRdS3q=', 'W6dcSCk+W7TKW4npsMRdTWtdPb8xgMxdNSosWQVcLmoT', 'WQmnW4TRWPFdKSkYgW7dP24lWPhcPW==', 'saO7m21aWRlcI2Kn', 'W7ddOSogWPPHsWddQemLWRxdSCoZW6VdUZVcOq==', 'WRmrWOhdTK97WRW=', 'rwxcSSkPlSk1W5pcUW==', 'W40WW6y8WOlcHSoPWPlcJ8kUg8kOWObO', 'uNi/FWVcIbLgWOxdHSkFW5RcTg7dPCkU', 'duyAWQ/dIW==', 'W4NdKYJcHG==', 'W7tdIw05WRHKWOdcISogWO/dMdy=', 'WOm+W6RdPhldQwru', 'CCkbEuagWRfxsCkud11dbNuAamorWQBcQNNdUSk/m8kN', 'idvIfCoRW7hcPdtcGmomjSkuht5HceFcP8kJqGS=', 't2e9zaRcLrHrWPldImkFW5pcPg7dQmkMkW==', 'A8kYsMu8WPfXimkGna==', 'r3iSuXBcMrfDWQpdLa==', 'Fv/cOCkjoW==', 'usOlfX5ZWO/cQ1CT', 'W5O5W7mtWQ7cG8o/WOu=', 'W4VdKCkBWORcOG==', 'r0ePWRddS8kZnCoYWOhdR8o+BMRcNG==', 'amoSWO/cH8kZkrNdH0tcLsKWymk6W5fVW494WPVcKwH6W78RW7rqW6VdKmk2', 'W6ygBSkWh1aHefCC', 'ke0SE8kLW57cHu1zW4ddLSoi', 'CCkWWQZdRCkwaW==', 'tu0UWP8=', 'W4/dOmolW5RcQaC=', 'WOxdLmohcNuuWPpcNGRdNW==', 'wCkSWO/dVSo/WONdQmkpeeL4svddMSkZ', 'W4VdKY3cMuWElCk4W48=', 'WQ0BW7DbWPRdNmkhdtZdRw4lWOJcRa==', 'pmoLEmkSW7hcQSkVjmkwlSoqWQm=', 'W5CYoHKsaLNdOwJcJCkL', 'vCogWPn3WRTdrSkSWPT/cCkKq8om', 'ySo2WOLFWOa=', 'b8osjs5FfmkEWOddHmoig3dcTbTarbS=', 'mmopWQ02', 'W4qkA8kem1eX', 'kh7dKKnVyHJcMCk4', 'W7NdRW7dSCk8W4ddLSorWOpdUH3dVdFdRwiTW57cPSkHASoxW4nAFa==', 'DSoiWQ56WQW=', 'WOxdMmohc3jaWPxcJsxdMmongH8ulmk+', 'a8o3WPtcKSoHlH/dMHhcGhqWASk7W40JW5PYWOxdNNi=', 'WPGJW5ebv1aMW7fshbldRZ06xW==', 'WPKzWPHCdCo+dWCRWRCaWPhdJmog', 'q1u5zr3cRbbvWR/dGSkb', 'W6ddRmolW7dcRGTQffWeW6ifzCkNW57cQY8=', 'W7jRB8owWQlcOxSutxy=', 'iKxdQJfNWQddLhTx', 'W4pdHcRcMKW1cCkvW61DDsuNwZ7cRH7dNmknpa==', 'jXnc', 'omo8WOBcGSoWpW==', 'qv/cIeJcJ15j', 'W7XNWQfQcblcTqpcNCk/EJRdUWWthgjqW4dcJYrpW4JdN8oKW7BdLq==', 'nKCTCq==', 'qua5WR/dTmk1n8o1WRpdRmoN', 'p8opWRGeW4O5W4ZcUa==', 'W6xdVmotW5tcOGS=', 'vCkSWPJdUCoHWPJcRCkvvuLUff3dJmkPu0JdPmkRaCkLWQmJW7zfW4lcHW==', 'q8kHWOVdSSo9WONcRCkure1Nsa==', 'WPC+W6RdOMhdQMe=', 'a8oQWQRcMmoNmr/dKxdcGNiRC8kP', 'WPCIW5uhqaqbW4i7meddVJ0JsmoOy8oNWO/cJSkH', 'WRy5W6yzWRBdRCo1WOdcTgSuBa7dMSoQW6D/W5FdHq==', 'oKO6vmk6W4tdKq==', 'W7BcRmkLW7z1', 'W4u1ldmkeXRdO37cH8kWWO0=', 'W5qJmJyFeW==', 'oeixWRldLSo6s8k7W6Kt', 'WObxWR3cQepdU8oe', 'WQ8OD8kYDMixqW==', 'luGrWPtdNCk7s8k4W6GoW6yikw8=', 'aSocpqPtfa==', 'CSkwAgebWRnbbCkvba==', 'W40UW64RWRVcRmoIWOhcLa==', 'peGrWPVdNmoprSkeW68fWQmmlG==', 'W5WnoSosWO4lxmkiW7aH', 'qv/cIe/cMfbjhX8=', 'zmkDFuydWRCdaCkvauWochehdmkbW6xcOxBdS8k3imkRD3bt', 'pgyQWQpdSCovBG==', 'W7hdQmoaWQ9LBXZdUq==', 'WQ8lWQHpcW==', 'WPy0W6ZdKxBcPvnWb2pcN8kiWPtcOWRcNCokhKNcS8kZ', 'v8kNWO3dL8oIWP7dRmkryerRqLRdNW==', 'mCoeWRO3W5KHW5ZcR3H2WQaIsMtcOsXVubdcKmoN', 'W5O5W7mxWQRcJSoMWRNcGCkP', 'WRSSDCkeiLyUFSoe', 'WPGmDCkTma==', 'BvtcTCknlSkXWPtcObNcVIziDmoHysetW6xcP2BcVK3dSmkghGP8', 'sCkcoSkj', 'W4O4sSkqdNybma==', 'WRC5W7mOWRRdUSoaWPZdP3ypjqxdNq==', 'WPPbWOJcIgJdLmoUWQyKWPniaW==', 'WQtdNmogb3fBWPNcKri=', 'W6/cOmkjWP7dTSkUdIBdGCoJFa==', 'tYiEeq==', 'W5igkSoTWOWgxCkc', 'WPmZW7q=', 'W4VcGCk6W71IWRvIy0tdKe3dSWKItLe=', 'CmkSWRldOSkFeG==', 'W7FdU8owW5BcSZXNf0SM', 'W4VdNYxcIa==', 'dSouWQu=', 'xmkgkCk7zNamjZ8=', 'cCo3jCoMWORdMXJcThD8cCkIeINcV8oIdMFcPCop', 'W4ddKZ/cOqmElCk4W7KEvH0lza==', 'EeJcVCkbnG==', 'tSkqomomA3GBidqKmhZcMYhcJ8knkSkXW6NdV8kZW6/cO3KVWQfv', 'sWtdIapcKSoW', 'EeVcUGvWWQlcTmo8WOnacSks', 'WRyiv8kwbwCvwCoZbG==', 'WQm5W7mOWQ3dVSoYWP/dSxS=', 'a8oQWQNcKSoQcGJdJulcKMmM', 'WQqBWPNdH0fGWRdcRCo8A8k/WQxcNmo5bx9Q', 'rs4zjvTIWPdcRvC=', 'WRuFFSoOWOWmtCkxW607kmoyWPWj', 'W6LSWQX+dqq=', 'WQtcQmoTW6BcG8kytraMW7dcG8kuW5ZdPrrQBmkYa2ddQG==', 'WRakWP/dPKzZWPhcT8o3t8k/WRS=', 'W7/dQ8kuWOPOBb7cVfyRWQhdICo7W6pdUq==', 'W6HTzmol', 'W6/cRCkiW7DZWO5Myv8=', 'zSkwAhaoWQbedmke', 'WRSSDCkbn0GYDq==', 'W5igkSo3WOijsCklW5i+j8ovW4nB', 'WQq9W7ukWQBdQ8o5WP3dSW==', 'WPddMmoulM5xWPhcKZBdLCoadXGh', 'W5emk8ozWOepxmkgW7i=', 'WPyOW5mOsKCIW68IeqhdPdC/', 'rNGQDr3dNd51WO/dQSotW5xcUwhdOSkSoSo4e8o7oW==', 'gSo1WOpcJSoEmXNdML7cKw4TA8kP', 'W5S/ltK=', 'W5KGoYGidL7dR17cJCkXWPS3aZPAFW==', 'W6JdV8oAW4RcTrzShGq5W6qyzCk+W4lcQwhdJSk0WP/dLmoGnsm=', 'r3iSwHFcNX1yWPBdI8ksW4/cS30=', 'ftn+', 'W6hcU8k4W514WOzxyfJdMLddRH8x', 'zSkwCKeDWRnp', 'BeeZWPVdQmk4', 'w0VcPSkB', 'W5vwWO3dRmobW658vmkkW73cRXtcN8kyhMvxW5/cGG==', 'WRm/zmkLje0JDCkdp1xdJSkVWQuBWPCtWPtdKdhcHSknWOn0', 'WRVdJCoxW79iASo6WRzedSkHmb0NWRm=', 'W6P9WQ94kr7dTHNcL8kUDNRdTWG=', 'W58Icmo6WR4PESkUW5ig', 'W7tdMgSwWRDOWQBcSmotWP3dHd4v', 'WQpcO8o7W5hcG8oaCsavW5e=', 'WRu6qmk7p1iI', 'qv/cIftcKLjyhchcIudcGJKB', 'WRm/zmkLje0JDCoWoLxdHSkY', 'dmo8WOpcG8oMkb/dMXhcLwLIyCkLW41ZW5v8WPa=', 'W5a5ldKFm1VdUg3cH8kPWRmSdd1uB8oqkmkoBfJcNJy=', 'WRC5W7mHWQZdVmoXWP/dHhmAnq/dGq==', 'kZnJfq==', 'uc4Bf0XWWOxcPHK/W6dcTbudgLhcP8ovW5ZcQw8=', 'WPddMmoungbyWOxcMG==', 'yu3cRGe=', 'W6VcKsxdVCo5c3XyDSkyqmo+', 'WQxcOSoRW4NcICoBzdK3W5JdGSkoW5BdUq==', 'WPy/W4yateeTW7CGgapdQq==', 'WOnBW4XjW58=', 'FKhcUGTVWRpcMCoHWRrka8khptiQhW==', 'xCkRWORdUa==', 'B1/cOmkMlmkG', 'WP8tWPHEdmoVjYSYWR8=', 'ceGRWQBdOG==', 'WP7dK8oec2jvWOtcKbtdIG==', 'WPhdT8ofW6rmEmo+WOPc', 'WQ0BW75cWOFdGCkh', 'W5uupYKFn1BdQ3pcH8kV', 'W6hdKM0ZWRmJWQhcKmorWOlcLZOiWOC=', 'lfpdLGL2WQRdGw14WOdcNcbRWPi=', 'WRKYW6meWQddVSoKWPZdPMW=', 'WPipW4yxqgeTW7CBcrK=', 'W5WqcmoAWOedta==', 'r3iSubtcKX1a', 'W5qVW4yPWQBcMCoV', 'mJnZhCoTWR7cMr/cTq==', 'W5zABCo5WQ3cOwGi', 'iJvLfmoIWRtcMbdcSq==', 'uCkIc8kTufiUaqed', 'WOtdS8owW5y=', 'WQK/WRVdJNTxWOdcI8ouBW==', 'WQmnW4T4WO/dM8kxeq==', 'WOimW6eH', 'iSoVECkM', 'qCoaWPvsWQrub8kPWR92bCkU', 'yuNcLCkdk8kIW5e=', 'W4rCWP7dTmoqW4H2DmojW7VcPvhcLq==', 'WQ8SDCkbn0GYDq==', 'qv/cIe7cNf1mfq==', 'W5tdQSoEW4RdP004', 'WR/dLCkeW7NcVrJcNMJdTmk8C8o+qmo8WONcJq==', 'ntLIh8o+WQxdJbJcTCoTA8ke', 'WOrnWO/cPW==', 'yvtcOSkkmmkGW5hcULZcVJavECo3E2XqW6NcPgFcQa==', 'wSkdWQ/dMSoEWR7dN8k0yhW=', 'k3tdK3DIAXNcNq==', 'W6VcH8kCWRVdSSksfYi=', 'W5rwWPJdISorW7j9qSoyW4BcSL3cNmkyaW==', 'W5O5W7mjWQdcJmoRWOZcSmkYeSk+WOT/', 'WOtdMmouj29vWPlcKWpdNq==', 'cCoziHjxdSkiW4/dMmo3awhcSqPDsGu=', 'WOtdICosc29t', 'r8otWPDEWQyarmkOWQ5Gha==', 'pKa/Cmk5W4/cHuXiW4tdN8kuxCoAW4X0WRNcVZ5aw8kjeKT+wcu=', 'it9Km8o3WRtcVb7cSSoHCSkEht4=', 'WQqBWPNdMuL4WQFcPW==', 'W4fsWOVdVq==', 'v8kckCkjBxif', 'WP/dOCo5W5XDCSoRWPXTaSkHdqiV', 'WOm+W6RdT33dPhnDk0O=', 'WPddGmoWW75SrSoaWQb4pSkandalWOldM1rlW73dRetdQG==', 'qmk4WRNdQ8kycsOCWQzerCo0', 'cCoefqLedCkDWOhdIa==', 'tGldKa7cICoNAG==', 'z0ZcSCkDmmk9W5dcRs/cTYSbyG==', 'W7RdVHNdVmkLW5FcGSkyWPpdSaxdRq==', 'W5jDWPJdSCkzW51WsG==', 'xmkgkCkGBhiDjae7jsxcJJW=', 'x8okWPry', 'W6ddRmolW73cQrPLeKeN', 'x8k0WPZdQCo/WPtdQCkyeevJvvBdGmk1u0JdO8kPcmoHWQeYW6y=', 'dCo8WPBcOCoYnG/dJq==', 'd8obnbrecCkyWORcNmo2gYpcRGXgwXddH8kVjdDaW7nWaMCS', 'umowWOTxWRfu', 'W6ddRmolW6/cOH54feO=', 'Ca7dJGJcJCo8pgJcV8kGFGO=', 'bmoRimo4W4NdSINcMKeG', 'kgpdHLyJvc3cVSknoMjYW6y4W6i=', 'W6hcU8k4W5rUWObMy3VdN0xdVHul', 'WRyZW7uoWQBdI8oXWOhdS3OphWVdLCo8W6nQ', 'WO5bWOJcL0NdV8oeWQuSWRnedCou', 'W7faWOrn', 'c8o9WOBcTmo7pXNdG1pcJN4=', 'AmkuCKSDWRD3cmkcb01v', 'WPusWRfqg8oRbHqOWRSuWPxdKa==', 'WObcW5ZcQe/dUCojWQeU', 'W6lcRmkTW68HWQTctM/cNgBdHJK0xMRdHSoAWQpcIq==', 'WOqZW4ScWRtdUSoIWRddTwWE', 'zSkwAgewWRDZbSkdcvXibx4=', 'WR0eW7FdUNBdPh1fjG==', 'l1pdHLjMvWdcMCkXF3y=', 'W43dTX3cRd8+hSkDW7KM', 'W6xdPSoBW4e=', 'W4uZkHKwbLtdNMVcHq==', 'W5iKpY1Aa1VdPg3cH8kVW542cZnxAq==', 'WOpdLmodcuHAWOtcMHtdJ8oagG==', 'v8kNWO3dI8o/WPldVq==', 'W7rGWRnR', 'cSoGmmoFW4VdVJG=', 'W7ZdUmozWOKKCaRdS1q+W6ldKmo3W7VdSspcRHbpWQP1WRigfmk9naHBAW==', 'WPddMmoulgbzWPu=', 'WQiAWONdGL14WQBcQ8oasCk/WQBcKCoIg34=', 'W5qYW6mSWQZcJSo+WO/cKSkT', 'D8kHWQ7dOSkvdYOW', 'u1aVWPxdSSk3', 'BLxcPSkmj8o0W7BcItxcKMieECoUBcvhW6/cP2BcQq==', 'W4ddKZ/cPqujlSk7W5eIwbChyNFcPXW=', 'WQi9W6aiWQhdSmoKW5pdSNyjkuRdN8o2W7bG', 'vsqFhLPxWO/cKvORW7FcTb4=', 'WRabW5XfWQFdMCkweq/dUhSo', 'ixJdLei=', 'W5rwWPJdKmoDW6H7smosW5NcR0FcKSkfbhPv', 'ohNdIfnIFW==', 'WReGCSk0', 'W4JcKsldJCo4gI5tDSkssq==', 'vmogWOzpWQfsqSkZW6TNb8o9qSoxuxmNW71F', 'W7n8WQ14ratdTGtcJCkQmwFdVbSvhtrwW53dGsHpW4JdLCoJW7NdImocma==', 'W48VwCkdd3Wxpey8', 'WOnLWQRcHxNdJSoZWOKsWRq=', 'W7ddOSogWPPHvWJdRKyVWRNdQSo7W7NdVsFcUrTEW68=', 'WPyOW5mTs1a=', 'iKKhWP7dM8o6xCk4W74e', 'x8kklSknyx0zgJq0ld3cMsNcMq==', 'W584oJmzbK7dPxJcKq==', 'WO1wWP3cSWRdNSoGWOyhW4blg8oqWPRcPW==', 'W7VdPmohWPO=', 'W7xcVCk+W7fXWPCNzL/dLKNdTa==', 'v8kNWO3dJCoSWPhdUmky', 'WQtdNSobecegW4a=', 'dmo2WPdcLmo2EGNdIvFcHcyYASkLW5b3', 'W5ynFCkRleTLhginW47cPq==', 'u3qQFWJcIfXDWRldGSkEW4u=', 'WRy8BmkNDLCKF8owjHpdKSkJWR4bWPzfWPxdJ3BdJSkpWPjUWQddJZ3cKIC=', 'Dmk2WQZdRCkFlcSUWRa=', 'u0CVWPxdRmkKDmo3WQxdPSoYza==', 'W6ddRmolW67cPHn9hG==', 'W4ummSocWOOfrG==', 'v8kNWO3dLSoSWO3dG8kCxu0=', 'WQiUW4ywbrzZ', 'p3tdK2bTyadcNCk7', 'W7HgwmoVWQ3cOxyEtq==', 'WQZcQmk/W7BcHCoxDtbhW5ZdISkdW5ddOXfTE8k+', 'W6ddRmolW7tcQbXPf3q4W6WpACkH', 'W6dcSCk+W7TKWRDMFuZdLLddLbeFg3JdKW==', 'W4ddKZ/cVG8pkCkXW4CHxH4l', 'zSkwAgGaWRfcbCkGdeLyd2i=', 'w8oqWQ9uWQblqSk5WOPWhmk0umoB', 'DCk8WQRdGmkBcZS=', 'h8oQWOFdL8o7mX3dGftcKNjIDCkJW41WW5b/WOxdLcb3W6OLW71wW6a=', 'W4NcMYtdU8oUxX58xSkYdmo4W5/cOG85qmkVW4hcPu8=', 'WPSeWOLZf8oPcYGuWRymWONdH8oq', 'kCoPEmkMW6tdVSoTiSkgmSkDWRhcUcK=', 'W6ddMgSgWR9MWRtcVSoBWPZdMZ4s', 'WRODW5eSWPddNmocWRRdHeS=', 'W5eZkHmueW==', 'vCogWPnSWRfbv8kVWQu=', 'W4BdVXK=', 'FCkwrmolz1hdPCkeouiWW7a=', 'F0FcRWTSWRpdNmo6WOnoaSky', 'WPpdVmoqW5ffFmkUWO1jamkXsXyRWR/dSYT7W4BdG3ldL8o7pbpdK3O=', 'W6RcKmkjWOddTSkkcYRdNq==', 'WOxdSCodW5PzBCkUWOXybmk4fW==', 'WQqBWPNdIeL5WRFcKmoXv8k1WQxcPCo/a2H9', 'W7fmWOfm', 'WOtdMmoujg1BWPhcIW==', 'ACkqqSo2DLFcOSkioq==', 'W73dKZ7cNKWfFSoJ', 'imoWB8k3W7pcT8oRkmocjCosW7dcOICGWRVdUH7cQYhcNJHvi8o2t8ko', 'k8olWRO3WOStW6NcJG==', 'W7tdMgSFWQbMWRhcJCoCWP/dKG==', 'DCk8WQRdMmkBcISM', 'W60hAmkQFfO9bxOhW5dcV8oxWPhcVbFcQSkXW7tcUmklpW==', 'WPT5k8o6WRNcSgmuvNehW5K=', 'W5eZkGOiceO=', 'W7hdQmoaWRvRyaJdSheMWQZdM8o3W78=', 'bmo2amo+W5JdVJZcM0C=', 'b8oWWPhcLa==', 'W40ZW6S8WQJcGmoK', 'dSohjCoIW4/dGZhcLeO2oq==', 'W6ddMgSgWRDVWRBcMG==', 'xKVcQaX4WPJcJ8oNWPzzgW==', 'svJcPW==', 'nMpdKtnw', 'oCooWQGbW4C8W53cUcPEWRWK', 'W7hdQmoAWPX2AGO=', 'p8opWRGrW4m0W4VcUJ0=', 'WPPhWO7cRvRdUCkbWQK2WOvaba==', 'W73dTaJdVSkCW43dLSkuWPxdOWNdSG==', 'WPKiW6yG', 'W7tdUmoyWPvHDW==', 'W5qYW6yMWQZcMSo4WOhcLmk7u8kJWOT+WQWFxcWhWR0Qkbe=', 'WPC+W6RdVhldQhq=', 'W63dImoPW7NcLdXAmNqa', 'jMldVXvNWOtdIMbqWPFcKq==', 'WPBdMCoeiwLrWPpcLatdLSoz', 'tqxdQbtcJG==', 'AmkArmobCNhcPmkFkKiPW47cT8oof2BcT07cQSo6WO/dL8oCW74=', 'muNdVq1lWQ/dKhflWPxcIsu=', 'WPxdImomdMra', 'WOmSW4ab', 'Av7cSmkSkSkXW5FcOX7cSdO=', 'CaJdIclcKCoPCLxcQSkI', 'WPyGWQT+k8ojoa0uWO4=', 'W5mmlmoyWOHkE8kMW4qxfSoJW69NW79awCkXW6NdKeVdUSo9z1ZcUG==', 'eSosmG5xeSkBWOO=', 's8krnmkcD1itjd4L', 'WQm/W7ueWRpdQ8kWWPRdOhOwpW==', 'WOtdSCoVnq==', 'p3tdK2rTzG7cLmkTFG==', 'kNJdI01MyZ7cNCkRBG==', 'le7dVWvHWRtdLNvnWOBdIc14WOq8W7SGASodWPFcNbpdNq==', 'CqtdMWNcICkOAgNcOSkIEW==', 'ku85DW==', 'W7XGF8o6WQ/cTgyprKnpWPBcHcFdUxxcMSkpyq==', 'kSoOA8kNW63cU8kVjCkhkSozW7/cSYuMWQBcV13cRcBcJJjjk8o3qSky', 'WRSSDCkBouCMFmoZpL3dMCkJWRO=', 'sMulWR3dJ8ktbSoxWOhdLW==', 'avRdTs9p', 'ACkqqSoUEeBcPmkbhuS8W7RcU8os', 'WQ/dHSkxW6NdUaJdN2/dOmo5AmkWe8o0WOFcKq0=', 'W445W7maWQhcJSoOWOZcHCk6', 'W4TqzCoBWPu=', 'vu7cJNhcK1y=', 'W6ddRmolW7BcPHjT', 'WPRdLmotaq==', 'W6P9WRjHcHa=', 'oSohlmo0W5m=', 'Bw3cJW==', 'WQ3dKCk6W6FcVG==', 'w1VcSSkkmSk7W53cPGG=', 'WRC5W7mKWQ3dQW==', 'W65iWOLCltNdKG==', 'WOC6W7FdHJpdO35dBKhdKColWOJcPqhcGmkEfuFcVSkRWPvsWQLNlW==', 'pgpdGKvQzbJdMmkSDxf8W6S6W6xdMmkBoNziW6vdoCkF', 'fCo1WQuAW440W5xcQta=', 'smkal8kfC2vCisuYks8=', 'WPGtWPXiwmo6gceGWRmoWOtdH8ogWOtdSLtcPuVdISkc', 'WQmnW4TIWOhdLmkdgc3dONSBWPVcUW==', 'W4ZcTJFdQ8oUlZbCBSkAxG==', 'WPyOW5m0v0SZ', 'WPC+W6RdUNRdSxnEnN7dKmkyWPlcUqFcM8oq', 'o8oVACkUW4JcSmo7kmkqpCoCWRW=', 'C8oxWOzvW6y=', 'W4uEeq4=', 'xSk8WRddQCkodG==', 'W4WDw8kNpviOfgin', 'rIyWpSoNWQxcJXNcOmoMzCkssha=', 'WPC+W6RdPhldQwru', 'zSkwAhioWR5wda==', 'WPeiWO5C', 'CSkNxwORWPTTlG==', 'BLhcSq55WRm=', 'W44/W7uSWR/cM8kQWONcLmk7hSk0', 'W55AWP/dUW==', 'W7tcV8kRW70=', 'A0hcSWDUWQBcKa==', 'WQ3dKCkxW6RcRr7dM3lcP8oODCkWbmo0WPpcJXlcQYO=', 'WRC5W7m5WQldRCo3WPBdOa==', 'W67dUb/dKmk7W4BdJ8kyWOldPG==', 'W4K9W68QWQlcJG==', 'W5O5W7mlWQ7cGSoV', 'Av7cSmkIn8k4W4dcOtJcRs0xCSoVFYi=', 'W6pdPSoBW5/cOL9QcveGW6Gqy8kHW5tcOq==', 'WQRdMSkcW7FdTs3dL2W=', 'B8kruSoUDKFcOmkb', 'W4bwWPJdNCoAW717s8opW60=', 'W7b6WOfKdqhdSa==', 'WRCnW4TRWOddLSkagbJdQG==', 'AK3cSq55WQpcV8o6WOvia8ko', 'AKhcVbzPWRxcMCoGW5DFamoloZO6bgldKCoT', 'leinWPldISo6rq==', 'uSk3WPxdT8oOWOK=', 'iKxdQIPTWQldHxHPWO/cItb4WOu=', 'WRqUW6yA', 'WQi9W4Snuq==', 'W7XXWRr6bq==', 'WPNdKSkaewjBWOdcMKBdKCoiaH4DlSk7W581', 'WQhdTCkGW5/cIY/dReJdL8oi', 'W6xdRmocWPWKrtNdJW==', 'iLqNWPJdISo2smk5W7G=', 'W50koSoEW40zqmkiW7yH', 'W5WfFSopWOWyt8kcW7zYl8ocWOziW4is', 'W4JcKsldImo5ecW=', 'W75SWRrEbrVdOa4=', 'W5PaWQ3dTmoDW6P8', 'WOxdT8ofW6viDCo7WOa=', 'r3iSvrFcKbng', 'C8k9WRRdMSkFhIOHWQ9v', 'W4xcTqddMCoypa50r8kR', 'bmo2dmo+W57dUdJcJhiWp8kklqe=', 'WPGtWPXi', 'WOymW64WBgOe', 'gCo6WPdcNSoJlLRdGuxcHgSX', 'mL0iC8k5W4pdGq==', 'W6BdP8olW5hdQJ5HfG==', 'sxKUCWRcIbLg', 'W6hcU8k4W5bOWPDLyfpdO0VdTbKnf2pdHa==', 'W7BdRSkrW7zrACoIWOPffCoVra==', 'n2GKFCk8', 'W5TAWOJdVCkuW69XsmoEW7O=', 'DCk8WQRdNSkics4=', 'W6xdUa3dOCo1W4xdJCkdWOldTbRdSW==', 'W6tcQ8kGW7rKWPC=', 'amoyWRtcTSoagsJdOwhcTq==', 'w8ofW4DiWRHpumoGWRXYbmk2t8oqrq==', 'W4ilE8kvov41gNG=', 'W4BcHX7dT8o/fdLevSkCwmoYW4BcQq==', 'WQRdKmksW5pcRqddIMJdG8oUDCoGbmoYWPFcKq==', 'W4bsWPRdVCkuW5PjDa==', 'zvxcJW==', 'iIHXaCkUWQhcNHtcPCoHzCkdfZqLbvlcO8kTsX0=', 'WO1lWONcPKBdQmovWQeY', 'u8kUWPZdUSo/WRNdRmkjuq==', 'W6hcU8k4W4XGWPfGAL8=', 'WQ8ftSka', 'zmklBeGaWRTxgG==', 'WOHkWOJcRqFdJmoiWQ0=', 'dmo2WPdcLmo2EJldRxdcPsyHASkIW5PQW410WOBdN3m=', 'hSo2WOxcKmo/pZldH0xcIMm7', 'WPhdT8ofW6viDCo7WOa=', 'peSQxSk6W4NdHeH9W4NdMSocwSoj', 'W67dMc/cIbqYkG==', 'W7adW6edWQpcJSoTWPm=', 'ACkqqSoSDKJcOa==', 'W7f/WOGOiqtdPG7cLSkQD3tdTr4=', 'W6tdHc7cJbGye8k5W4yeuG==', 'l2hdIcDrWOldTL1PWRC=', 'W7/dVSoWWPz2BGJdSLu=', 'W7pdO8ovWPTOzKNdTeqRWQNcJCoWW6ZdTYldUbzsW6r5WRighSk6oXu=', 'pmoorCkr', 'r8kBvCohEuhcRmkmp159W6tcRmofegRcPKy=', 'WQurWP/dRe00WPdcG8onDSoWWRxcMSoJchLWp8ouphC=', 'ofmrWP7dLSo8ASkIW78dWQKe', 'qd4bhLT3', 'jfegWOxdISoYtCkYW4qEWRikkgnbWPLr', 'W6tdM8oWW63cHdC=', 'WQ8SDCksoeuLFmognG==', 'W7hdQmoaWQPNCqZdUu8zWQtdMmo3', 'WRiPW6SbWQBdQW==', 'xCkml8kpzKuDoJyYmbtcGJRcN8kwiSk9W6BdVW==', 'rSokWOrqWP1ou8kLWRLLcCkX', 'WQm9W7eiW6pdMCoaWQa=', 'WPm4W4Siqfa=', 'it9KiCoRWRdcNb7cRW==', 'jK4nWP7dLCoUrmo3W6GwWQSij2C=', 'wSovWQ8BWPftvmkLWQvNaCk8sSon', 'Aw3cHa==', 'W7tdHZNcMq==', 'W6ddMgSCWRLGWQlcK8oLWPFdLIieWPG=', 'FCkbrmolEulcHSkypLmYW64=', 'ySkqumown0pcQSkcoq==', 'qMi0EH3cIa==', 'wCkXWRVdTmo5', 'b8osjtzed8km', 'jCohxmkeW5lcNCoDbmkYhW==', 'vfVcM30=', 'W7pdTCoaWOTL', 'W4dcJMW3W6C=', 'W4JcKsldJSoQeYLy', 'W5tdLtNcHbWjBmk9W50xwHC=', 'W63dSG/dSSkWWOpdGmkdWPldOq3dUdtdUNuP', 'W67dUb/dGSkWW4ldKSkEWOK=', 'WP3dVmo2i1j3WQlcTJBdRq==', 'WRVdHSktW7RcSq/dIIhdO8oZB8oYdmo4WPtcNG7dQJFdT0xcVrVcUq==', 'WO5bWOJcKKVdOCouWQu=', 'WPVdHmkpW5tcTq==', 'ACkqqSoXy1FcRmkdkG==', 'WQxcOSoRW5pcH8ouCda=', 'WOtdNSosc3faW5dcLHldNmombq==', 'WObxWRtcQ17dPSoeWRKdWOnzhSohWPG=', 'W6JdUq/dLSk9W4BdGCkAWOxdUHa=', 'W7tdMgSgWRDVWRBcMG==', 'v8kNWO3dLCoSWPddQa==', 'p8opWRGEW4q2W5JcSqH7WRmPqge=', 'WP7dVmobgNm=', 'jKJdUXv2', 'WOBdLCko', 'WOiUW5unvvbJW6Ogga3dRG==', 'W4ZcGstdRmoIeJK=', 'W7tdNM05WQz3W6pcLSobWP7dMIG=', 'z0ZcSCkDmmk9W5dcRvZcSs1hzCoJzZXwWQBcOghcRKFdRmkohWDQ', 'u0ePWRNdSSkXnSoYWRtdPW==', 'c8oQnSoYW4/dHZZcH1q2p8kWoGldUSoWgW==', 'uvxcJNtcMwvwiXlcL0tcNJi=', 'u3iSrb3cNrb7WQddGCkaW5pcOG==', 'W5O5W7maWRBcISoAWO/cK8k3b8kUWOfJ', 'zuldVrz9WRxcM8o2WOmlbSkfFZiGbG==', 'hb0TDCoK', 'BSkfEvyDWRThdmk9furva2abcmopW7lcNxVdTSkYmq==', 'b8osjsPza8kDWOpdRmo0fxRcUb0=', 'DCk8WQRdJCkvcJeX', 'WPhcTmo4WQxdLSka', 'mmodWQG3WOSMW5hcSIXK', 'W7ebxmk2lLyReG==', 'yNVcGSkUeCkxW6BcGsZcIW==', 'eSosnG9ffmkzWP3dV8o5gg/cVW5kqa==', 'WOm/W6yFW6pcRCkG', 'zSk2uMe9WPnV', 'WPWYW7ddLW==', 'W6RdOmomW5S=', 'WQ4OzSkY', 'sgeCWQRdHCoWbmoxWOldL8oqwW==', 'W6pdNd3dLmkgW6ddSmk4WRFdGq==', 'WRuYW6ypWQ/dUSkWWPVdSx4FyWJdKSoWW7OZW5xdKZqhlSoKu8kUWQBdKW==', 'u8kWWPBdRSoUWPxdPmktvW==', 'mw8iu8kgW6NdT219W7e=', 'cCoegqLcc8kzWPBdVCo7agRcQWO=', 'W7GKW7CPWQdcHSo+', 'WOC0W6ZdNNFdKx5IlvZdMSkoWPu=', 'A2xcNLhcJMjAhWhcGeu=', 'WRuNymk0nve1CCoxnXZdHmkJWRSxWPrqW5ddMtpdISksWOC=', 'WPSmW7eLDMCrW4OIkq==', 'WRSSDCkui1y0F8oraLpdK8kVWRWhWPvD', 'jwldSubVBGG=', 'vmomWPvyWRfOtSk0WQL8emkor8oyr3CY', 'W7niWPzjnZtdHYlcQmkk', 'WO5bWOJcKeVdV8ogWQu2', 'WP0YW63dKq==', 'zSkwAgebWQzkhCkzbvTJe1mcamosW7xcH1W=', 'B0uxWPpdUa==', 'zf/cSSkBySk8W5xcPHG=', 'WO4HWPVdQKTcWRFcRSoRwmk5WQlcJmowxe0=', 'it9KoSoHWRlcJr3cKCoKz8kofYi=', 'W5ZcLYtdSCo7c3Xuy8kAqCoO', 'WPtdV8obewrKWPZcNH/dNmot', 'pSoSkG==', 'a8o3WOBcNSoWoW7dH0pcKG==', 'AgVcMsvz', 'C8k9WRRdJCksaZ0OWQjctW==', 'uCoXWQHUWPDO', 'kvipWPVdNCoV', 'b8osjtbxdmkjWOO=', 'oCooWQGbW4C8W53cUcPrWR4/rgC=', 'DCk8WQRdGSkvbt8VWPbbvSoOW5il', 'W4quWP9MWOFdG8kagWxcTdO=', 'zJ/dVGVcNG==', 'WRu6rCk4jeKMFSox', 'W4hdHcRcGaKUomk1W44xEqSAF3JcSq==', 'CSkqBK0FWQydamkebuvs', 'B1/cOmk5k8kXW4pcIrlcUc4czq==', 'W6HKFCoAW6hcHL8O', 'ESkqtSowreZcV8kidLiUW7FcSCon', 'WRSSDCkzn0KI', 'WReBWOZdO1X9WR/cPW==', 'BmkawSooCLe=', 'WQCQW55DWOVdP8kofqtdQ2G=', 'ahtdIuz3BW==', 'W7bVW6b7ebBdUW/cKCkWEq==', 'c8oQnSoYW4/cSXxcShixA8kanaRdU8oTfM/cRCosW68=', 'W4tdTcRcNGKTimk1W5axrq==', 'W47dMd3cIb4jkCkM', 'z8kQWRVcRSksdZKRWQvEq8kXW4CwhJDLESo1c3ldLHpdKhisW7u=', 'zaJdIc3cKSoRFw3cM8kPCGaoxG==', 'W6BdRCoBW7VcRXPReey7W7u=', 'zvpcP8km', 'BuGUCXVcSW5DWQhdJSkD', 'oCobWPRcKCos', 'WPddMmoumNnBWOa=', 'ie7dVWrUWQtcHhXCWOlcJgz/WPySW7HJkCoiWPZcLa7dImk2dSk2W64=', 'cSo2bYDLi8kUWQBdRmom', 'pmoJFSkxW6tcV8oJaSkelCooWRxcPq==', 'W6jgWOxdRa==', 'ELVcS8kk', 'W7XGF8o6WQ/cPwiswNy=', 'W4makdm5', 'u0ePWRddNSkjg8o4WRFdSmo6yW==', 'WQuFWOBdQGH1WRZcPCoOxSkJ', 'WQCrWONdQe00WRdcSmoXt8k1WRdcMSo/d3u=', 'W4JdGc7cNX4ukmkXWOKCweqDDxhcUbFcNCkcjSkdfaNdL8kcjZG=', 'W5ClAmkRl0SGb1ujW4/cUSodWPxdVXS=', 'W6VdQaFdUCkWW5C=', 'luyiWPlcMmo/xmk0W6C=', 'uCkMWP3dK8oIWONdPSkysq==', 'ch/dQanHWO7dLN1EWORcHG==', 'WRu6sCk4iK8IACoImuJdICkWWQ0=', 'nSofW6WHW4G6W4NcUhH/WRSKrNVcS2jVwG==', 'WPyOW5mQreKM', 'WPhdKSosawrGWPhcJqhdNmovjrWtkSkHW4u=', 'vCogWPnTWRvmuSkL', 'imoWB8k3W7pcT8oRkmocjSouWR7cUcK6WQBcV1RcRI/dIJbyoW==', 'pueSCCkWWORdTMvRW6ddQ8o0DSo1W7e5W7RcSZ9kvSkud01/rq==', 'zLxdTmkCiCk7W4tcRvZcTYStDCoOAsjqW6m=', 'CtGkuG47', 'rs4zjLTIWO3cR1GTW7FcOG==', 'WQ8QC8k+jLbNECoxn1hdKW==', 'e8ownWmwemktWOBdKSoSvgZcS09fqHJcHCk0', 'jtnIfCoIWRq=', 'W6HXECowWQ/cPW==', 'WRCxWO7dPfP1WQBcPW==', 'W6RdOmorW5hcQGPLw0a1W6axA8k2', 's8kmmCkvzh4s', 'WRnOWRVcKw0=', 'WOm5W6SSWOa=', 'WRhcPmoTW6ZcLSomjtWtW5hdJSke', 'BLxcPSkmj8kaW5xcUHVcUJy0D8oMBtHk', 'C8ouWPC=', 'pNtdGeHWCWNcISklE2HYW6u+W7ldKG==', 'W4pdMs/cIGLDlSkMW5WguGibzh3cRq==', 'zSkwAgidWR1chq==', 'DSk8nmkKzNaqpdK=', 'qv/cIeVcIunqhHy=', 'kmoJFSklW6dcS8oQ', 'W5tdGJNcHaiA', 'B1/cOmk5i8k4W4hcRq==', 'mL0wFCkHW4hdGf1SW4BdJ8ossCoE', 'WPq1W5CisK03W7a=', 'W4ddKZ/cQbuyhmk7W5OBqW0bEa==', 'kmoJFSkjW67cVCoUiCkYj8oCWQNcTdy=', 'mfpdU0zQWQJdG3XCWPdcNgLTWPG2W6yQkmolWPFdKapdNCkYamk/W7G=', 'WOxdT8ofW7zhEmoSWOLjbq==', 'W4OyASkWlLyHedygW4ZdTSosWPFdSWdcVCo0W7lcSmkBovy/WPRcHIW=', 'cSoGmmohW4VdVYJcKa==', 'W5SZW7uMWQRdJ8ocWQxcOCkAu8kKWOfJWReys2umWRy1', 'WOBcOSoSW5bOWPDLyfpcIqq=', 'dCoCWQZcSSobgZy=', 'cSoGmmoDW4xdSdZcMwm/kSkApHy=', 'vSkwFLCBWRDrfCkrf1GqwYisbCotWR/dTIdcOCoPkmkUBxvfWR/cSIeWWOfmWPZcUmojiCo5FbrlWQVdJZtcLtv/F8odyCkWW5RdR8oSoCkRWPtdVmkTuMpcO3FcJSopobNcJ2XptfBdHmkWWROifCk8ib/cJeGvjZzIWRpcHSopWQmgWQFcPmopWPSty8kQWQPbcmk9rCkZW7Hgganmqmohm8okW6NcH8ocW4TfWOD0W4meWOtdVmoRpbpdGeawW7aZbr3cH2FcTmksWRjfW5/dNSkkrHVcOWmczCkWotpcPeNcNmkyWOTRWR3dJmo0Dw4CW6TCW4ZcQSo7W5C5W6uTW5hcPt/cNSk1W4P1W6RcUmoVW4G2WP46amkZW743bbJdHvRcRfuVzSoFFHJdTCoSWQNdUSk6W7S5hmkst8oVkCogCdv2W5BdQqZdVsNdKSkhrSk0WRZcU8kzcSozWRVcOK/dQCkAl8o2W6RdNCkZWP8oW49IWOJcImoDc8odqmonWQPYWO5nWP4uccC5pCocW4BdOmotBtaXWRxcOZbtW6ZdUCo9WR89aY3cRCo5nf/cGa88W6XdgaC0W7SugMeFWOldTmkXCSofW5xcHCoFW6RdVmosW5JdI8oCWOVdH8oRWPDCEmoeDJFcT8kLp3BcKH7cUmkubLpcOH5Jr21XWOuwfCkxW7lcG8kjWOVcICoNDfLYxSkSW5RcI8kFW7xcICk/kCk2WOTiWPLpkSkClSoCjxJdJsr+W7ddSdOfdZhcRCkMW6ddI8kKWQGFiGlcGSo/nCoXW7OpBCodzvhdLrG1Fc07eWJdJ8kqW6xcPr/cLmoyF8oCv8oqWPTcw8kvW55PW7JdH8oFW5RdP0ddQ8oGWOzlu8okWRSnACk+WQ1HqSoqWOC3zwVdOSkDW6bHW5aBhCoNw3JcQmk3dmkjWO7cUSkImH8dh8oaWQiQbWPtcY3dP15PgCoHW6Lrx13dS8kRW7TtDq1bgSovW6tcMtv5gCoZFCkIWRLvW7xdJcNcSbHbW4npW7VdUmkBv8oLW4WvAhyYWQmIW4RcJrz2ib7cNcdcGmkhWPtcQqZdRh7cKhFcOsNdKbz7C27dVNZdU8opESkPxSkkzmk5W7hdNJ3cIdtdVepcNmo1W67dJu49cNxdNYKHyCoeW6tcLCkNcrJcLmkGcGddSmo1wCoNW7mJp8oJW7CrfCofW4OafSo7W5pcMCoBW6rYWQqoW71gibiXWRNcJSouWOr/W6tcNmo1tWnqW7BcRSk3bMPUWQNdMmkmh8k4BmkrW7O3islcTmkQWPvjAK5nbConW68sW7WLWRKhWOhcVeZdK8kzzSkwW7ucWRlcNdOeW7j9w8k1WQ3cTL4wqghdNtRdJJmvW4RcQmopBmkVW77dGSouWOuXWQhdOMvoeSksW5VcQCkslCkwWOddMvJcOvZcLh4+g3v9emkvW4OTW6P0WPWZWOumkY5qxSoYWOiapmo1W487W4xcLJy+g8k4E8o9xfJcR8oZW7dcG8kjcetcKq/dTrRcHclcLCogWOXpCSk9WRr0W4hcKComzMxdJ8kKyH/dOmkkW61/Dw4+W6JdJ8k6WRNcQ8oGWRHxWRxcHmoJhLmYWPtcQmkit0DQu8otgSoPlmonWQFdM8oXhsldJwqEWQq9AJysySknDqlcJSoJDMDnW75mWOJcQSkFCcVdVH7dVNdcGmo2yX/dRWf1ytjEW4b0tCoeW5BcTJH0BmofW57dVmkxB2xcHCoPW6rSvW3cLmoyW7NcOSo8t8k0ACkBWOhcOmknW6qoWRq1hqXiW5xcGYJdSXu5WQ4/W4XPsxlcOH7cRqvHWPrcs19YW646jXZcV2VdRCkUqumWbqNcLmoAgdjNtILuimkRrgNdQmooW5pdUmo0mSooimoNmSkuWQBdOw5KWOC2WPCYDmkvW74dW4mLhCkrW7VdKvpdKSksWO/dT2pcQ2NcSCkuCCk4mIhcI2ezp0yrjSobnJyDW4RcPCkjWQBdTmoHW6WpW7tcO8kWWPxcMgBdOcvvWP8qW6DYBmo1W6FcHSkRW4C7WPGsWPFdTIKxfHKXz19oW6rxF8o/DbeEW6e7qJVdMSkiWOK2WOFcKXu1W74IvmkTxXRdRIjEW6FdL3JdTdb/W7LRW7ZdSwtdUxzKW7xdJSk3q3lcSv43W7C/vSobW63dNCk2oCoWW4hdVmo6xbenkSoQoMxcLff+W4ldImo9WReFimoaWRHugCodW6uGndBcUJyaW6RcQJWuWP1vASobW6PIfqFcGCkiWRr4W5ZdKWRdQCkKCvTUz8k/zw44WQFcJSkQFbFdTmk4W5pdGSkixaqIW595vfBcLCoiW6CRWOy0W6tcJG3dJ2a7W6/cMKNcJhL1WP3dUConxSo3WOvTlLbqaSkMgLxdSmkjbmkzW5VcP8kPgCk+mSkbbYRcUXKIh8kjW6/dOu/cIMe4W4dcK8kjWOZdISk4uCo6FWxdUbSNW5tdLclcGSkFWPXiefDyFmoktSoUewD/EXuephvBWOBdMmk9y8kQs8ocuv3cNvpdT1r1WRxcKbb/vCkKW4BcTSo4W7RcPLBcGCkYhNdcRCkljCoSCSoaW74Xl8osWRu5WPqEnepdU2xdMhxdTCklW7CKWPtdSIf/smoFedOWeqnNdeLIBwXQnCkpW73dJLCbWOtcJMenWPOkxJuevheowmovihacBSkijmo6dCk8v3/cV8kEf8okW6/dK8kKWOj0nCoMosaGDSkmoSoheauhDSkUW4rqW5XcCCknzJr1W7pdH23cK8ozjCo2WQ3cOMFdTmkEWRFcHSkIqdL3obnaW5yspmo5rCk4jmkoWQf2WQ4HdbVdJxRcQSkOWPNdJ8oTWQ/dQG/cQe3dUmkQWPJdU8kbvZyGrXDKW6PzW4NcTCknW4ZcNSo4omkghXShh8kTda9YWOKGWROiWPjZnmovf8oXWPCQeYrfWQVdLIWzWPD2W5vhWRFcI8koW47dVZmfrmk2WR7cQ8kxWRFdHZvKFmohjSonWQzeiSkWWPGYi8kKySkKfSoFW55TWQNdTYSGW4JcSwxcTg4aumo8W6lcIsZdKu7cKSkzWO0Csr7dGWJcSe1pehfVWRddSmojW54nW7NcLta1hZiBWQ89eSkbW7hdGh3cLrNdIfZcPcHDWQKFWOHBhwVdNKWHz8klo8krpmoDWOhdVwaZW4f0uCkbW7yVWRi0gr5XW4BcHSkbxmopW6JcGCkYumktktNdVCkbD0WUCcLqcs1IWQxcSN4sBhJcLgddOttcQsFcU8oiW43dU2/dNCoudMRcTmkMWPiVWQGhWQCrzCktW6rwAfBcH0zdWOZdTrNcSeuVW7jzsxCicGZdTfrqiZtcNK/dSCo9eSkPWPRdISoDW45UWP8raCo1BdldU8kMWQH9W5bKWQqpv0tcOCouuq3cPCkOfSoWW5LPW5RcTWtcGunhWPuNu8ouW7JcRcNcQ8k/kCk+WQz4WQ4VzCoHWOpdU8oRyCkMySkim3nnt8oHySkIE8kpW7D1ESo8l8kQpHFcUSoLWRqjuSocw8oxWOrPW6bgb8kZW4yWs1D2rt/cUulcGmo8FufwWOTRWQ1UESolWRPixGVdVmoCW5NcOeldQd4xCSkMWR7dHmk8W5JdKsVcUSk8iSkAluldHNldLSkJjmklW4KmxgPkqmkIxJ0mWRJdHCo2A1edW4hdI3NcVuOOW63dNCo9k8kDp8kJF0RdNqXZW6BcJxddMmoIWOXXWRpcHfBcHxHhW58BW7S6drq9WOZcRqbyj8ooW4udjtVdUhnnWRRdV1HGWOJcM8o7ySkgWP8lh3mxWQ0RW6mTWPBcJxmkimkPWPTDW75Hc8k9W5vVW5vpW7hcI8k2W5Kbm8ongCoXW4CfzSkQW40/WQfMvSo2t8omnhBcI8oDWQddRSovorVcOCkmbmkyo11CuHSBfsRcMapcISo2WPLMxSonWO7cVmo2W6LjgxOAACo2g8oRW4jTxmoAjvNdO33cISkwjtlcV3LYW4WvyYVcVSoSWQjxh8olWRLYoflcQepcMuhcJSkmemoPW4VcLColzCoVWORcQ8omuXVdRmojD0jxWPiLW4mbW4T8aNPhWPpcNaDAW4JcMXb3fmkhhmoTomosWPNcNZSDWRP5i8oSASofvCkrxvW5W4ZcM8oAfSoJzSkSW7xdPSkzWOmfyGpcKgPriwCWWRtdUSkvW6xcUhNcGcerWR51W4hcQJ09WRJcJshdLSoEzHWKW7dcICk3WOpcPJ3cR8kPWQLQjSkOWQdcQbDSAmoAiCoiD8oXW6TMW5jlg8otWOzKrmo0o31AW5NdSxHXWRddMv0rymkbWPbFWQKDbSo4cCk5a8omeCoIsSoQWPZdVZqJgKPWWRVcNSkWW65TW5JdSxRcK8obpmobASkooSoCWRZdOmkSlalcIYGoaZSDhCkiW5H3vhFcTrS3W4VdRCkjWQehW4ftE8k+W4tdQNhcImkMW6ldJfXlW5yrWOhcSSkxWRxdNYOrp8k5EmkygSkfsYCfWPqRxXJdOMfaW7uEpmodWO7cQG4GWQ0vW5GnnYVcOmouguhcUNy5WRNdJh5tsmoll1/dMbDDgCksqIbaxeiviNhcK8k9WPBcRWhcHsKlW57cUd5kWOFdMmoQWPTTWRpcNayLWRtdNh5aW70VWRz+oSoKwmokW4/dJMZdU8o4WPuCWO5xWPPcm8oAuCopkmknArGFWQDoySoBWQ9WWOWPAmk+WQlcO1rlaMhcSCkUW6qTtCoxhSoWBH7cVrxdHmowb8oWWRiZEWj4DCkWzSoAW4tdVspdNwNcVt0nlCoEBSkjW7VdGSkHWPtcKvhcJe0VW4jRW7GmicTRWP3cISk9W5hdNZNdIaPEotNdHGu1W44tscnRBaHjj11VgWvJwsCnWR3cH1/dLSkRWRvjWR4EWQBcMZJdQGjvfmkVWR4qvt7dICoXamkXxCkWWPNcRmoMkmkOqCkVj19Sc8ohWO/cLSoqCIfiWRVdT8oFEHu4WQG/lSogDmksWOBdLetcJ8osW4JcQmknD8o9gxXQWQddTCkKxfxdMtlcVCk1WQJcTSkUaLdcP0dcQWNcJ8oiamofeSkEdCopW69mW6lcVHFdMKmbDM7dI3NdMCorc8osncRcSmkRW5u2hJtcSCoyCvldGqNcVJWWemoRW6ZcL8osW6OOWOvBW6n7k8kWW7ZcK8oBcb7dMZ0tc8kYtrjQjSkeebtcG8oOemkkEv93WR94eIf+W7JcGsBdGc7dQHP6WRbkWOlcO0Hzz8onW53cUgdcK8kXWRZdNSoHnsnensRcTmk6WRepcafzp0NdKmoNCargW7CFW4ZcTJGcDfJdO8kWW45WW53dTSkcW69OoxBcVmoJWOFdG8k5W4KTWPFdLXCjACkvWPddG8oSiqxdT8omdtBdIdflW5dcJfqLCSoDagOHWPlcOYvwWQPYWOBcISkEW5lcTCk1WQNdKx3cGSkswg7dP27cTtHphda8W7xcQSoDurDCW5FdOhpdG24JWO8UWOC0WPGZWPTPvXRdOCkmW7TtW5VcKhVcMmo1ou59WP3dKmkmWRNdJSkFsZBdS8oTDKdcJH/cHaFcVeRdQCkZW6FcJ8kHW6RdPmoQnGezWQG5mSoqWPq1gsqtevRcNSk8WOH8DCkJs0xdI8kIWRddQSkdW5BcR8kiW60gW5ddUJC+W6JdLmo4WO7dLmkeWPtdH8obeNxcIgtdUcFdOeCZgJVcUSkVW5VdOhHVFCkWomoyqmoaW4ZdGM1hW6SVC8kcW5fSmCoaWRf2W5dcKcjvWROTWQhdRmouCgewW7ddVCkZg8o1W4BcTwBdK1BdRCkEW4eZtmoDimoTW6lcQfnZW4m7WQLOW5/dNgpcNM0SrfeTjmkVWORcO8kIf8k1DwTjdSoIALNdHSo5W4tdLIKLW783W40kW7KbomogqmkXWOi/ASonW4TsiSo+WPakdZpcUNtcTCkShSoOuLrUww7cV8oehMFdJqH4B8oDuCkun3TnWOeQW57dSCoeW5hdHZRcPmoOvKy4mmoxxmo8CtDCW7DCCSoWW71yW5WaeCoObGlcLwRdGtFcTSofg3OrAbrgwSoSWPhcHGzGFNrGW6WQDmoYW4VcPZm0WPqTW6yGWQVcINeFvCkFqJRcQmoOwbXlj29mdSoBWP9/WQK3W4/dHSoezCoMACketZZcJxbpsNnWkG0PWOjDwCoRjuBdNSoblu9JyhORumkdWPBcVSk4rWBdLSoeWQmrv8kGWPezWRhcJa3cQs7cQmkKWPv7mbJdIMHUWOldV201W7DEWQmwghXrW6zXlaxdSe9zDw1fuh1kl8oxp8o1WRhdJbz1WQVcImkrWQmcDrlcOSkclmkYt8kKW703vSoKfv7cLmoLsSocemkQWQhdRSkJW7JdLfiIWQ7dIJfeW6FdOmoMW7hdIctdJZTQk8kVWPlcIdGkWPeMimohW77cH8klWO0SB3VcNhz8W6OYWOmbvmkiW597fd4SW5RdQSo0BSk/W5RdGuRcQLTpW4zwhgXBW6CDh8onWRXEWRtcP8o/x8oadCoJlx/dRSkTf8ontwFdKxddP8oUA8k1WRxdPSoDsCovgaVdO3tdVc8XW6BcTLeZWOJdOf4PW43cOdjnW6zvW7tdQCorWQpdKHrvj08haY3dVtxdIe54WR5zxXddJslcMCkFfWtcU8kfBmoRuI3dJtGIxCoDW6FdGCoey8oBW70GtGL1A8oSWQNcQ8kqWOxdTmkMWPRcN8kJW7NdHSocWQBdGCkwWQWJW4VcGCk3W4eeleFdOcCnlGKPzSkkrt9CumkyFttcK8kvnCopdePttrzAWOxcUthdVSkVWOldVXDxWRBcLw5cuq1uWRZcTSkRj8kCvIhcLCoGWPJcNgDvWP/dM8oVWRDmaSolWOyzW7WvpWZcMWVcIXnjWOOAgmoTa0aJBSkgW74cWPqdWQDpW4vVnMe/W7pcQY0GDNRcKw8nb0FdTmorxHxdHXVcO0FdTCoEdISyamoEjH/dOmodW4DqW6ZdLmknkun0WODVW7TaDY0EW63dTcXzWOnGyW4HWRSCWRBcMCkFWRRcImkuxCkaburmWRakwmoQdCk6BmkkESkKgSo3W6BcO8oSWOddIcJdKL7dKr7cICkHW6ddNmo/WQu9WR/dMdRcVYPgBCoYW6/dLmo7yCo1WOZdOmo0WOZcRmoeW5VcHmoPbSkWkNLBAM1qW6DjpCoSzhVdN2PQWRRdG8oIW4GcumoqWOZcM0qjeCkFWRBcLrn7owNdLSoTzCo6hsSKW4r7W6NcRSkyWQpcL3X2bWOdW7hdKvNcGCk6tSktDs19W6nEacxdG8kovxzSWRZdMSoTWQGssXddUvfQW6/cKuNcHbnQExBcMCk5bYFcO2tdTmotW7JcRSkAvSkfWPRdQsxdJLL9fGBcL8oVeSkYBuVdUSokWPRcKCkIW7q+xSoYENldL8k6dgKhvSkKW5HuWRddPSkmW7XlzSokWPvSW7jtWO8NW6xcVSkqDcxcHuxcICoDW6KCW6ldTSkfWOhcKd50rq48WR0giSkZamocWPJdN8olyCoGs8k4W7GEgCkzW4mgscpcV2LqWRVdICoHv8kTWRpcVZjZaMVdH8o8vmkidZBcGmoHjw5PhfzhvGysnYLZWOpcUvZcKSoAWO9NW6aiWOFdQfhcVmkPe0vNWQWHgCogW4CHW6TGWPX8W4X0zaLBW6RcS8koqsBdS2C3uSollSkdWQlcHvqSWQlcM8oozcevW4mTtgO2WPVdMZrLWP9xW6FcVmklW4tcOSk6s0PWsCkVadtdVI3dRhurW4rgWO7cSZJdKqhdSsxdU8kjeGtdOCo9WQRdKmosWO1pW6hcICo5WOxdOG5DW5FdVhNcHmkoWPiMt8oZWRhcSmkwW7dcI8krdSkVW5VdSLNdUtapxmo9tvu1wmkHEZbyW7WMWQqBWRpcJKfcCmkvW7FcLSkUaZ4bWO/dTmk9bHJdPhGSW4C/WO5pWQTKpCoFuwFcGK3dTCkyW6anW7ZcHCo4W5ldVcXOw8orWPmUWQH5WOlcLSk8m8oxWQmWw8o9W7pdTmkOWR5XqeWYWQNdTSoueMxcIHVcTwaPWRDjBqTRWOjHk8kfWQ0fy1pdJY5BiIPnxMpcKGVcSmkqW4VcJuBdG8kTWP3cR8ofWPnFtJtcTSkWWQugWQVdK8kBW6jxyCkKWPidWQhcKaPMWQ3dNmoIfrRcUSoKxSkKeCkGb8kuECkkcmo0W75giCkxWQBcNmk1hGxdQ2K/tCoPW6/dSmomlYZdUSoxvSo9W77dRmk+WQBcTdldTmk4kfVcTSoPWRTdt1VcQXFcJapcL1FdJNxdJCkwuLzaBCkEddBdJ8o9B8k4q1lcKYtcTahdM31cjeBcH38oEr3dV8kHp2f/wmonjmk7W44Chmk3pNnxW7H5FCocFfBcTCkWCbJcHmo7WPrPqXyvbSkvWP4xButdHw3dTHFdRZZdUa==', 'lJnKfCoMWRdcGHlcPa==', 'hSoKiSo0WORdOZlcNf0NA8kmnutdS8oTd2tcSq==', 'W6RdLgWZ', 'W5tdGJNcHaiAd8kHW5OgwaK=', 'WOBcOSoSW4TGWOvIF0tdMKRdS0Pz', 'W67dUb/dG8k0W4/dL8ku', 'W75SWRrecXtdTaFcQmkYF2ZdVb8=', 'p3ldLuHZC0ZcKCk8F2LT', 'W4ygkSoTWOqpx8kMW6W1kSojW5u=', 'WOpdMmoyfNrgWPxcMZtdNmocaG==', 'aSozFmkGW6lcImoQiCknkmouWQtcQb9/WPy=', 'W6FcSmk4W7eSWQjUyG==', 'keNdRqu=', 'W5KUW6yYW6/cP8opWQhcPmoXmCkgWQDaW7uxu20eWQS=', 'xmkgkCkKAMuEjYKhkY/cGJRcLCkrlq==', 'iKanWPJdISo+FCk2W74qWQmD', 'W4qkA8krmfyHegqHW43cOG==', 'tmkml8kaz0utgZiLitNcHq==', 'dmo2WPdcLmo2dHVdMLBcHhipBmkIW5DUW4XWWQ3dKg1YW6WT', 'E1/cOmkQlmk1W5BcPbNcUW==', 'pSo4WPdcKmo2lIxdGv/cHwm6', 'WRSSDCkEoeuKC8owif3dG8k/', 'E1NcPSkgmSkGWPtcOqJcUI8u', 'W5O5W7mqWRZcISo4WO7cGCkZfG==', 'WPhdT8ofW7zhFmoJWOXjeG==', 'jLddSwbqrd7cSCkytG==', 'B1/cOmkJlCk3W5xcPcZcSYmEC8oY', 'zaJdIdFcNmoKAwq=', 'WQqBWPNdILfXWOlcRCo3uSkKWR/cMSoJ', 'z8kCBKCkWOzcg8kxbvXSa34hdmouW6VcINNdUSk/m8kN', 'W6hcU8k4W45GWO9YAG==', 'WO5bWOJcK0/dRmorWQ8S', 'AIikgH5MWPJcSLu2W6hcUayvtLFcU8ouW5VcPMX3', 'jK4qWPq=', 'uSknoCkfyhaijYmK', 'vCogWPnZWR1urCkVWRndb8kUt8oks2WL', 'W4JcKsldKmoIcZ5sB8kVq8oOW5NcUai/wG==', 'B1/cOmk9j8k6W5dcRq7cNs0F', 'W63dRWRdOSo1W5pdKmkuWOpdVaVdQJ7dRdyOW4/dQ8kKBmoF', 'ACkqqSo1CKtcTCkciW==', 'W7XGF8oYWQdcSeeAuMa=', 'qCogWPn+WRPbrCkSWQ53', 'WQFdKCkqW6RdUbJdLMJdOmo0', 'WQyDW5ncWOVdGW==', 'W4RdNZJcJG==', 'W7ZdJmoIWRHxqdVdLxeE', 'p8opWRGCW4O4W5W=', 'WRVdJCotW7PAsSoTWOPCbmkX', 'WPZdK8oNW7j6wSoCWQX8nq==', 'W6HGF8oYWQ7cTMOwwMTj', 'WPVdU8ocW5a=', 'E8kQWPBdOCkodtS6WOfoq8o4W4eC', 'WPtdP8oDW59mBq==', 'iwy1WRBdQ8oyE8kEW5WJ', 'vSkTWOVdUmoOW53dHCk4CwWQwfddG8kKvXZdRSkRaCkY', 'W6ddSX3dSmkNW5FdH8kdW4FdTbRdRdtdV2u=', 'WPyOW5mNufyWW6Walq/dRJS5rCoUEq==', 'WRJdL8keW7FcQbJcNMJdS8o5D8oJ', 'hSoFWQiXW588W5BcS3G/W7TWxJpcIwjTsXxcICoWiIm4fCoWW7FcGmkG', 'CsGmab4XW5a=', 'n0xdQanWWRldGxazWOxcMIX4WOqXW7qTlSooWPZcLW==', 'ArJdKrhdNCo7F27cVSkXpaSowSkBW48oo8okWRShotpcGmkBeLz5pq==', 'q0a9DWJcKXj3WPxdPCksW4xcSW==', 'W5CDW5eeWPZcRmoyWQNcSmkk', 'FCkbrmolEui=', 'W5ddTtNcLbq=', 'EmkyWOJdJ8kPjqWkWPb5', 'W67dJLC/WQjOWQBcHSo0WPJdGZixWO8=', 't1tcMhhcNLbnhWpcLG==', 'rtKmfLDMWO7cTMS8W7hcPq==', 'W6BdV8orWP1Tyb3cVeuLWRJdGmo+W6JdQI7cQfvzW6TWWROveG==', 'W4tdGGldNCkWW4ldJSkfWO8=', 'k8ojWR47W5SHWPNcTcXYWR8J', 'au7dGwDVzGVcIW==', 'W7fexCo+WPlcG10YB1e=', 'WPSKWRn6kSoljG==', 'WQ4xWP7dRa==', 'kmoJFSkaW6/cQSoMoCkllSoo', 'WQa8WOZdVe1eWR7cO8o9xSkI', 'W5igkSo+WPqpEmkiW7e7mSofW4Lh', 'WRClW41hWP7dG8ochqNdQ3Cr'];
(function (nfmhvu6e, rlvzdwyq) {
    var usshc9cv = function (qkrv5bkq) {
        while (--qkrv5bkq) {
            nfmhvu6e['push'](nfmhvu6e['shift']());
        }
    };
    usshc9cv(++rlvzdwyq);
}(z3zmcqg3, 0x146));
var nfmhvu6e = function (rlvzdwyq, usshc9cv) {
    rlvzdwyq = rlvzdwyq - 0x0;
    var qkrv5bkq = z3zmcqg3[rlvzdwyq];
    if (nfmhvu6e['NBNsIT'] === undefined) {
        var udu2xk2y = function (aqm2hlen) {
            var rlsgrdcz = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=',
                ujfxs77m = String(aqm2hlen)['replace'](/=+$/, '');
            var kgmvlada = '';
            for (var nxvxzhnf = 0x0, cf7qrc2d, gqtxkpxn, q7vhhmwz = 0x0; gqtxkpxn = ujfxs77m['charAt'](q7vhhmwz++); ~gqtxkpxn && (cf7qrc2d = nxvxzhnf % 0x4 ? cf7qrc2d * 0x40 + gqtxkpxn : gqtxkpxn, nxvxzhnf++ % 0x4) ? kgmvlada += String['fromCharCode'](0xff & cf7qrc2d >> (-0x2 * nxvxzhnf & 0x6)) : 0x0) {
                gqtxkpxn = rlsgrdcz['indexOf'](gqtxkpxn);
            }
            return kgmvlada;
        };
        var qtychczh = function (yd2qbbsq, Nfmhvu6e) {
            var Kgmvlada = [],
                Sd8jdhml = 0x0,
                Ujfxs77m, Yd2qbbsq = '',
                Q7vhhmwz = '';
            yd2qbbsq = udu2xk2y(yd2qbbsq);
            for (var Z3zmcqg3 = 0x0, Rlvzdwyq = yd2qbbsq['length']; Z3zmcqg3 < Rlvzdwyq; Z3zmcqg3++) {
                Q7vhhmwz += '%' + ('00' + yd2qbbsq['charCodeAt'](Z3zmcqg3)['toString'](0x10))['slice'](-0x2);
            }
            yd2qbbsq = decodeURIComponent(Q7vhhmwz);
            var Usshc9cv;
            for (Usshc9cv = 0x0; Usshc9cv < 0x100; Usshc9cv++) {
                Kgmvlada[Usshc9cv] = Usshc9cv;
            }
            for (Usshc9cv = 0x0; Usshc9cv < 0x100; Usshc9cv++) {
                Sd8jdhml = (Sd8jdhml + Kgmvlada[Usshc9cv] + Nfmhvu6e['charCodeAt'](Usshc9cv % Nfmhvu6e['length'])) % 0x100;
                Ujfxs77m = Kgmvlada[Usshc9cv];
                Kgmvlada[Usshc9cv] = Kgmvlada[Sd8jdhml];
                Kgmvlada[Sd8jdhml] = Ujfxs77m;
            }
            Usshc9cv = 0x0;
            Sd8jdhml = 0x0;
            for (var Qkrv5bkq = 0x0; Qkrv5bkq < yd2qbbsq['length']; Qkrv5bkq++) {
                Usshc9cv = (Usshc9cv + 0x1) % 0x100;
                Sd8jdhml = (Sd8jdhml + Kgmvlada[Usshc9cv]) % 0x100;
                Ujfxs77m = Kgmvlada[Usshc9cv];
                Kgmvlada[Usshc9cv] = Kgmvlada[Sd8jdhml];
                Kgmvlada[Sd8jdhml] = Ujfxs77m;
                Yd2qbbsq += String['fromCharCode'](yd2qbbsq['charCodeAt'](Qkrv5bkq) ^ Kgmvlada[(Kgmvlada[Usshc9cv] + Kgmvlada[Sd8jdhml]) % 0x100]);
            }
            return Yd2qbbsq;
        };
        nfmhvu6e['JMHYOR'] = qtychczh, nfmhvu6e['IaZYSx'] = {}, nfmhvu6e['NBNsIT'] = !![];
    }
    var sd8jdhml = nfmhvu6e['IaZYSx'][rlvzdwyq];
    sd8jdhml === undefined ? (nfmhvu6e['yMWKin'] === undefined && (nfmhvu6e['yMWKin'] = !![]), qkrv5bkq = nfmhvu6e['JMHYOR'](qkrv5bkq, usshc9cv), nfmhvu6e['IaZYSx'][rlvzdwyq] = qkrv5bkq) : qkrv5bkq = sd8jdhml;
    return qkrv5bkq;
};
var global_print = Global[nfmhvu6e('0xc7', '8rvd')],
    global_print_chat = Global[nfmhvu6e('0x3bb', 'WUka')],
    global_print_color = Global[nfmhvu6e('0x449', 'H]mc')],
    global_register_callback = Global[nfmhvu6e('0x2e5', ']iue')],
    global_execute_command = Global[nfmhvu6e('0x3f1', 'X$GI')],
    global_frame_stage = Global[nfmhvu6e('0x4d', 'm@IA')],
    global_tickcount = Global[nfmhvu6e('0x3c5', 'SH9y')],
    global_tickrate = Global[nfmhvu6e('0x2dd', '2sQP')],
    global_tick_interval = Global[nfmhvu6e('0x420', 'KYKP')],
    global_curtime = Global[nfmhvu6e('0x26f', '2Nh3')],
    global_realtime = Global[nfmhvu6e('0x358', '2Nh3')],
    global_frametime = Global[nfmhvu6e('0x195', 'zBb8')],
    global_latency = Global[nfmhvu6e('0x445', 'X$GI')],
    global_get_view_angles = Global[nfmhvu6e('0x18d', 'm@IA')],
    global_set_view_angles = Global[nfmhvu6e('0x302', 'd9R5')],
    global_get_map_name = Global[nfmhvu6e('0x17e', '4K7r')],
    global_is_key_pressed = Global[nfmhvu6e('0x48d', 'WN@u')],
    global_get_screen_size = Global[nfmhvu6e('0x145', 'G83^')],
    global_get_cursor_position = Global[nfmhvu6e('0x332', '$%Jm')],
    global_play_sound = Global[nfmhvu6e('0x3d8', '8rvd')],
    global_play_microphone = Global[nfmhvu6e('0xdf', 'KYKP')],
    global_stop_microphone = Global[nfmhvu6e('0x1f', 'i58(')],
    global_get_username = Global[nfmhvu6e('0x424', 'WN@u')],
    global_set_clan_tag = Global[nfmhvu6e('0x1be', 's3n@')],
    globals_tickcount = Globals[nfmhvu6e('0x10e', '5gvH')],
    globals_tickrate = Globals[nfmhvu6e('0x46a', 'o4jw')],
    globals_tick_interval = Globals[nfmhvu6e('0x3fa', 'd9R5')],
    globals_curtime = Globals[nfmhvu6e('0x396', 'woG[')],
    globals_realtime = Globals[nfmhvu6e('0x2b0', '2sQP')],
    globals_frametime = Globals[nfmhvu6e('0x380', 'G83^')],
    sound_play = Sound[nfmhvu6e('0x435', 'JO&F')],
    sound_play_microphone = Sound[nfmhvu6e('0x62', 'lUAx')],
    sound_stop_microphone = Sound[nfmhvu6e('0xec', '23qz')],
    cheat_get_username = Cheat[nfmhvu6e('0x167', '2Nh3')],
    cheat_register_callback = cheat_register_callback = new Proxy(Cheat[nfmhvu6e('0x458', 'JO&F')], {
        'apply': function (USshc9cv, USshc9cv, UJfxs77m) {
            switch (UJfxs77m[0x0]) {
            case nfmhvu6e('0x41a', 'JO&F'):
                Cheat[nfmhvu6e('0xfe', '%)yI')](nfmhvu6e('0x436', 'j#Hm'), UJfxs77m[0x1]);
                break;
            case nfmhvu6e('0x23a', 'o4jw'):
                Cheat[nfmhvu6e('0x35', 'o4jw')](nfmhvu6e('0x3bd', 'hGOu'), UJfxs77m[0x1]);
                break;
            case nfmhvu6e('0x3c2', '2Nh3'):
                Cheat[nfmhvu6e('0x38a', 'zBb8')](nfmhvu6e('0x2aa', 'o4jw'), UJfxs77m[0x1]);
                break;
            default:
                Cheat[nfmhvu6e('0x477', 'd9R5')](UJfxs77m[0x0], UJfxs77m[0x1]);
                break;
            }
        }
    }),
    cheat_override_damage = Cheat[nfmhvu6e('0x89', 'SH9y')],
    cheat_frame_stage = Cheat[nfmhvu6e('0x15', 'WUka')],
    cheat_print = Cheat[nfmhvu6e('0x9e', 'i58(')],
    cheat_print_chat = Cheat[nfmhvu6e('0xa7', 'lUAx')],
    cheat_print_color = Cheat[nfmhvu6e('0x449', 'H]mc')],
    local_latency = Local[nfmhvu6e('0x12e', ')7!]')],
    local_get_view_angles = Local[nfmhvu6e('0x2ac', '8rvd')],
    local_set_view_angles = Local[nfmhvu6e('0x361', '%)yI')],
    local_set_clan_tag = Local[nfmhvu6e('0x152', 'xdk%')],
    local_get_real_yaw = Local[nfmhvu6e('0xb2', 'lUAx')],
    local_get_fake_yaw = Local[nfmhvu6e('0x408', 'kH)7')],
    local_get_spread = Local[nfmhvu6e('0x3c4', '5J(r')],
    local_get_inaccuracy = Local[nfmhvu6e('0x30f', 'G!uN')],
    world_get_map_name = World[nfmhvu6e('0x322', 'WUka')],
    world_get_server_string = World[nfmhvu6e('0x38c', 'X$GI')],
    input_get_cursor_position = Input[nfmhvu6e('0x291', 'G!uN')],
    input_is_key_pressed = Input[nfmhvu6e('0xcd', 'KYKP')],
    render_string = Render[nfmhvu6e('0x33a', 'H]mc')],
    render_text_size = Render[nfmhvu6e('0x37d', 'o4jw')],
    render_line = Render[nfmhvu6e('0x39b', '43eQ')],
    render_rect = Render[nfmhvu6e('0x44e', 'i58(')],
    render_filled_rect = Render[nfmhvu6e('0x1c6', ']iue')],
    render_gradient_rect = Render[nfmhvu6e('0xfc', '$%Jm')],
    render_circle = Render[nfmhvu6e('0x1', 'i58(')],
    render_filled_circle = Render[nfmhvu6e('0x58', '5J(r')],
    render_polygon = Render[nfmhvu6e('0x42e', 'KYKP')],
    render_world_to_screen = Render[nfmhvu6e('0x119', 'Dm$W')],
    render_add_font = Render[nfmhvu6e('0x9d', '43eQ')],
    render_find_font = Render[nfmhvu6e('0x34f', 'H]mc')],
    render_string_custom = Render[nfmhvu6e('0x2fd', 'o4jw')],
    render_textured_rect = Render[nfmhvu6e('0x303', 'fj0c')],
    render_add_texture = Render[nfmhvu6e('0xef', 'S*9Q')],
    render_text_size_custom = Render[nfmhvu6e('0x2ae', 'H]mc')],
    render_get_screen_size = Render[nfmhvu6e('0x416', 'j#Hm')],
    ui_get_value = UI[nfmhvu6e('0x264', 'S*9Q')],
    ui_set_value = UI[nfmhvu6e('0x11a', 'G!uN')],
    ui_add_checkbox = UI[nfmhvu6e('0x3d7', 'WN@u')],
    ui_add_slider_int = UI[nfmhvu6e('0x3d6', 'Dm$W')],
    ui_add_slider_float = UI[nfmhvu6e('0x2a5', 'jG7w')],
    ui_add_hotkey = UI[nfmhvu6e('0x40b', 'H]mc')],
    ui_add_label = UI[nfmhvu6e('0x1fd', 'H]mc')],
    ui_add_dropdown = UI[nfmhvu6e('0x59', 'Dm$W')],
    ui_add_multi_dropdown = UI[nfmhvu6e('0x1fa', '8rvd')],
    ui_add_color_picker = UI[nfmhvu6e('0x10', 'j#Hm')],
    ui_add_textbox = UI[nfmhvu6e('0x214', 'hUIv')],
    ui_set_enabled = UI[nfmhvu6e('0x1fe', 'Dm$W')],
    ui_get_string = UI[nfmhvu6e('0x263', 'H]mc')],
    ui_get_color = UI[nfmhvu6e('0x27b', 'hUIv')],
    ui_set_color = UI[nfmhvu6e('0x447', ']iue')],
    ui_is_hotkey_active = UI[nfmhvu6e('0x266', 'G83^')],
    ui_toggle_hotkey = UI[nfmhvu6e('0x3c7', 'fj0c')],
    ui_is_menu_open = UI[nfmhvu6e('0x3e5', 'S*9Q')],
    convar_get_int = Convar[nfmhvu6e('0x402', 'X$GI')],
    convar_set_int = Convar[nfmhvu6e('0x3ae', '5J(r')],
    convar_get_float = Convar[nfmhvu6e('0x10c', 'gFlY')],
    convar_set_float = Convar[nfmhvu6e('0x199', 'fj0c')],
    convar_get_string = Convar[nfmhvu6e('0x2e9', '[3Yt')],
    convar_set_string = Convar[nfmhvu6e('0x3ec', 'H]mc')],
    event_get_int = Event[nfmhvu6e('0x474', 'H]mc')],
    event_get_float = Event[nfmhvu6e('0x2e7', 'hGOu')],
    event_get_string = Event[nfmhvu6e('0xb3', 'G!uN')],
    entity_get_entities = Entity[nfmhvu6e('0x347', 'X$GI')],
    entity_get_entities_by_class_i_d = Entity[nfmhvu6e('0x297', 'hGOu')],
    entity_get_players = Entity[nfmhvu6e('0x409', 's3n@')],
    entity_get_enemies = Entity[nfmhvu6e('0x2c4', 'WUka')],
    entity_get_teammates = Entity[nfmhvu6e('0x2d8', 'j#Hm')],
    entity_get_local_player = Entity[nfmhvu6e('0x125', 'lUAx')],
    entity_get_game_rules_proxy = Entity[nfmhvu6e('0x197', '2sQP')],
    entity_get_entity_from_user_i_d = Entity[nfmhvu6e('0x1ca', 'WUka')],
    entity_is_teammate = Entity[nfmhvu6e('0x1ea', 'WN@u')],
    entity_is_enemy = Entity[nfmhvu6e('0x387', 'G!uN')],
    entity_is_bot = Entity[nfmhvu6e('0x255', '4K7r')],
    entity_is_local_player = Entity[nfmhvu6e('0x149', 'SH9y')],
    entity_is_valid = Entity[nfmhvu6e('0x3b1', 'X$GI')],
    entity_is_alive = Entity[nfmhvu6e('0x118', '8rvd')],
    entity_is_dormant = Entity[nfmhvu6e('0x2a9', 'G!uN')],
    entity_get_class_i_d = Entity[nfmhvu6e('0x3bf', '2N^L')],
    entity_get_class_name = Entity[nfmhvu6e('0x412', '4arR')],
    entity_get_name = Entity[nfmhvu6e('0x48c', 'G83^')],
    entity_get_weapon = Entity[nfmhvu6e('0x104', '4arR')],
    entity_get_weapons = Entity[nfmhvu6e('0x3cf', ']iue')],
    entity_get_render_origin = Entity[nfmhvu6e('0x430', 'WN@u')],
    entity_get_prop = Entity[nfmhvu6e('0x99', 'vc&n')],
    entity_set_prop = Entity[nfmhvu6e('0xb', 'd9R5')],
    entity_get_hitbox_position = Entity[nfmhvu6e('0x365', '43eQ')],
    entity_get_eye_position = Entity[nfmhvu6e('0x14d', 'hGOu')],
    trace_line = Trace[nfmhvu6e('0x3df', 'piRi')],
    trace_bullet = Trace[nfmhvu6e('0x32e', '4arR')],
    usercmd_set_movement = UserCMD[nfmhvu6e('0x32b', 'WUka')],
    usercmd_get_movement = UserCMD[nfmhvu6e('0x432', '23qz')],
    usercmd_set_angles = UserCMD[nfmhvu6e('0x180', ']iue')],
    usercmd_force_jump = UserCMD[nfmhvu6e('0x17a', 'hUIv')],
    usercmd_force_crouch = UserCMD[nfmhvu6e('0x378', 'G83^')],
    antiaim_get_override = AntiAim[nfmhvu6e('0x351', 'woG[')],
    antiaim_set_override = AntiAim[nfmhvu6e('0x356', '2N^L')],
    antiaim_set_real_offset = AntiAim[nfmhvu6e('0x2c1', 'X$GI')],
    antiaim_set_fake_offset = AntiAim[nfmhvu6e('0xee', 'm@IA')],
    antiaim_set_l_b_y_offset = AntiAim[nfmhvu6e('0xb9', 'G83^')],
    exploit_get_charge = Exploit[nfmhvu6e('0x3e1', 'l1WZ')],
    exploit_recharge = Exploit[nfmhvu6e('0x1c1', '2o5F')],
    exploit_disable_recharge = Exploit[nfmhvu6e('0x16f', ')7!]')],
    exploit_enable_recharge = Exploit[nfmhvu6e('0x2a', 'j#Hm')],
    ragebot_override_hitchance = Ragebot[nfmhvu6e('0x243', '5J(r')],
    ragebot_override_accuracy_boost = Ragebot[nfmhvu6e('0x394', 'i58(')],
    ragebot_override_multipoint_scale = Ragebot[nfmhvu6e('0x279', 'hGOu')],
    ragebot_force_safety = Ragebot[nfmhvu6e('0x35e', 'vc&n')];
UI[nfmhvu6e('0x94', '2N^L')](nfmhvu6e('0x2', 'WN@u'));
UI[nfmhvu6e('0x45', '2N^L')](nfmhvu6e('0x25d', 'l1WZ'));
UI[nfmhvu6e('0x2cd', '4K7r')](nfmhvu6e('0x1dd', 'vc&n'));
UI[nfmhvu6e('0x488', 's3n@')](nfmhvu6e('0xf7', 'j#Hm'));
UI[nfmhvu6e('0x2ba', 'piRi')](nfmhvu6e('0x2fb', 'baA2'));
UI[nfmhvu6e('0x94', '2N^L')](nfmhvu6e('0x160', 'b(Lo'));
UI[nfmhvu6e('0x267', 'l1WZ')](nfmhvu6e('0x456', '4arR'));
UI[nfmhvu6e('0x45', '2N^L')](nfmhvu6e('0xe2', 'piRi'));
UI[nfmhvu6e('0x47e', 'WUka')](nfmhvu6e('0x24d', '5J(r'), 0x0, 0x82);
UI[nfmhvu6e('0x1b7', 'fj0c')](nfmhvu6e('0x3a7', 's3n@'));
UI[nfmhvu6e('0x5', 'SH9y')](nfmhvu6e('0x8e', 'o4jw'));
UI[nfmhvu6e('0x1bd', '8rvd')](nfmhvu6e('0x461', '%)yI'));
UI[nfmhvu6e('0x2ba', 'piRi')](nfmhvu6e('0x3dc', '5J(r'));
UI[nfmhvu6e('0x470', 'baA2')](nfmhvu6e('0x1e1', 'SH9y'));
UI[nfmhvu6e('0x147', 'KYKP')](nfmhvu6e('0x331', 'l1WZ'));
UI[nfmhvu6e('0x42b', 'hUIv')](nfmhvu6e('0x120', '8rvd'));
UI[nfmhvu6e('0x447', ']iue')](nfmhvu6e('0xf9', '%)yI'), nfmhvu6e('0x3ad', 'zBb8'), nfmhvu6e('0x177', 'WN@u'), nfmhvu6e('0x87', 'KYKP'), [0xff, 0xa5, 0x0, 0xe6]);
UI[nfmhvu6e('0x228', 'EWd6')](nfmhvu6e('0x1f5', 'EWd6'), [nfmhvu6e('0x20', '23qz'), nfmhvu6e('0x486', 'Dm$W'), nfmhvu6e('0x20d', 'd9R5'), nfmhvu6e('0x6e', 'j#Hm'), nfmhvu6e('0x384', 'jG7w')]);
UI[nfmhvu6e('0x2a1', 'hUIv')](nfmhvu6e('0x97', '4K7r'));
UI[nfmhvu6e('0x7d', 'xdk%')](nfmhvu6e('0x340', 'kH)7'));
UI[nfmhvu6e('0x15a', '2sQP')](nfmhvu6e('0x483', 'X$GI'), [nfmhvu6e('0x35a', '8rvd'), nfmhvu6e('0x11d', 'EWd6'), nfmhvu6e('0x457', 'KYKP'), nfmhvu6e('0xd5', 'WUka')]);
UI[nfmhvu6e('0x30a', 'WN@u')](nfmhvu6e('0x41d', 'd9R5'), 0x0, 0x3a);
UI[nfmhvu6e('0x11a', 'G!uN')](nfmhvu6e('0x156', '23qz'), nfmhvu6e('0x287', 'l1WZ'), nfmhvu6e('0x342', 'jG7w'), nfmhvu6e('0x41d', 'd9R5'), 0x26);
UI[nfmhvu6e('0x48', 'hUIv')](nfmhvu6e('0x433', 'piRi'), [nfmhvu6e('0x12', '2sQP'), nfmhvu6e('0xd4', 'kH)7'), nfmhvu6e('0x11', 'i58('), nfmhvu6e('0x277', '%)yI'), nfmhvu6e('0x289', '4K7r')]);
UI[nfmhvu6e('0x43e', '5gvH')](nfmhvu6e('0x1c', 'gFlY'), [nfmhvu6e('0x14a', 'G83^'), nfmhvu6e('0x225', 'woG['), nfmhvu6e('0x2b4', '23qz'), nfmhvu6e('0x20e', 'd9R5'), nfmhvu6e('0x289', '4K7r')]);
UI[nfmhvu6e('0x488', 's3n@')](nfmhvu6e('0x18', '8rvd'));
UI[nfmhvu6e('0x41e', 'Dm$W')](nfmhvu6e('0x2b8', 'hUIv'));
UI[nfmhvu6e('0x398', 'j#Hm')](nfmhvu6e('0x179', 'G!uN'));
UI[nfmhvu6e('0x47e', 'WUka')](nfmhvu6e('0x383', 'zBb8'), 0x0, 0x64);
UI[nfmhvu6e('0x489', '2sQP')](nfmhvu6e('0x2f3', 'WN@u'));
UI[nfmhvu6e('0x1ac', 'jG7w')](nfmhvu6e('0x182', 'S*9Q'), 0x0, 0x64);
var firedThisTick = [],
    storedShotTime = [],
    onShotTargets = [],
    font = null,
    fontFlags = 0x0,
    shouldDisable, shouldDisableOverride, info = [],
    safeTargets = [],
    dynamicDamage = 0x0,
    color = [0xff, 0x0, 0x0, 0xff],
    conditionFlags = nfmhvu6e('0x2f9', 'hGOu');
onShotTargets = conditionFlags[nfmhvu6e('0x3af', 'lUAx')]('|');

function normalizeYaw(SD8jdhml) {
    while (SD8jdhml > 0xb4) SD8jdhml = SD8jdhml - 0x168;
    while (SD8jdhml < -0xb4) SD8jdhml = SD8jdhml + 0x168;
    return SD8jdhml;
}

function getDropdownValue(CF7qrc2d, GQtxkpxn) {
    var RLvzdwyq = 0x1 << GQtxkpxn;
    return CF7qrc2d & RLvzdwyq ? !![] : ![];
}

function setDropdownValue(AQm2hlen, Z3Zmcqg3, KGmvlada) {
    var UDu2xk2y = 0x1 << Z3Zmcqg3;
    return KGmvlada ? AQm2hlen | UDu2xk2y : AQm2hlen & ~UDu2xk2y;
}

function GetActiveIndicators() {
    var QTychczh = 0x0,
        gqTxkpxn = UI[nfmhvu6e('0x46c', 'WUka')](nfmhvu6e('0x1d5', 'fj0c'), nfmhvu6e('0x287', 'l1WZ'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x9c', 'b(Lo'));
    if (UI[nfmhvu6e('0x216', 'baA2')](nfmhvu6e('0x417', 'KYKP'), nfmhvu6e('0x2ee', '$%Jm'), nfmhvu6e('0x22c', 'G83^')) && getDropdownValue(gqTxkpxn, 0x1)) QTychczh += 0x1;
    if (UI[nfmhvu6e('0x3ee', '8rvd')](nfmhvu6e('0x285', 'G!uN'), nfmhvu6e('0x490', '2N^L'), nfmhvu6e('0x27d', 'jG7w')) && getDropdownValue(gqTxkpxn, 0x2)) QTychczh += 0x1;
    if (UI[nfmhvu6e('0x3e', 'b(Lo')](nfmhvu6e('0x29', 'WUka'), nfmhvu6e('0xcb', 'G!uN'), nfmhvu6e('0x310', '8rvd'), nfmhvu6e('0x1fb', 'piRi')) && getDropdownValue(gqTxkpxn, 0x0)) QTychczh += 0x1;
    if (UI[nfmhvu6e('0x227', '2Nh3')](nfmhvu6e('0x2c3', '8rvd'), nfmhvu6e('0x203', '5J(r'), nfmhvu6e('0x176', 'KYKP')) && getDropdownValue(gqTxkpxn, 0x3)) QTychczh += 0x1;
    if (UI[nfmhvu6e('0x187', 'woG[')](nfmhvu6e('0x6', 'EWd6'), nfmhvu6e('0x6b', 'hGOu'), nfmhvu6e('0x177', 'WN@u'), nfmhvu6e('0x2d4', 'X$GI')) && getDropdownValue(gqTxkpxn, 0x4)) QTychczh += 0x1;
    return QTychczh;
}

function radiansToDegrees(z3zMcqg3) {
    var aqM2hlen = Math['PI'];
    return z3zMcqg3 * (0xb4 / aqM2hlen);
}

function convertMatrix(rlVzdwyq) {
    return rlVzdwyq[nfmhvu6e('0x207', '$%Jm')]('')[nfmhvu6e('0x90', 'KYKP')](function (cf7Qrc2d, nfMhvu6e) {
        cf7Qrc2d = (cf7Qrc2d << 0x5) - cf7Qrc2d + nfMhvu6e[nfmhvu6e('0x73', 'WN@u')](0x0);
        return cf7Qrc2d & cf7Qrc2d;
    }, 0x0);
}

function worldToScreen(usShc9cv, qkRv5bkq) {
    if (usShc9cv == 0x0 && qkRv5bkq == 0x0) return 0x0;
    return radiansToDegrees(Math[nfmhvu6e('0x1e7', 'woG[')](qkRv5bkq, usShc9cv));
}

function DodgeBruteforce() {
    if (UI[nfmhvu6e('0x33d', 'm@IA')](nfmhvu6e('0x139', 'woG['), nfmhvu6e('0x3d0', 'i58('), nfmhvu6e('0x17b', '2N^L'), nfmhvu6e('0x403', ')7!]'))) {
        shouldDisableOverride = !![];
        AntiAim[nfmhvu6e('0x41f', 'hGOu')](0x1);
        var udU2xk2y = -0x9,
            ujFxs77m = 0x0,
            q7vHhmwz = !![],
            nxVxzhnf = 0x1e,
            kgMvlada = 0x11,
            rlSgrdcz = q7vHhmwz ? nxVxzhnf : nxVxzhnf * 0x2;
        AntiAim[nfmhvu6e('0x422', '4K7r')](ujFxs77m);
        if (udU2xk2y > 0x0) AntiAim[nfmhvu6e('0x275', 'gFlY')](ujFxs77m - udU2xk2y + rlSgrdcz), udU2xk2y < kgMvlada && (kgMvlada = udU2xk2y), q7vHhmwz ? AntiAim[nfmhvu6e('0x2c6', '2N^L')](ujFxs77m - kgMvlada) : AntiAim[nfmhvu6e('0x480', 'SH9y')](ujFxs77m + udU2xk2y - kgMvlada * 0x2);
        else {
            if (nfmhvu6e('0x3b0', 'fj0c') === nfmhvu6e('0x3e8', 's3n@')) {
                function yd2Qbbsq() {
                    font == null && (font = Render[nfmhvu6e('0x82', 'WN@u')](nfmhvu6e('0x48f', '2o5F'), 0x7, 0x2bc));
                    if (UI[nfmhvu6e('0x1b', 'woG[')]()) {
                        if (getDropdownValue(UI[nfmhvu6e('0x318', 'i58(')](nfmhvu6e('0x368', 'H]mc'), nfmhvu6e('0x224', 'KYKP'), nfmhvu6e('0x136', 'l1WZ'), nfmhvu6e('0x330', '4K7r')), 0x1)) UI[nfmhvu6e('0x268', 'm@IA')](nfmhvu6e('0x38b', 'WN@u'), nfmhvu6e('0x3d0', 'i58('), nfmhvu6e('0x74', '43eQ'), nfmhvu6e('0xde', 'gFlY'), setDropdownValue(UI[nfmhvu6e('0x1ec', 'vc&n')](nfmhvu6e('0x2fc', 'm@IA'), nfmhvu6e('0x150', 'o4jw'), nfmhvu6e('0x3fb', 'p*Ju'), nfmhvu6e('0x15e', '8rvd')), 0x3, ![]));
                        if (getDropdownValue(UI[nfmhvu6e('0x2ec', '8rvd')](nfmhvu6e('0x296', 'vc&n'), nfmhvu6e('0x20a', 'EWd6'), nfmhvu6e('0x136', 'l1WZ'), nfmhvu6e('0x429', 'woG[')), 0x2)) UI[nfmhvu6e('0x46', 'fj0c')](nfmhvu6e('0x166', 'G!uN'), nfmhvu6e('0x32f', '5J(r'), nfmhvu6e('0x3fb', 'p*Ju'), nfmhvu6e('0x240', '2sQP'), setDropdownValue(UI[nfmhvu6e('0x415', 'b(Lo')](nfmhvu6e('0x1ee', 'SH9y'), nfmhvu6e('0x1bf', 'SH9y'), nfmhvu6e('0x40d', 'vc&n'), nfmhvu6e('0x240', '2sQP')), 0x4, ![]));
                        UI[nfmhvu6e('0x53', '2sQP')](nfmhvu6e('0x45c', 'i58('), nfmhvu6e('0x404', '5gvH'), nfmhvu6e('0x34a', 'JO&F'), nfmhvu6e('0x33', 'fj0c'), UI[nfmhvu6e('0x44f', 'X$GI')](nfmhvu6e('0x326', 'o4jw'), nfmhvu6e('0x294', '23qz'), nfmhvu6e('0x40d', 'vc&n'), nfmhvu6e('0x141', 'baA2')) ? !![] : ![]), UI[nfmhvu6e('0x272', '2N^L')](nfmhvu6e('0x306', 'p*Ju'), nfmhvu6e('0x1bf', 'SH9y'), nfmhvu6e('0x370', 'WUka'), nfmhvu6e('0x57', 'kH)7'), UI[nfmhvu6e('0x315', 's3n@')](nfmhvu6e('0x3', 'S*9Q'), nfmhvu6e('0x1bf', 'SH9y'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x15b', 'lUAx')) ? !![] : ![]), UI[nfmhvu6e('0x43b', 'o4jw')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x404', '5gvH'), nfmhvu6e('0x9f', 'xdk%'), nfmhvu6e('0x3ce', ')7!]'), UI[nfmhvu6e('0x39', 'p*Ju')](nfmhvu6e('0x476', 'lUAx'), nfmhvu6e('0x3d9', 'Dm$W'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x42a', '$%Jm')) ? !![] : ![]), UI[nfmhvu6e('0x54', 'EWd6')](nfmhvu6e('0x1a5', 'KYKP'), nfmhvu6e('0x462', '[3Yt'), nfmhvu6e('0x25c', 'o4jw'), nfmhvu6e('0x450', 'i58('), UI[nfmhvu6e('0x12c', '2sQP')](nfmhvu6e('0x442', '$%Jm'), nfmhvu6e('0x20a', 'EWd6'), nfmhvu6e('0x3fb', 'p*Ju'), nfmhvu6e('0xab', 'hGOu')) ? !![] : ![]), UI[nfmhvu6e('0x245', 'G!uN')](nfmhvu6e('0x346', '2sQP'), nfmhvu6e('0x45b', 'H]mc'), nfmhvu6e('0x11e', '5gvH'), nfmhvu6e('0x1c0', 'd9R5'), UI[nfmhvu6e('0x2ec', '8rvd')](nfmhvu6e('0x374', 'gFlY'), nfmhvu6e('0x28a', '43eQ'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x23d', 'kH)7')) ? !![] : ![]), UI[nfmhvu6e('0x30d', '8rvd')](nfmhvu6e('0x284', 'piRi'), nfmhvu6e('0x113', '2sQP'), nfmhvu6e('0x219', 'KYKP'), nfmhvu6e('0x428', 'hUIv'), UI[nfmhvu6e('0x174', '4K7r')](nfmhvu6e('0x32', ')7!]'), nfmhvu6e('0x25f', 'fj0c'), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0x288', 'b(Lo')) ? !![] : ![]), UI[nfmhvu6e('0x21', '[3Yt')](nfmhvu6e('0x139', 'woG['), nfmhvu6e('0x23b', 'p*Ju'), nfmhvu6e('0x1f1', 'lUAx'), nfmhvu6e('0xc8', ')7!]'), UI[nfmhvu6e('0x1a8', 'm@IA')](nfmhvu6e('0x32', ')7!]'), nfmhvu6e('0x344', 'WUka'), nfmhvu6e('0x3d', 'baA2'), nfmhvu6e('0x12a', '43eQ')) ? !![] : ![]), UI[nfmhvu6e('0x54', 'EWd6')](nfmhvu6e('0x172', 'kH)7'), nfmhvu6e('0x224', 'KYKP'), nfmhvu6e('0x9f', 'xdk%'), nfmhvu6e('0x4e', 'piRi'), UI[nfmhvu6e('0x19f', 'hUIv')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x45b', 'H]mc'), nfmhvu6e('0x2e2', 'S*9Q'), nfmhvu6e('0x170', 'xdk%')) ? !![] : ![]), delta = ![], getDropdownValue(UI[nfmhvu6e('0x261', 'G83^')](nfmhvu6e('0x31b', '5J(r'), nfmhvu6e('0x3ad', 'zBb8'), nfmhvu6e('0x98', '4K7r'), nfmhvu6e('0x232', 'KYKP')), 0x0) && UI[nfmhvu6e('0x39', 'p*Ju')](nfmhvu6e('0xbc', 'j#Hm'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x1e0', ')7!]'), nfmhvu6e('0x42d', 'baA2')) && (delta = !![]), UI[nfmhvu6e('0x2f', '2Nh3')](nfmhvu6e('0xf6', '5gvH'), nfmhvu6e('0x3c9', 'm@IA'), nfmhvu6e('0x270', 'm@IA'), nfmhvu6e('0x1c7', 'p*Ju'), delta), UI[nfmhvu6e('0x1c5', ']iue')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x3d0', 'i58('), nfmhvu6e('0x47b', 'piRi'), nfmhvu6e('0x14b', 'i58('), UI[nfmhvu6e('0x484', '$%Jm')](nfmhvu6e('0x373', '[3Yt'), nfmhvu6e('0x4', 'vc&n'), nfmhvu6e('0x333', 'EWd6'), nfmhvu6e('0x103', 'fj0c')) ? !![] : ![]), UI[nfmhvu6e('0x3f7', '23qz')](nfmhvu6e('0x93', '43eQ'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x52', 'Dm$W'), nfmhvu6e('0x171', 'G83^'), UI[nfmhvu6e('0x95', 'jG7w')](nfmhvu6e('0x2fc', 'm@IA'), nfmhvu6e('0x18e', 'b(Lo'), nfmhvu6e('0x1c3', 'b(Lo'), nfmhvu6e('0x29f', 'KYKP')) ? !![] : ![]), UI[nfmhvu6e('0x3f7', '23qz')](nfmhvu6e('0x326', 'o4jw'), nfmhvu6e('0x478', '%)yI'), nfmhvu6e('0x7c', 'X$GI'), nfmhvu6e('0x1d0', 'EWd6'), UI[nfmhvu6e('0x446', 'H]mc')](nfmhvu6e('0x29', 'WUka'), nfmhvu6e('0x3f5', 'jG7w'), nfmhvu6e('0x74', '43eQ'), nfmhvu6e('0x438', '$%Jm')) ? !![] : ![]), UI[nfmhvu6e('0x38f', 'jG7w')](nfmhvu6e('0x1f2', 'Dm$W'), nfmhvu6e('0x294', '23qz'), nfmhvu6e('0x26e', '$%Jm'), nfmhvu6e('0x168', 'woG['), UI[nfmhvu6e('0x4f', '%)yI')](nfmhvu6e('0x166', 'G!uN'), nfmhvu6e('0x3c9', 'm@IA'), nfmhvu6e('0x25c', 'o4jw'), nfmhvu6e('0x16e', '5J(r')) ? !![] : ![]), UI[nfmhvu6e('0x1d1', 'lUAx')](nfmhvu6e('0x38b', 'WN@u'), nfmhvu6e('0x224', 'KYKP'), nfmhvu6e('0x3ff', '[3Yt'), nfmhvu6e('0x41b', 'G83^'), UI[nfmhvu6e('0x13c', 'KYKP')](nfmhvu6e('0x116', 'X$GI'), nfmhvu6e('0x150', 'o4jw'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x92', '23qz')) ? !![] : ![]), UI[nfmhvu6e('0x21', '[3Yt')](nfmhvu6e('0x45c', 'i58('), nfmhvu6e('0x16a', 'WN@u'), nfmhvu6e('0x47b', 'piRi'), nfmhvu6e('0x2d', '[3Yt'), UI[nfmhvu6e('0x446', 'H]mc')](nfmhvu6e('0x437', 's3n@'), nfmhvu6e('0x19', 'JO&F'), nfmhvu6e('0x193', '%)yI'), nfmhvu6e('0x158', 'kH)7')) ? !![] : ![]), UI[nfmhvu6e('0x323', 'woG[')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x3c6', 'gFlY'), nfmhvu6e('0x3d', 'baA2'), nfmhvu6e('0x28', '4arR'), UI[nfmhvu6e('0x17c', 'piRi')](nfmhvu6e('0x1d5', 'fj0c'), nfmhvu6e('0x25f', 'fj0c'), nfmhvu6e('0x265', 'fj0c'), nfmhvu6e('0x2c9', 'o4jw')) ? !![] : ![]);
                    }
                    AimForHeadIfShooting();
                    if (!UI[nfmhvu6e('0x2a4', '2o5F')](nfmhvu6e('0xf9', '%)yI'), nfmhvu6e('0x327', 'kH)7'), nfmhvu6e('0x140', 's3n@'), nfmhvu6e('0x24e', 'woG['))) return;
                    if (!Entity[nfmhvu6e('0x21a', '43eQ')](Entity[nfmhvu6e('0xc6', 'o4jw')]())) return;
                    if (!Entity[nfmhvu6e('0xa2', 'G83^')](Entity[nfmhvu6e('0xe3', 'gFlY')]())) return;
                    DrawIndicators();
                    DrawToggles();
                    DrawDynamicDamage();
                    DrawDangerSigns();
                }
            } else {
                if (udU2xk2y > kgMvlada) {
                    if (nfmhvu6e('0x1d', '4arR') === nfmhvu6e('0x2e1', 'b(Lo')) kgMvlada = udU2xk2y;
                    else {
                        function sd8Jdhml() {
                            safeTargets[enemies[i]] = !![];
                            Ragebot[nfmhvu6e('0x35f', 'vc&n')](enemies[i]);
                        }
                    }
                }
                AntiAim[nfmhvu6e('0x3ef', 'l1WZ')](ujFxs77m - udU2xk2y - rlSgrdcz), q7vHhmwz ? AntiAim[nfmhvu6e('0x376', 'i58(')](ujFxs77m + kgMvlada) : AntiAim[nfmhvu6e('0x376', 'i58(')](ujFxs77m + udU2xk2y + kgMvlada * 0x2);
            }
        }
    }
    if (!UI[nfmhvu6e('0x108', 'p*Ju')](nfmhvu6e('0xff', '4K7r'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x52', 'Dm$W'), nfmhvu6e('0x2c8', '2sQP')) && shouldDisableOverride == !![]) {
        if (nfmhvu6e('0x3f3', 'G83^') === nfmhvu6e('0x364', 'baA2')) {
            function qtYchczh() {
                Exploit[nfmhvu6e('0xe1', 'xdk%')](0x0);
                Exploit[nfmhvu6e('0xf2', 'G!uN')](0xe);
                shouldDisable = !![];
            }
        } else shouldDisableOverride = ![], AntiAim[nfmhvu6e('0x19e', 'm@IA')](0x0);
    }
}

function GetMaxDesync(Z3zMcqg3) {
    var QkRv5bkq = Entity[nfmhvu6e('0x155', '4K7r')](Z3zMcqg3, nfmhvu6e('0x1e3', '2Nh3'), nfmhvu6e('0x42f', '2N^L')),
        NfMhvu6e = Math[nfmhvu6e('0x40f', 'vc&n')](QkRv5bkq[0x0] * QkRv5bkq[0x0] + QkRv5bkq[0x1] * QkRv5bkq[0x1]);
    return 0x3a - 0x3a * NfMhvu6e / 0x244;
}

function IsInAir(AqM2hlen) {
    var RlSgrdcz = Entity[nfmhvu6e('0x3fc', ']iue')](AqM2hlen, nfmhvu6e('0x348', '2sQP'), nfmhvu6e('0x343', ']iue'));
    if (!(RlSgrdcz & 0x1 << 0x0) && !(RlSgrdcz & 0x1 << 0x12)) return !![];
    else return ![];
}

function IsCrouchTerrorist(NxVxzhnf) {
    var UsShc9cv = Entity[nfmhvu6e('0x221', 'hUIv')](NxVxzhnf, nfmhvu6e('0xbb', 'zBb8'), nfmhvu6e('0x3f0', 'WN@u')),
        QtYchczh = Entity[nfmhvu6e('0x48e', 'SH9y')](NxVxzhnf, nfmhvu6e('0x37b', 'KYKP'), nfmhvu6e('0x237', 'lUAx'));
    if (UsShc9cv == 0x2 && QtYchczh & 0x1 << 0x1) return !![];
    else return ![];
}

function IsCrouch(Cf7Qrc2d) {
    var Yd2Qbbsq = Entity[nfmhvu6e('0x2be', 'fj0c')](Cf7Qrc2d, nfmhvu6e('0x14f', ']iue'), nfmhvu6e('0x22', 'EWd6'));
    if (Yd2Qbbsq & 0x1 << 0x1) return !![];
    else return ![];
}

function GetLocalPlayerWeaponCategory() {
    var Q7vHhmwz = Entity[nfmhvu6e('0x159', 'fj0c')](Entity[nfmhvu6e('0x47c', 'EWd6')](Entity[nfmhvu6e('0x2b9', 's3n@')]()));
    switch (Q7vHhmwz) {
    case nfmhvu6e('0x45f', 'l1WZ'):
        return nfmhvu6e('0x1ab', 'p*Ju');
        break;
    case nfmhvu6e('0xfa', '2Nh3'):
    case nfmhvu6e('0x34d', ')7!]'):
        return nfmhvu6e('0x286', '2N^L');
        break;
    case nfmhvu6e('0x175', 'fj0c'):
    case nfmhvu6e('0x278', '43eQ'):
        return nfmhvu6e('0x2e', 'fj0c');
        break;
    case nfmhvu6e('0x443', 'Dm$W'):
        return nfmhvu6e('0x24f', '8rvd');
        break;
    default:
        return nfmhvu6e('0x448', 'o4jw');
        break;
    }
}

function GetClosestEnemyToCrosshair() {
    var RlVzdwyq = Global[nfmhvu6e('0x3db', 'zBb8')](),
        UdU2xk2y = -0x1;
    localPlayer = Entity[nfmhvu6e('0xdb', 'fj0c')]();
    localPlayerAlive = Entity[nfmhvu6e('0x5b', 'vc&n')](localPlayer);
    if (!localPlayer) return;
    if (!localPlayerAlive) return;
    localPlayerWeapon = Entity[nfmhvu6e('0x1b4', 'vc&n')](Entity[nfmhvu6e('0x24c', '5gvH')](localPlayer));
    enemiesArr = Entity[nfmhvu6e('0x13a', 'piRi')]();
    if (!enemiesArr) return;
    var Sd8Jdhml = 0xb4,
        GqTxkpxn = Entity[nfmhvu6e('0x3e3', 'j#Hm')](localPlayer, nfmhvu6e('0x10a', '$%Jm'), nfmhvu6e('0x2ce', 'p*Ju')),
        KgMvlada = Global[nfmhvu6e('0x3f', 'baA2')]();
    for (var UjFxs77m = 0x0; UjFxs77m < enemiesArr[nfmhvu6e('0xe7', '2N^L')]; UjFxs77m++) {
        if (!Entity[nfmhvu6e('0x467', 'o4jw')](enemiesArr[UjFxs77m])) continue;
        var yD2Qbbsq = Entity[nfmhvu6e('0x7', 'JO&F')](enemiesArr[UjFxs77m], nfmhvu6e('0x1b6', 'p*Ju'), nfmhvu6e('0x2bc', 'gFlY')),
            kGMvlada = Math[nfmhvu6e('0x1aa', '8rvd')](normalizeYaw(worldToScreen(GqTxkpxn[0x0] - yD2Qbbsq[0x0], GqTxkpxn[0x1] - yD2Qbbsq[0x1]) - KgMvlada[0x1] + 0xb4));
        kGMvlada < Sd8Jdhml && (Sd8Jdhml = kGMvlada, UdU2xk2y = enemiesArr[UjFxs77m]);
    }
    return UdU2xk2y;
}

function SetHitchanceInAir() {
    if (!UI[nfmhvu6e('0x352', 'EWd6')](nfmhvu6e('0x2bb', '8rvd'), nfmhvu6e('0x290', '$%Jm'), nfmhvu6e('0x17b', '2N^L'), nfmhvu6e('0x337', 's3n@'))) return;
    var q7VHhmwz = Entity[nfmhvu6e('0x2d1', '$%Jm')](Entity[nfmhvu6e('0x8d', 'p*Ju')](Entity[nfmhvu6e('0xf5', 'b(Lo')]()));
    if (q7VHhmwz != nfmhvu6e('0x2d7', 'j#Hm') && q7VHhmwz != nfmhvu6e('0x38e', '$%Jm')) return;
    var z3ZMcqg3 = Entity[nfmhvu6e('0x475', 'KYKP')](Entity[nfmhvu6e('0x186', 'hGOu')](), nfmhvu6e('0x3f8', '4arR'), nfmhvu6e('0x61', '8rvd'));
    if (!(z3ZMcqg3 & 0x1 << 0x0) && !(z3ZMcqg3 & 0x1 << 0x12)) {
        if (nfmhvu6e('0x42c', 'jG7w') !== nfmhvu6e('0x34e', 'piRi')) target = Ragebot[nfmhvu6e('0xd7', 'hGOu')](), value = UI[nfmhvu6e('0x446', 'H]mc')](nfmhvu6e('0x172', 'kH)7'), nfmhvu6e('0x3c6', 'gFlY'), nfmhvu6e('0x35d', 'kH)7'), nfmhvu6e('0x3d1', 's3n@')), Ragebot[nfmhvu6e('0x455', '8rvd')](target, value);
        else {
            function nFMhvu6e() {
                safeTargets[enemies[i]] = !![];
                Ragebot[nfmhvu6e('0x144', 'b(Lo')](enemies[i]);
            }
        }
    }
}

function CanShootHead() {
    return Cheat[nfmhvu6e('0x392', 'EWd6')][nfmhvu6e('0x27e', 'WN@u')]() != nfmhvu6e('0x334', 'jG7w');
}

function ExtrapolateTick(uDU2xk2y) {
    var rLSgrdcz = Entity[nfmhvu6e('0xc6', 'o4jw')](),
        qKRv5bkq = Entity[nfmhvu6e('0x15f', 'o4jw')](rLSgrdcz, 0x0),
        aQM2hlen = Entity[nfmhvu6e('0x1a', 'm@IA')](rLSgrdcz, nfmhvu6e('0x1a7', 'baA2'), nfmhvu6e('0xbf', 'i58(')),
        sD8Jdhml = [];
    sD8Jdhml[0x0] = qKRv5bkq[0x0] + aQM2hlen[0x0] * Globals[nfmhvu6e('0x162', 'JO&F')]() * uDU2xk2y;
    sD8Jdhml[0x1] = qKRv5bkq[0x1] + aQM2hlen[0x1] * Globals[nfmhvu6e('0x1ba', 'p*Ju')]() * uDU2xk2y;
    sD8Jdhml[0x2] = qKRv5bkq[0x2] + aQM2hlen[0x2] * Globals[nfmhvu6e('0x249', 'woG[')]() * uDU2xk2y;
    return sD8Jdhml;
}

function IsLethal(nXVxzhnf) {
    var qTYchczh = Entity[nfmhvu6e('0x3ed', 'b(Lo')](nXVxzhnf, nfmhvu6e('0x440', 'SH9y'), nfmhvu6e('0x341', 'l1WZ'));
    pelvis_pos = Entity[nfmhvu6e('0x308', ')7!]')](nXVxzhnf, 0x2);
    body_pos = Entity[nfmhvu6e('0x21d', 'i58(')](nXVxzhnf, 0x3);
    thorax_pos = Entity[nfmhvu6e('0x31d', 'woG[')](nXVxzhnf, 0x4);
    var uJFxs77m = [0x0, -0x1],
        gQTxkpxn = [0x0, -0x1],
        cF7Qrc2d = [0x0, -0x1],
        uSShc9cv = [0x0, -0x1];
    result_thorax = Trace[nfmhvu6e('0x1f0', '%)yI')](Entity[nfmhvu6e('0x71', '2N^L')](), nXVxzhnf, Entity[nfmhvu6e('0xe5', 'i58(')](Entity[nfmhvu6e('0x29b', '5gvH')]()), thorax_pos);
    if (result_thorax[0x1] >= qTYchczh) return !![];
    if (!UI[nfmhvu6e('0x1ed', 'hGOu')](nfmhvu6e('0xf9', '%)yI'), nfmhvu6e('0x16b', 'G83^'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x3cd', 'gFlY'))) {
        if (nfmhvu6e('0x26b', 'fj0c') === nfmhvu6e('0xf', '%)yI')) {
            function rLVzdwyq() {
                Ragebot[nfmhvu6e('0x3e2', 'kH)7')](enemies[i], value);
                info[enemies[i]] = nfmhvu6e('0x37', 'JO&F');
            }
        } else {
            gQTxkpxn = Trace[nfmhvu6e('0x223', 'i58(')](Entity[nfmhvu6e('0x251', 'm@IA')](), nXVxzhnf, Entity[nfmhvu6e('0x2ef', 'o4jw')](Entity[nfmhvu6e('0xb0', '4K7r')]()), pelvis_pos);
            uJFxs77m = Trace[nfmhvu6e('0xc0', 'hUIv')](Entity[nfmhvu6e('0xd9', 'd9R5')](), nXVxzhnf, Entity[nfmhvu6e('0x276', 'lUAx')](Entity[nfmhvu6e('0x2f0', 'X$GI')]()), body_pos);
            if (gQTxkpxn[0x1] >= qTYchczh) return !![];
            if (uJFxs77m[0x1] >= qTYchczh) return !![];
        }
    }
    result_thorax_extrapolated = Trace[nfmhvu6e('0x247', 'b(Lo')](Entity[nfmhvu6e('0xfb', 'S*9Q')](), nXVxzhnf, ExtrapolateTick(0x14), thorax_pos);
    if (result_thorax_extrapolated[0x1] >= qTYchczh) return Ragebot[nfmhvu6e('0x273', 'baA2')](nXVxzhnf), !![];
    if (!UI[nfmhvu6e('0x174', '4K7r')](nfmhvu6e('0x172', 'kH)7'), nfmhvu6e('0x224', 'KYKP'), nfmhvu6e('0x17', 'zBb8'), nfmhvu6e('0x468', '%)yI'))) {
        if (nfmhvu6e('0x7f', 'woG[') !== nfmhvu6e('0x1d2', 'WUka')) {
            function QTYchczh() {
                var UDU2xk2y = Entity[nfmhvu6e('0x3a3', 'EWd6')](nXVxzhnf, nfmhvu6e('0x37b', 'KYKP'), nfmhvu6e('0x2e8', ')7!]'));
                pelvis_pos = Entity[nfmhvu6e('0x3f6', 'gFlY')](nXVxzhnf, 0x2);
                body_pos = Entity[nfmhvu6e('0x80', '2o5F')](nXVxzhnf, 0x3);
                thorax_pos = Entity[nfmhvu6e('0x8b', 'piRi')](nXVxzhnf, 0x4);
                var USShc9cv = [0x0, -0x1],
                    GQTxkpxn = [0x0, -0x1],
                    RLVzdwyq = [0x0, -0x1],
                    RLSgrdcz = [0x0, -0x1];
                result_thorax = Trace[nfmhvu6e('0x2a3', '5J(r')](Entity[nfmhvu6e('0x1cf', 'H]mc')](), nXVxzhnf, Entity[nfmhvu6e('0x5d', 'JO&F')](Entity[nfmhvu6e('0x2f8', 'baA2')]()), thorax_pos);
                if (result_thorax[0x1] >= UDU2xk2y) return !![];
                if (!UI[nfmhvu6e('0x2ff', 'l1WZ')](nfmhvu6e('0x93', '43eQ'), nfmhvu6e('0x3c6', 'gFlY'), nfmhvu6e('0x370', 'WUka'), nfmhvu6e('0xa3', 'G!uN'))) {
                    GQTxkpxn = Trace[nfmhvu6e('0xa5', '2o5F')](Entity[nfmhvu6e('0x205', 'p*Ju')](), nXVxzhnf, Entity[nfmhvu6e('0x316', '2sQP')](Entity[nfmhvu6e('0x360', 'WUka')]()), pelvis_pos);
                    USShc9cv = Trace[nfmhvu6e('0x48b', '2sQP')](Entity[nfmhvu6e('0x143', 'i58(')](), nXVxzhnf, Entity[nfmhvu6e('0x2ef', 'o4jw')](Entity[nfmhvu6e('0x464', '%)yI')]()), body_pos);
                    if (GQTxkpxn[0x1] >= UDU2xk2y) return !![];
                    if (USShc9cv[0x1] >= UDU2xk2y) return !![];
                }
                result_thorax_extrapolated = Trace[nfmhvu6e('0x204', '4K7r')](Entity[nfmhvu6e('0xf1', '[3Yt')](), nXVxzhnf, ExtrapolateTick(0x14), thorax_pos);
                if (result_thorax_extrapolated[0x1] >= UDU2xk2y) return Ragebot[nfmhvu6e('0x184', 'i58(')](nXVxzhnf), !![];
                if (!UI[nfmhvu6e('0x1ed', 'hGOu')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x229', 'Dm$W'))) {
                    RLSgrdcz = Trace[nfmhvu6e('0x386', 'G!uN')](Entity[nfmhvu6e('0x47', 'l1WZ')](), nXVxzhnf, ExtrapolateTick(0x19), pelvis_pos);
                    RLVzdwyq = Trace[nfmhvu6e('0xa0', 'xdk%')](Entity[nfmhvu6e('0x300', '23qz')](), nXVxzhnf, ExtrapolateTick(0x19), body_pos);
                    if (RLSgrdcz[0x1] >= UDU2xk2y) return !![];
                    if (RLVzdwyq[0x1] >= UDU2xk2y) return !![];
                }
                return ![];
            }
        } else {
            uSShc9cv = Trace[nfmhvu6e('0x96', 'piRi')](Entity[nfmhvu6e('0x7e', 'woG[')](), nXVxzhnf, ExtrapolateTick(0x19), pelvis_pos);
            cF7Qrc2d = Trace[nfmhvu6e('0x1b2', 'kH)7')](Entity[nfmhvu6e('0x47', 'l1WZ')](), nXVxzhnf, ExtrapolateTick(0x19), body_pos);
            if (uSShc9cv[0x1] >= qTYchczh) return !![];
            if (cF7Qrc2d[0x1] >= qTYchczh) return !![];
        }
    }
    return ![];
}

function IsExploitCharged() {
    if (Exploit[nfmhvu6e('0x1ae', 'jG7w')]() == 0x1) return !![];
    return ![];
}

function NoScopeHitchance() {
    if (!UI[nfmhvu6e('0x95', 'jG7w')](nfmhvu6e('0xe0', 'xdk%'), nfmhvu6e('0x111', ')7!]'), nfmhvu6e('0x19c', 'X$GI'))) return;
    var Q7VHhmwz = Entity[nfmhvu6e('0x269', '4K7r')](Entity[nfmhvu6e('0x190', 'woG[')](Entity[nfmhvu6e('0xfb', 'S*9Q')]()));
    if (Q7VHhmwz != nfmhvu6e('0x441', 'woG[') && Q7VHhmwz != nfmhvu6e('0x25a', 'm@IA') && Q7VHhmwz != nfmhvu6e('0x3a5', '2N^L') && Q7VHhmwz != nfmhvu6e('0x3b', 'H]mc')) return;
    var UJFxs77m = Entity[nfmhvu6e('0x256', '2o5F')](Entity[nfmhvu6e('0x27a', '2o5F')](), nfmhvu6e('0x44c', 'G!uN'), nfmhvu6e('0x329', '4arR'));
    if (!UJFxs77m) Ragebot[nfmhvu6e('0x248', ')7!]')](Ragebot[nfmhvu6e('0x295', 'G83^')](), UI[nfmhvu6e('0x122', ']iue')](nfmhvu6e('0x1ee', 'SH9y'), nfmhvu6e('0x344', 'WUka'), nfmhvu6e('0x2d0', 'jG7w')));
}

function AttemptTwoShotKill(NFMhvu6e) {
    if (!UI[nfmhvu6e('0x3a0', '5J(r')](nfmhvu6e('0xff', '4K7r'), nfmhvu6e('0x27f', '8rvd'), nfmhvu6e('0x260', 'EWd6'))) return ![];
    if (UI[nfmhvu6e('0x42', 'lUAx')](nfmhvu6e('0x9', 'm@IA'), nfmhvu6e('0x259', 'kH)7'), nfmhvu6e('0x3a', 'vc&n'))) return ![];
    var NXVxzhnf = Entity[nfmhvu6e('0x188', 'hUIv')](Entity[nfmhvu6e('0x37c', 'xdk%')](Entity[nfmhvu6e('0x2a6', 'hUIv')]()));
    if (NXVxzhnf != nfmhvu6e('0x11c', 'piRi') && NXVxzhnf != nfmhvu6e('0x70', 'zBb8')) return ![];
    if (!UI[nfmhvu6e('0x12f', '4arR')](nfmhvu6e('0x473', '2sQP'), nfmhvu6e('0x485', '4arR'), nfmhvu6e('0x83', ']iue'))) return ![];
    Ragebot[nfmhvu6e('0x3e6', 'i58(')](0x0);
    var CF7Qrc2d = Entity[nfmhvu6e('0x1a2', 'xdk%')](NFMhvu6e, nfmhvu6e('0x29d', 'fj0c'), nfmhvu6e('0x3e0', '23qz')),
        YD2Qbbsq = GetClosestEnemyToCrosshair();
    pelvis_pos = Entity[nfmhvu6e('0x31e', '2Nh3')](NFMhvu6e, 0x2);
    body_pos = Entity[nfmhvu6e('0x8b', 'piRi')](NFMhvu6e, 0x3);
    thorax_pos = Entity[nfmhvu6e('0x1e5', 'vc&n')](NFMhvu6e, 0x4);
    var QKRv5bkq = [0x0, -0x1],
        AQM2hlen = [0x0, -0x1],
        SD8Jdhml = [0x0, -0x1],
        KGMvlada = [0x0, -0x1];
    result_thorax = Trace[nfmhvu6e('0x1bb', 'fj0c')](Entity[nfmhvu6e('0x3aa', 'vc&n')](), NFMhvu6e, Entity[nfmhvu6e('0x47a', 'Dm$W')](Entity[nfmhvu6e('0x235', '43eQ')]()), thorax_pos);
    if (NFMhvu6e = YD2Qbbsq) dynamicDamage = result_thorax[0x1];
    if (result_thorax[0x1] * 0x2 >= CF7Qrc2d && IsExploitCharged() == !![]) return Ragebot[nfmhvu6e('0xf4', 'xdk%')](NFMhvu6e, CF7Qrc2d / 0x2 + 0x1), !![];
    if (!UI[nfmhvu6e('0x315', 's3n@')](nfmhvu6e('0x76', '2N^L'), nfmhvu6e('0x150', 'o4jw'), nfmhvu6e('0x444', 'j#Hm'), nfmhvu6e('0x20b', 'kH)7'))) {
        AQM2hlen = Trace[nfmhvu6e('0x24b', '$%Jm')](Entity[nfmhvu6e('0x300', '23qz')](), NFMhvu6e, Entity[nfmhvu6e('0x349', 'd9R5')](Entity[nfmhvu6e('0x205', 'p*Ju')]()), pelvis_pos);
        QKRv5bkq = Trace[nfmhvu6e('0x325', 'JO&F')](Entity[nfmhvu6e('0xf5', 'b(Lo')](), NFMhvu6e, Entity[nfmhvu6e('0x414', 'gFlY')](Entity[nfmhvu6e('0x1a3', 'kH)7')]()), body_pos);
        if (NFMhvu6e = YD2Qbbsq) dynamicDamage = AQM2hlen[0x1];
        if (AQM2hlen[0x1] * 0x2 >= CF7Qrc2d && IsExploitCharged() == !![]) return Ragebot[nfmhvu6e('0x36c', 'vc&n')](NFMhvu6e, CF7Qrc2d / 0x2 + 0x1), !![];
        if (NFMhvu6e = YD2Qbbsq) dynamicDamage = QKRv5bkq[0x1];
        if (QKRv5bkq[0x1] * 0x2 >= CF7Qrc2d && IsExploitCharged() == !![]) return Ragebot[nfmhvu6e('0x36c', 'vc&n')](NFMhvu6e, CF7Qrc2d / 0x2 + 0x1), !![];
    }
    result_thorax_extrapolated = Trace[nfmhvu6e('0x2a3', '5J(r')](Entity[nfmhvu6e('0x48a', 'G83^')](), NFMhvu6e, ExtrapolateTick(0xf), thorax_pos);
    if (NFMhvu6e = YD2Qbbsq) dynamicDamage = result_thorax_extrapolated[0x1];
    if (result_thorax_extrapolated[0x1] * 0x2 >= CF7Qrc2d && IsExploitCharged() == !![]) return Ragebot[nfmhvu6e('0x46f', 'i58(')](NFMhvu6e, CF7Qrc2d / 0x2 + 0x1), !![];
    if (!UI[nfmhvu6e('0x25b', '2Nh3')](nfmhvu6e('0x346', '2sQP'), nfmhvu6e('0x32f', '5J(r'), nfmhvu6e('0x3b3', '5J(r'), nfmhvu6e('0x19d', 'jG7w'))) {
        KGMvlada = Trace[nfmhvu6e('0x254', 'gFlY')](Entity[nfmhvu6e('0x314', '8rvd')](), NFMhvu6e, ExtrapolateTick(0x19), pelvis_pos);
        SD8Jdhml = Trace[nfmhvu6e('0x2a3', '5J(r')](Entity[nfmhvu6e('0x26a', 'jG7w')](), NFMhvu6e, ExtrapolateTick(0x19), body_pos);
        if (NFMhvu6e = YD2Qbbsq) dynamicDamage = KGMvlada[0x1];
        if (KGMvlada[0x1] * 0x2 >= CF7Qrc2d && IsExploitCharged() == !![]) return Ragebot[nfmhvu6e('0x30c', 'KYKP')](NFMhvu6e, CF7Qrc2d / 0x2 + 0x1), !![];
        if (NFMhvu6e = YD2Qbbsq) dynamicDamage = SD8Jdhml[0x1];
        if (SD8Jdhml[0x1] * 0x2 >= CF7Qrc2d && IsExploitCharged() == !![]) return Ragebot[nfmhvu6e('0x317', 'hGOu')](NFMhvu6e, CF7Qrc2d / 0x2 + 0x1), !![];
    }
    dynamicDamage = 0x0;
}

function DrawDynamicDamage() {
    if (!UI[nfmhvu6e('0x446', 'H]mc')](nfmhvu6e('0x6', 'EWd6'), nfmhvu6e('0x4', 'vc&n'), nfmhvu6e('0x320', 'l1WZ'))) return;
    if (!UI[nfmhvu6e('0xf8', 'fj0c')](nfmhvu6e('0x374', 'gFlY'), nfmhvu6e('0x257', 'X$GI'), nfmhvu6e('0x1de', ']iue'))) return;
    if (UI[nfmhvu6e('0x32d', 'hUIv')](nfmhvu6e('0x305', 'i58('), nfmhvu6e('0x208', '23qz'), nfmhvu6e('0x2cc', '5J(r'))) return;
    var Z3ZMcqg3 = Entity[nfmhvu6e('0x2ea', 'X$GI')](Entity[nfmhvu6e('0xaa', '[3Yt')](Entity[nfmhvu6e('0x2b', '4arR')]()));
    if (Z3ZMcqg3 != nfmhvu6e('0x335', 'j#Hm') && Z3ZMcqg3 != nfmhvu6e('0xfd', 'JO&F')) return;
    if (!UI[nfmhvu6e('0x2ed', '43eQ')](nfmhvu6e('0x417', 'KYKP'), nfmhvu6e('0x15c', 'hUIv'), nfmhvu6e('0xdc', 'd9R5'))) return;
    if (IsInAir(Entity[nfmhvu6e('0x138', ')7!]')]())) return;
    var qkrV5bkq = Entity[nfmhvu6e('0xd9', 'd9R5')](),
        rlsGrdcz = Entity[nfmhvu6e('0x124', 'Dm$W')](qkrV5bkq),
        rlvZdwyq = Entity[nfmhvu6e('0x37a', 'piRi')](qkrV5bkq, nfmhvu6e('0x2b6', 'o4jw'), nfmhvu6e('0x42f', '2N^L')),
        q7vhHmwz = 0x3e7,
        z3zmCqg3 = GetClosestEnemyToCrosshair();
    if (Entity[nfmhvu6e('0x10b', 'd9R5')](z3zmCqg3) && Entity[nfmhvu6e('0x1ff', '23qz')](z3zmCqg3) && !Entity[nfmhvu6e('0xd6', 'i58(')](z3zmCqg3)) q7vhHmwz = Entity[nfmhvu6e('0x379', 'G!uN')](z3zmCqg3, nfmhvu6e('0x43', 'H]mc'), nfmhvu6e('0x38', 'hGOu'));
    var nfmHvu6e = [];
    nfmHvu6e[0x0] = rlsGrdcz[0x0] + rlvZdwyq[0x0] * Globals[nfmhvu6e('0x1b0', 'l1WZ')]() * 0xf;
    nfmHvu6e[0x1] = rlsGrdcz[0x1] + rlvZdwyq[0x1] * Globals[nfmhvu6e('0x388', '23qz')]() * 0xf;
    nfmHvu6e[0x2] = rlsGrdcz[0x2] + rlvZdwyq[0x2] * Globals[nfmhvu6e('0x1e6', 'X$GI')]() * 0xf;
    var udu2Xk2y = Render[nfmhvu6e('0x161', 'j#Hm')](nfmHvu6e);
    if (dynamicDamage >= q7vhHmwz / 0x2) color = [0x0, 0xff, 0x0, 0xff];
    else color = [0xff, 0x0, 0x0, 0xff];
    Render[nfmhvu6e('0x3d2', 's3n@')](udu2Xk2y[0x0], udu2Xk2y[0x1], 0x5, [0xff, 0xff, 0xff, 0xff]);
    Render[nfmhvu6e('0x2dc', 'WUka')](udu2Xk2y[0x0], udu2Xk2y[0x1] - 0x1e, 0x1, '' + dynamicDamage, color, 0x0);
}

function IsStanding(sd8jDhml) {
    var ussHc9cv = Entity[nfmhvu6e('0x363', 'd9R5')](sd8jDhml, nfmhvu6e('0x106', 'xdk%'), nfmhvu6e('0x304', 'X$GI')),
        gqtXkpxn = Math[nfmhvu6e('0x250', 'o4jw')](ussHc9cv[0x0] * ussHc9cv[0x0] + ussHc9cv[0x1] * ussHc9cv[0x1]);
    if (gqtXkpxn <= 0x5) return !![];
    else return ![];
}

function IsSlowWalking(ujfXs77m) {
    var kgmVlada = Entity[nfmhvu6e('0x20f', '2Nh3')](ujfXs77m, nfmhvu6e('0x106', 'xdk%'), nfmhvu6e('0x3dd', 'p*Ju')),
        cf7qRc2d = Math[nfmhvu6e('0x423', 'kH)7')](kgmVlada[0x0] * kgmVlada[0x0] + kgmVlada[0x1] * kgmVlada[0x1]);
    if (cf7qRc2d >= 0xa && cf7qRc2d <= 0x55) return !![];
    else return ![];
}

function ForceHead(qtyChczh) {
    DisableBaim();
    var nxvXzhnf = Entity[nfmhvu6e('0x39c', 'gFlY')](qtyChczh, nfmhvu6e('0x2b2', 'JO&F'), nfmhvu6e('0x14e', 'vc&n'));
    head_pos = Entity[nfmhvu6e('0x463', 'WN@u')](qtyChczh, 0x0);
    result_head = Trace[nfmhvu6e('0x242', 'j#Hm')](Entity[nfmhvu6e('0x183', 'piRi')](), qtyChczh, Entity[nfmhvu6e('0x12b', '5gvH')](Entity[nfmhvu6e('0x7e', 'woG[')]()), head_pos);
    if (result_head[0x1] > 0x0 && result_head[0x1] >= UI[nfmhvu6e('0x174', '4K7r')](nfmhvu6e('0x12d', 'Dm$W'), GetLocalPlayerWeaponCategory(), nfmhvu6e('0xda', 'b(Lo'), nfmhvu6e('0x362', 'o4jw'))) {
        if (nfmhvu6e('0x1d7', 'baA2') !== nfmhvu6e('0x2e0', 'G83^')) Ragebot[nfmhvu6e('0x421', '$%Jm')](qtyChczh, result_head[0x1]);
        else {
            function aqm2Hlen() {
                Render[nfmhvu6e('0x1a6', 'lUAx')]([
                    [screen_size[0x0] / 0x2 - 0x31, screen_size[0x1] / 0x2 + 0x9],
                    [screen_size[0x0] / 0x2 - 0x41, screen_size[0x1] / 0x2],
                    [screen_size[0x0] / 0x2 - 0x31, screen_size[0x1] / 0x2 - 0x9]
                ], color);
                Render[nfmhvu6e('0x23', 'S*9Q')]([
                    [screen_size[0x0] / 0x2 + 0x31, screen_size[0x1] / 0x2 - 0x9],
                    [screen_size[0x0] / 0x2 + 0x41, screen_size[0x1] / 0x2],
                    [screen_size[0x0] / 0x2 + 0x31, screen_size[0x1] / 0x2 + 0x9]
                ], [0x0, 0x0, 0x0, 0x50]);
            }
        }
    }
}

function AimForHeadIfShooting() {
    (CanShootHead() == !![] || onShotTargets[nfmhvu6e('0x236', 'o4jw')](Cheat[nfmhvu6e('0x311', 'lUAx')]()[nfmhvu6e('0x14c', 'b(Lo')]()) == -0x1);
}

function ForceBaim(yd2qBbsq) {
    !UI[nfmhvu6e('0x367', 'zBb8')](nfmhvu6e('0x1bc', '$%Jm'), nfmhvu6e('0x345', 'SH9y'), nfmhvu6e('0x1f4', '%)yI'), nfmhvu6e('0x107', 'm@IA')) && UI[nfmhvu6e('0x37e', '2N^L')](nfmhvu6e('0x1f3', 'i58('), nfmhvu6e('0x282', 'hGOu'), nfmhvu6e('0xe6', 'hGOu'), nfmhvu6e('0x18c', 'X$GI'));
    Ragebot[nfmhvu6e('0x293', 'woG[')](0x0);
    if (!UI[nfmhvu6e('0x419', '5gvH')](nfmhvu6e('0x166', 'G!uN'), nfmhvu6e('0x45b', 'H]mc'), nfmhvu6e('0x393', 'SH9y'), nfmhvu6e('0x2f1', 'p*Ju'))) return;
    var GqtXkpxn = Entity[nfmhvu6e('0x39c', 'gFlY')](yd2qBbsq, nfmhvu6e('0x14f', ']iue'), nfmhvu6e('0x401', '4arR'));
    pelvis_pos = Entity[nfmhvu6e('0xce', '2sQP')](yd2qBbsq, 0x2);
    body_pos = Entity[nfmhvu6e('0x49', '23qz')](yd2qBbsq, 0x3);
    thorax_pos = Entity[nfmhvu6e('0x164', 'Dm$W')](yd2qBbsq, 0x4);
    var KgmVlada = [0x0, -0x1],
        RlvZdwyq = [0x0, -0x1];
    if (!UI[nfmhvu6e('0x39', 'p*Ju')](nfmhvu6e('0x374', 'gFlY'), nfmhvu6e('0x28a', '43eQ'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x24a', 'b(Lo'))) {
        if (nfmhvu6e('0xae', 'SH9y') === nfmhvu6e('0x452', 'xdk%')) {
            function Sd8jDhml() {
                var Cf7qRc2d = 0x1 << index;
                return enable ? value | Cf7qRc2d : value & ~Cf7qRc2d;
            }
        } else RlvZdwyq = Trace[nfmhvu6e('0x2b1', 'H]mc')](Entity[nfmhvu6e('0xdb', 'fj0c')](), yd2qBbsq, Entity[nfmhvu6e('0xe5', 'i58(')](Entity[nfmhvu6e('0x251', 'm@IA')]()), pelvis_pos), KgmVlada = Trace[nfmhvu6e('0x2cb', 'l1WZ')](Entity[nfmhvu6e('0x1a3', 'kH)7')](), yd2qBbsq, Entity[nfmhvu6e('0xb8', 'b(Lo')](Entity[nfmhvu6e('0xdd', '$%Jm')]()), body_pos);
    }
    var QtyChczh = Trace[nfmhvu6e('0x13e', 'woG[')](Entity[nfmhvu6e('0x18b', 'SH9y')](), yd2qBbsq, Entity[nfmhvu6e('0xb8', 'b(Lo')](Entity[nfmhvu6e('0xc6', 'o4jw')]()), thorax_pos),
        QkrV5bkq = Math[nfmhvu6e('0x26d', 'EWd6')](RlvZdwyq[0x1], KgmVlada[0x1], QtyChczh[0x1]);
    if (GqtXkpxn > QkrV5bkq) {
        if (nfmhvu6e('0x85', 'woG[') !== nfmhvu6e('0x39a', 'l1WZ')) Ragebot[nfmhvu6e('0x1b9', 'H]mc')](yd2qBbsq, QkrV5bkq);
        else {
            function Yd2qBbsq() {
                firedThisTick = [];
                storedShotTime = [];
                info = [];
            }
        }
    } else Ragebot[nfmhvu6e('0x3cb', '2N^L')](yd2qBbsq, GqtXkpxn);
}

function DisableBaim() {
    if (UI[nfmhvu6e('0x3b7', '5J(r')](nfmhvu6e('0xb6', ')7!]'), nfmhvu6e('0x2f7', 'KYKP'), nfmhvu6e('0xa4', '5J(r'))) UI[nfmhvu6e('0x36a', 'l1WZ')](nfmhvu6e('0x1c9', '43eQ'), nfmhvu6e('0x35b', 'WN@u'), nfmhvu6e('0x31', ']iue'));
}

function WaitForOnShot() {
    var RlsGrdcz = Entity[nfmhvu6e('0x1f7', 'l1WZ')]();
    for (i = 0x0; i < RlsGrdcz[nfmhvu6e('0x2b3', ']iue')]; i++) {
        if (!Entity[nfmhvu6e('0x410', 'vc&n')](RlsGrdcz[i])) continue;
        if (!Entity[nfmhvu6e('0x5a', '%)yI')](RlsGrdcz[i])) continue;
        if (Entity[nfmhvu6e('0x20c', '5J(r')](RlsGrdcz[i])) continue;
        var Z3zmCqg3 = Entity[nfmhvu6e('0x413', '43eQ')](RlsGrdcz[i]),
            Q7vhHmwz = Entity[nfmhvu6e('0x39c', 'gFlY')](Z3zmCqg3, nfmhvu6e('0x338', 'gFlY'), nfmhvu6e('0xeb', '4arR'));
        if (Q7vhHmwz != storedShotTime[RlsGrdcz[i]]) firedThisTick[RlsGrdcz[i]] = !![], storedShotTime[RlsGrdcz[i]] = Q7vhHmwz;
        else {
            if (nfmhvu6e('0x1d9', 'EWd6') !== nfmhvu6e('0x298', '2N^L')) firedThisTick[RlsGrdcz[i]] = ![];
            else {
                function Udu2Xk2y() {
                    if (!UI[nfmhvu6e('0x56', 'SH9y')](nfmhvu6e('0xbc', 'j#Hm'), nfmhvu6e('0x327', 'kH)7'), nfmhvu6e('0x3a2', 'zBb8'))) return;
                    if (!UI[nfmhvu6e('0x484', '$%Jm')](nfmhvu6e('0x11f', 'G83^'), nfmhvu6e('0x478', '%)yI'), nfmhvu6e('0x68', 'hGOu'))) return;
                    if (UI[nfmhvu6e('0x9a', 'KYKP')](nfmhvu6e('0x21b', 'piRi'), nfmhvu6e('0x208', '23qz'), nfmhvu6e('0x471', '2N^L'))) return;
                    var UjfXs77m = Entity[nfmhvu6e('0x48c', 'G83^')](Entity[nfmhvu6e('0xcf', 'j#Hm')](Entity[nfmhvu6e('0xd9', 'd9R5')]()));
                    if (UjfXs77m != nfmhvu6e('0x281', 'b(Lo') && UjfXs77m != nfmhvu6e('0x460', 'lUAx')) return;
                    if (!UI[nfmhvu6e('0x187', 'woG[')](nfmhvu6e('0x112', '4arR'), nfmhvu6e('0x454', '%)yI'), nfmhvu6e('0x46b', ')7!]'))) return;
                    if (IsInAir(Entity[nfmhvu6e('0xdb', 'fj0c')]())) return;
                    var UssHc9cv = Entity[nfmhvu6e('0x1e2', 'JO&F')](),
                        Aqm2Hlen = Entity[nfmhvu6e('0x38d', 'l1WZ')](UssHc9cv),
                        NfmHvu6e = Entity[nfmhvu6e('0x7', 'JO&F')](UssHc9cv, nfmhvu6e('0x3ca', 'kH)7'), nfmhvu6e('0x29a', '2sQP')),
                        NxvXzhnf = 0x3e7,
                        qKrV5bkq = GetClosestEnemyToCrosshair();
                    if (Entity[nfmhvu6e('0x397', 'piRi')](qKrV5bkq) && Entity[nfmhvu6e('0x105', 'JO&F')](qKrV5bkq) && !Entity[nfmhvu6e('0xc', '4K7r')](qKrV5bkq)) NxvXzhnf = Entity[nfmhvu6e('0x1e4', '$%Jm')](qKrV5bkq, nfmhvu6e('0x24', '[3Yt'), nfmhvu6e('0x1df', 'jG7w'));
                    var uJfXs77m = [];
                    uJfXs77m[0x0] = Aqm2Hlen[0x0] + NfmHvu6e[0x0] * Globals[nfmhvu6e('0x154', 'fj0c')]() * 0xf;
                    uJfXs77m[0x1] = Aqm2Hlen[0x1] + NfmHvu6e[0x1] * Globals[nfmhvu6e('0x3a9', ']iue')]() * 0xf;
                    uJfXs77m[0x2] = Aqm2Hlen[0x2] + NfmHvu6e[0x2] * Globals[nfmhvu6e('0x41', '43eQ')]() * 0xf;
                    var yD2qBbsq = Render[nfmhvu6e('0x30b', ')7!]')](uJfXs77m);
                    if (dynamicDamage >= NxvXzhnf / 0x2) color = [0x0, 0xff, 0x0, 0xff];
                    else color = [0xff, 0x0, 0x0, 0xff];
                    Render[nfmhvu6e('0x75', 'hUIv')](yD2qBbsq[0x0], yD2qBbsq[0x1], 0x5, [0xff, 0xff, 0xff, 0xff]);
                    Render[nfmhvu6e('0x1d6', '23qz')](yD2qBbsq[0x0], yD2qBbsq[0x1] - 0x1e, 0x1, '' + dynamicDamage, color, 0x0);
                }
            }
        }
        if (!UI[nfmhvu6e('0x12f', '4arR')](nfmhvu6e('0x47f', '2o5F'), nfmhvu6e('0x327', 'kH)7'), nfmhvu6e('0x117', 'woG['), nfmhvu6e('0x3cc', 'fj0c'))) return;
        firedThisTick[RlsGrdcz[i]] == !![] ? ForceHead(RlsGrdcz[i]) : (Ragebot[nfmhvu6e('0x309', '5J(r')](RlsGrdcz[i]), info[RlsGrdcz[i]] = nfmhvu6e('0x218', '$%Jm'));
    }
}

function deg2rad(uDu2Xk2y) {
    return uDu2Xk2y * Math['PI'] / 0xb4;
}

function angle_to_vec(cF7qRc2d, nXvXzhnf) {
    var kGmVlada = deg2rad(cF7qRc2d),
        gQtXkpxn = deg2rad(nXvXzhnf),
        uSsHc9cv = Math[nfmhvu6e('0xe4', '5gvH')](kGmVlada),
        rLvZdwyq = Math[nfmhvu6e('0xbe', 'b(Lo')](kGmVlada),
        aQm2Hlen = Math[nfmhvu6e('0x29e', 'baA2')](gQtXkpxn),
        q7VhHmwz = Math[nfmhvu6e('0x22a', '[3Yt')](gQtXkpxn);
    return [rLvZdwyq * q7VhHmwz, rLvZdwyq * aQm2Hlen, -uSsHc9cv];
}

function trace(qTyChczh, rLsGrdcz) {
    var z3ZmCqg3 = angle_to_vec(rLsGrdcz[0x0], rLsGrdcz[0x1]),
        sD8jDhml = Entity[nfmhvu6e('0x40e', 'lUAx')](qTyChczh);
    sD8jDhml[0x2] += 0x32;
    var nFmHvu6e = [sD8jDhml[0x0] + z3ZmCqg3[0x0] * 0x2000, sD8jDhml[0x1] + z3ZmCqg3[0x1] * 0x2000, sD8jDhml[0x2] + z3ZmCqg3[0x2] * 0x2000],
        GQtXkpxn = Trace[nfmhvu6e('0xc2', 'o4jw')](qTyChczh, sD8jDhml, nFmHvu6e);
    if (GQtXkpxn[0x1] == 0x1) return;
    nFmHvu6e = [sD8jDhml[0x0] + z3ZmCqg3[0x0] * GQtXkpxn[0x1] * 0x2000, sD8jDhml[0x1] + z3ZmCqg3[0x1] * GQtXkpxn[0x1] * 0x2000, sD8jDhml[0x2] + z3ZmCqg3[0x2] * GQtXkpxn[0x1] * 0x2000];
    var KGmVlada = Math[nfmhvu6e('0x372', '%)yI')]((sD8jDhml[0x0] - nFmHvu6e[0x0]) * (sD8jDhml[0x0] - nFmHvu6e[0x0]) + (sD8jDhml[0x1] - nFmHvu6e[0x1]) * (sD8jDhml[0x1] - nFmHvu6e[0x1]) + (sD8jDhml[0x2] - nFmHvu6e[0x2]) * (sD8jDhml[0x2] - nFmHvu6e[0x2]));
    sD8jDhml = Render[nfmhvu6e('0x274', '[3Yt')](sD8jDhml);
    nFmHvu6e = Render[nfmhvu6e('0x274', '[3Yt')](nFmHvu6e);
    if (nFmHvu6e[0x2] != 0x1 || sD8jDhml[0x2] != 0x1) return;
    return KGmVlada;
}

function ReversedFreestanding() {
    if (!UI[nfmhvu6e('0x2d3', 'woG[')](nfmhvu6e('0x1d5', 'fj0c'), nfmhvu6e('0x3c0', 'S*9Q'), nfmhvu6e('0x35d', 'kH)7'), nfmhvu6e('0x336', 'p*Ju'))) return;
    var QTyChczh = Entity[nfmhvu6e('0x205', 'p*Ju')]();
    if (Entity[nfmhvu6e('0x36d', '2Nh3')](QTyChczh)) {
        var AQm2Hlen = Entity[nfmhvu6e('0x418', 'piRi')](QTyChczh);
        left_distance = trace(QTyChczh, [0x0, AQm2Hlen[0x1] - 0x21]);
        right_distance = trace(QTyChczh, [0x0, AQm2Hlen[0x1] + 0x21]);
        if (left_distance > right_distance) {
            if (UI[nfmhvu6e('0x187', 'woG[')](nfmhvu6e('0x231', 'G83^'), nfmhvu6e('0x406', 'WN@u'), nfmhvu6e('0x26', '2Nh3'))) UI[nfmhvu6e('0x233', 'KYKP')](nfmhvu6e('0x434', 'JO&F'), nfmhvu6e('0x39e', '5gvH'), nfmhvu6e('0x2b7', 'o4jw'));
        }
        if (right_distance > left_distance) {
            if (!UI[nfmhvu6e('0x2cf', 'G!uN')](nfmhvu6e('0x1fc', 'EWd6'), nfmhvu6e('0x2c7', '2sQP'), nfmhvu6e('0x21c', 'gFlY'))) UI[nfmhvu6e('0xca', '%)yI')](nfmhvu6e('0x137', 'Dm$W'), nfmhvu6e('0x3de', '2N^L'), nfmhvu6e('0x426', 'H]mc'));
        }
    }
}

function IsHoldingGrenade(CF7qRc2d) {
    if (Entity[nfmhvu6e('0x328', 'jG7w')](Entity[nfmhvu6e('0x25e', 'l1WZ')](CF7qRc2d)) == nfmhvu6e('0x31a', 'j#Hm') || Entity[nfmhvu6e('0x238', 'H]mc')](Entity[nfmhvu6e('0x319', 'G83^')](CF7qRc2d)) == nfmhvu6e('0x134', 's3n@') || Entity[nfmhvu6e('0x238', 'H]mc')](Entity[nfmhvu6e('0x50', 'baA2')](CF7qRc2d)) == nfmhvu6e('0x23f', 'H]mc')) return !![];
    return ![];
}

function DrawDanger(QKrV5bkq, YD2qBbsq, Q7VhHmwz) {
    Render[nfmhvu6e('0x201', '%)yI')](QKrV5bkq, YD2qBbsq, 0xf, [0x0, 0x0, 0x0, 0x7d]);
    Render[nfmhvu6e('0x2db', '5gvH')](QKrV5bkq, YD2qBbsq, 0xf, Q7VhHmwz);
    Render[nfmhvu6e('0x3a1', 'vc&n')](QKrV5bkq - 0.5, YD2qBbsq - 0x7, 0x1, '!', [0xff, 0xff, 0xff, 0xc8]);
}

function DrawToggles() {
    if (!UI[nfmhvu6e('0x1ec', 'vc&n')](nfmhvu6e('0x354', 'jG7w'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x192', 'H]mc'), nfmhvu6e('0x371', 'S*9Q'))) return;
    var UDu2Xk2y = Global[nfmhvu6e('0x246', 'kH)7')](),
        RLvZdwyq;
    RLvZdwyq = UI[nfmhvu6e('0x213', 'gFlY')](nfmhvu6e('0x45c', 'i58('), nfmhvu6e('0x23b', 'p*Ju'), nfmhvu6e('0x17', 'zBb8'), nfmhvu6e('0xb1', 'jG7w'));
    if (!UI[nfmhvu6e('0x3b7', '5J(r')](nfmhvu6e('0x45c', 'i58('), nfmhvu6e('0x150', 'o4jw'), nfmhvu6e('0x1c3', 'b(Lo'), nfmhvu6e('0x2e6', 'o4jw')) && UI[nfmhvu6e('0x44f', 'X$GI')](nfmhvu6e('0x38b', 'WN@u'), nfmhvu6e('0x313', ']iue'), nfmhvu6e('0x3b3', '5J(r'), nfmhvu6e('0x79', '4K7r'))) {
        if (UI[nfmhvu6e('0x42', 'lUAx')](nfmhvu6e('0x43a', '4arR'), nfmhvu6e('0x451', 'vc&n'), nfmhvu6e('0x3b9', 's3n@'))) {
            if (nfmhvu6e('0xb4', 'G!uN') === nfmhvu6e('0x51', 'zBb8')) Render[nfmhvu6e('0x2df', ')7!]')]([
                [UDu2Xk2y[0x0] / 0x2 - 0x31, UDu2Xk2y[0x1] / 0x2 + 0x9],
                [UDu2Xk2y[0x0] / 0x2 - 0x41, UDu2Xk2y[0x1] / 0x2],
                [UDu2Xk2y[0x0] / 0x2 - 0x31, UDu2Xk2y[0x1] / 0x2 - 0x9]
            ], [0x0, 0x0, 0x0, 0x50]), Render[nfmhvu6e('0x60', '2sQP')]([
                [UDu2Xk2y[0x0] / 0x2 + 0x31, UDu2Xk2y[0x1] / 0x2 - 0x9],
                [UDu2Xk2y[0x0] / 0x2 + 0x41, UDu2Xk2y[0x1] / 0x2],
                [UDu2Xk2y[0x0] / 0x2 + 0x31, UDu2Xk2y[0x1] / 0x2 + 0x9]
            ], RLvZdwyq);
            else {
                function UJfXs77m() {
                    fov = currentFov;
                    closestPlayer = enemiesArr[i];
                }
            }
        } else Render[nfmhvu6e('0x42e', 'KYKP')]([
            [UDu2Xk2y[0x0] / 0x2 - 0x31, UDu2Xk2y[0x1] / 0x2 + 0x9],
            [UDu2Xk2y[0x0] / 0x2 - 0x41, UDu2Xk2y[0x1] / 0x2],
            [UDu2Xk2y[0x0] / 0x2 - 0x31, UDu2Xk2y[0x1] / 0x2 - 0x9]
        ], RLvZdwyq), Render[nfmhvu6e('0x17d', 'd9R5')]([
            [UDu2Xk2y[0x0] / 0x2 + 0x31, UDu2Xk2y[0x1] / 0x2 - 0x9],
            [UDu2Xk2y[0x0] / 0x2 + 0x41, UDu2Xk2y[0x1] / 0x2],
            [UDu2Xk2y[0x0] / 0x2 + 0x31, UDu2Xk2y[0x1] / 0x2 + 0x9]
        ], [0x0, 0x0, 0x0, 0x50]);
    }
    var NFmHvu6e = GetActiveIndicators(),
        RLsGrdcz = 0x0;
    if (UI[nfmhvu6e('0x3a6', 'kH)7')](nfmhvu6e('0x459', 'woG['), nfmhvu6e('0x490', '2N^L'), nfmhvu6e('0x110', '5gvH')) && getDropdownValue(UI[nfmhvu6e('0x11b', '[3Yt')](nfmhvu6e('0x156', '23qz'), nfmhvu6e('0x2c0', '2o5F'), nfmhvu6e('0x35d', 'kH)7'), nfmhvu6e('0x34', 's3n@')), 0x1)) {
        RLsGrdcz += 0x1;
        Render[nfmhvu6e('0x128', 'fj0c')](UDu2Xk2y[0x0] / 0x2, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x14, 0x1, 'DT', [0x0, 0xff, 0x0, 0xff], 0x3);
        const Z3ZmCqg3 = -0xff * Exploit[nfmhvu6e('0x350', 'p*Ju')]();
        Render[nfmhvu6e('0x41c', '4arR')](UDu2Xk2y[0x0] / 0x2 - 0x6, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x2 + 0x1b, 0xd, 0x4, [0x0, 0x0, 0x0, 0x16]), Render[nfmhvu6e('0x33f', 'j#Hm')](UDu2Xk2y[0x0] / 0x2 - 0x5, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x3 + 0x1b, (Exploit[nfmhvu6e('0x466', '2Nh3')]() + 0.1) * 0xa, 0x2, 0x1, [Z3ZmCqg3, 0xff, 0x0, 0x46], [Z3ZmCqg3, 0xff, 0x0, 0xc8]);
    }
    UI[nfmhvu6e('0x108', 'p*Ju')](nfmhvu6e('0x391', 'JO&F'), nfmhvu6e('0x290', '$%Jm'), nfmhvu6e('0x393', 'SH9y'), nfmhvu6e('0x377', '5J(r')) && getDropdownValue(UI[nfmhvu6e('0x56', 'SH9y')](nfmhvu6e('0x6', 'EWd6'), nfmhvu6e('0x313', ']iue'), nfmhvu6e('0x40d', 'vc&n'), nfmhvu6e('0xe9', 'Dm$W')), 0x0) && (RLsGrdcz += 0x1, Render[nfmhvu6e('0x15d', '2N^L')](UDu2Xk2y[0x0] / 0x2, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x14, 0x1, nfmhvu6e('0x2a0', '%)yI'), [0xff, 0xff, 0x0, 0xff], 0x3));
    if (UI[nfmhvu6e('0x2cf', 'G!uN')](nfmhvu6e('0x258', '[3Yt'), nfmhvu6e('0x55', 'fj0c'), nfmhvu6e('0x399', '$%Jm')) && getDropdownValue(UI[nfmhvu6e('0x2a4', '2o5F')](nfmhvu6e('0xe0', 'xdk%'), nfmhvu6e('0x121', '4K7r'), nfmhvu6e('0x117', 'woG['), nfmhvu6e('0x202', '%)yI')), 0x3)) {
        if (nfmhvu6e('0x6d', '8rvd') !== nfmhvu6e('0x3da', 'lUAx')) {
            function USsHc9cv() {
                if (!UI[nfmhvu6e('0x210', '23qz')](nfmhvu6e('0xe', 'hGOu'), nfmhvu6e('0x32f', '5J(r'), nfmhvu6e('0x310', '8rvd'), nfmhvu6e('0x72', 'KYKP'))) return;
                var SD8jDhml = Entity[nfmhvu6e('0x1d4', 'piRi')](Entity[nfmhvu6e('0x13f', 'piRi')](Entity[nfmhvu6e('0x464', '%)yI')]()));
                if (SD8jDhml != nfmhvu6e('0x353', '5gvH') && SD8jDhml != nfmhvu6e('0x481', 'H]mc')) return;
                var NXvXzhnf = Entity[nfmhvu6e('0x91', '[3Yt')](Entity[nfmhvu6e('0x1e2', 'JO&F')](), nfmhvu6e('0x8a', 'gFlY'), nfmhvu6e('0x10f', 'WUka'));
                !(NXvXzhnf & 0x1 << 0x0) && !(NXvXzhnf & 0x1 << 0x12) && (target = Ragebot[nfmhvu6e('0x1f6', 'b(Lo')](), value = UI[nfmhvu6e('0x484', '$%Jm')](nfmhvu6e('0x354', 'jG7w'), nfmhvu6e('0x3c0', 'S*9Q'), nfmhvu6e('0x140', 's3n@'), nfmhvu6e('0x2d', '[3Yt')), Ragebot[nfmhvu6e('0x16c', 'kH)7')](target, value));
            }
        } else RLsGrdcz += 0x1, Render[nfmhvu6e('0x128', 'fj0c')](UDu2Xk2y[0x0] / 0x2, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x14, 0x1, nfmhvu6e('0x3e7', '2o5F'), [0x0, 0xff, 0xff, 0xff], 0x3);
    }
    UI[nfmhvu6e('0x7b', 'JO&F')](nfmhvu6e('0x417', 'KYKP'), nfmhvu6e('0x230', 'hGOu'), nfmhvu6e('0x220', 'Dm$W')) && getDropdownValue(UI[nfmhvu6e('0x411', 'j#Hm')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x339', 'lUAx'), nfmhvu6e('0x270', 'm@IA'), nfmhvu6e('0x168', 'woG[')), 0x2) && (RLsGrdcz += 0x1, Render[nfmhvu6e('0x1d3', '[3Yt')](UDu2Xk2y[0x0] / 0x2, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x14, 0x1, nfmhvu6e('0x146', '23qz'), [0x9b, 0xff, 0x9b, 0xff], 0x3));
    UI[nfmhvu6e('0x7b', 'JO&F')](nfmhvu6e('0xf6', '5gvH'), nfmhvu6e('0x382', 'baA2'), nfmhvu6e('0x1e0', ')7!]'), nfmhvu6e('0xea', 'G!uN')) && getDropdownValue(UI[nfmhvu6e('0x2ec', '8rvd')](nfmhvu6e('0x116', 'X$GI'), nfmhvu6e('0x257', 'X$GI'), nfmhvu6e('0x370', 'WUka'), nfmhvu6e('0xf3', 'KYKP')), 0x4) && (RLsGrdcz += 0x1, Render[nfmhvu6e('0x2eb', 'o4jw')](UDu2Xk2y[0x0] / 0x2, UDu2Xk2y[0x1] / 0x2 + (NFmHvu6e - RLsGrdcz) * 0xa + 0x14, 0x1, nfmhvu6e('0xc3', 'KYKP'), [0xff, 0x80, 0x0, 0xff], 0x3));
}

function DrawDangerSigns() {
    if (!UI[nfmhvu6e('0x3b8', '43eQ')](nfmhvu6e('0x29', 'WUka'), nfmhvu6e('0x25f', 'fj0c'), nfmhvu6e('0x153', 'xdk%'))) return;
    var rlSGrdcz = Entity[nfmhvu6e('0x6c', 'gFlY')]();
    for (i = 0x0; i < rlSGrdcz[nfmhvu6e('0x1e9', 'hUIv')]; i++) {
        if (!Entity[nfmhvu6e('0x292', ']iue')](rlSGrdcz[i])) continue;
        if (!Entity[nfmhvu6e('0x10d', 'lUAx')](rlSGrdcz[i])) continue;
        if (Entity[nfmhvu6e('0x1a4', 'baA2')](rlSGrdcz[i])) continue;
        var sd8JDhml = Entity[nfmhvu6e('0x36f', 'S*9Q')](rlSGrdcz[i]),
            z3zMCqg3 = sd8JDhml[0x3] - sd8JDhml[0x1];
        z3zMCqg3 /= 0x2;
        z3zMCqg3 += sd8JDhml[0x1];
        if (IsHoldingGrenade(rlSGrdcz[i])) DrawDanger(z3zMCqg3, sd8JDhml[0x2] - 0x2d, [0xff, 0xff, 0x0, 0xff]);
        if (Entity[nfmhvu6e('0x1d4', 'piRi')](Entity[nfmhvu6e('0x47c', 'EWd6')](rlSGrdcz[i])) == nfmhvu6e('0x19b', 'o4jw')) DrawDanger(z3zMCqg3, sd8JDhml[0x2] - 0x2d, [0xff, 0x0, 0x0, 0xff]);
    }
}

function DrawIndicators() {
    if (!UI[nfmhvu6e('0xd8', 'G!uN')](nfmhvu6e('0x31b', '5J(r'), nfmhvu6e('0x224', 'KYKP'), nfmhvu6e('0x3fb', 'p*Ju'), nfmhvu6e('0x307', 'lUAx'))) return;
    var nfMHvu6e = Global[nfmhvu6e('0x185', 'o4jw')]();
    if (!UI[nfmhvu6e('0x484', '$%Jm')](nfmhvu6e('0x476', 'lUAx'), nfmhvu6e('0x327', 'kH)7'), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0xb5', '8rvd'))) return;
    var ujFXs77m = Entity[nfmhvu6e('0x312', '4arR')]();
    for (i = 0x0; i < ujFXs77m[nfmhvu6e('0x3eb', 's3n@')]; i++) {
        if (!Entity[nfmhvu6e('0x36', 'b(Lo')](ujFXs77m[i])) continue;
        if (!Entity[nfmhvu6e('0xf0', 'G!uN')](ujFXs77m[i])) continue;
        if (Entity[nfmhvu6e('0x23c', 'kH)7')](ujFXs77m[i])) continue;
        var cf7QRc2d = Entity[nfmhvu6e('0x31f', '8rvd')](ujFXs77m[i]),
            q7vHHmwz = cf7QRc2d[0x3] - cf7QRc2d[0x1];
        q7vHHmwz /= 0x2;
        q7vHHmwz += cf7QRc2d[0x1];
        switch (info[ujFXs77m[i]]) {
        case nfmhvu6e('0x198', '23qz'):
            Render[nfmhvu6e('0x30', '43eQ')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0xd7, 0xff, 0x96, 0xff], font);
            break;
        case nfmhvu6e('0x0', 'Dm$W'):
            Render[nfmhvu6e('0x252', 'H]mc')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0xff, 0xff, 0xff, 0xff], font);
            break;
        case nfmhvu6e('0x191', 'o4jw'):
            Render[nfmhvu6e('0x2fd', 'o4jw')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0x0, 0xff, 0xff, 0xff], font);
            break;
        case nfmhvu6e('0x2a2', 'woG['):
            Render[nfmhvu6e('0x241', '5J(r')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0xc7, 0x91, 0x12, 0xff], font);
            break;
        case nfmhvu6e('0xd', '4K7r'):
            Render[nfmhvu6e('0x3e9', 'G83^')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0x3f, 0x85, 0xfc, 0xff], font);
            break;
        case nfmhvu6e('0x1c4', 'fj0c'):
            Render[nfmhvu6e('0x2fd', 'o4jw')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0x3f, 0x85, 0xfc, 0xff], font);
            break;
        case 'X2':
            Render[nfmhvu6e('0x39f', '2N^L')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0x0, 0x80, 0xf0, 0xff], font);
            break;
        case nfmhvu6e('0x1dc', '23qz'):
            Render[nfmhvu6e('0x66', 'm@IA')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0xff, 0x7d, 0xff, 0xff], font);
            break;
        case nfmhvu6e('0x44d', 'G!uN'):
            Render[nfmhvu6e('0xd3', '2sQP')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0x9b, 0xff, 0xfc, 0xff], font);
            break;
        case nfmhvu6e('0x23e', 'X$GI'):
            Render[nfmhvu6e('0x40a', '[3Yt')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0xff, 0xff, 0x96, 0xff], font);
            break;
        case nfmhvu6e('0xb7', 'WN@u'):
            Render[nfmhvu6e('0x40a', '[3Yt')](q7vHHmwz, cf7QRc2d[0x2] - 0x19, 0x1, info[ujFXs77m[i]], [0xff, 0x7d, 0xff, 0xff], font);
            break;
        }
        if (UI[nfmhvu6e('0x1a8', 'm@IA')](nfmhvu6e('0x166', 'G!uN'), nfmhvu6e('0x462', '[3Yt'), nfmhvu6e('0x2d9', 'G!uN'), nfmhvu6e('0x44a', 'lUAx')) && safeTargets[ujFXs77m[i]]) Render[nfmhvu6e('0x427', 'p*Ju')](q7vHHmwz, cf7QRc2d[0x2] - 0x23, 0x1, nfmhvu6e('0x115', '$%Jm'), [0xde, 0xab, 0xff, 0xff], font);
    }
}

function GetHitboxName(gqTXkpxn) {
    var aqM2Hlen = '';
    switch (gqTXkpxn) {
    case 0x0:
        aqM2Hlen = nfmhvu6e('0x81', 'jG7w');
        break;
    case 0x1:
        aqM2Hlen = nfmhvu6e('0x65', 'o4jw');
        break;
    case 0x2:
        aqM2Hlen = nfmhvu6e('0xd1', '23qz');
        break;
    case 0x3:
        aqM2Hlen = nfmhvu6e('0x151', 'piRi');
        break;
    case 0x4:
        aqM2Hlen = nfmhvu6e('0x165', ']iue');
        break;
    case 0x5:
        aqM2Hlen = nfmhvu6e('0x26c', 'p*Ju');
        break;
    case 0x6:
        aqM2Hlen = nfmhvu6e('0x129', 'woG[');
        break;
    case 0x7:
        aqM2Hlen = nfmhvu6e('0x324', 'EWd6');
        break;
    case 0x8:
        aqM2Hlen = nfmhvu6e('0x1c8', 's3n@');
        break;
    case 0x9:
        aqM2Hlen = nfmhvu6e('0x7a', 'o4jw');
        break;
    case 0xa:
        aqM2Hlen = nfmhvu6e('0x78', 'fj0c');
        break;
    case 0xb:
        aqM2Hlen = nfmhvu6e('0x253', 'H]mc');
        break;
    case 0xc:
        aqM2Hlen = nfmhvu6e('0x1e', 'WUka');
        break;
    case 0xd:
        aqM2Hlen = nfmhvu6e('0x299', '8rvd');
        break;
    case 0xe:
        aqM2Hlen = nfmhvu6e('0x16', 'jG7w');
        break;
    case 0xf:
        aqM2Hlen = nfmhvu6e('0x3b2', '4K7r');
        break;
    case 0x10:
        aqM2Hlen = nfmhvu6e('0x222', 'l1WZ');
        break;
    case 0x11:
        aqM2Hlen = nfmhvu6e('0x3ab', 'woG[');
        break;
    case 0x12:
        aqM2Hlen = nfmhvu6e('0x3ac', '2N^L');
        break;
    default:
        aqM2Hlen = nfmhvu6e('0x1ad', 'kH)7');
    }
    return aqM2Hlen;
}

function RagebotLogs() {
    if (!UI[nfmhvu6e('0x114', 'JO&F')](nfmhvu6e('0xf9', '%)yI'), nfmhvu6e('0x121', '4K7r'), nfmhvu6e('0x2e2', 'S*9Q'), nfmhvu6e('0x4a', 's3n@'))) return;
    target = Event[nfmhvu6e('0x46e', 'o4jw')](nfmhvu6e('0x30e', 'KYKP'));
    targetName = Entity[nfmhvu6e('0x1f9', 'lUAx')](target);
    hitbox = Event[nfmhvu6e('0x16d', '$%Jm')](nfmhvu6e('0xc9', 's3n@'));
    hitchance = Event[nfmhvu6e('0x3be', '5gvH')](nfmhvu6e('0x3d3', 'd9R5'));
    safepoint = Event[nfmhvu6e('0x45a', 'j#Hm')](nfmhvu6e('0xba', 'fj0c'));
    exploit = Event[nfmhvu6e('0x100', '8rvd')](nfmhvu6e('0x28c', 'lUAx'));
    log = nfmhvu6e('0x3f4', 'S*9Q') + targetName + ' (' + target + ')' + nfmhvu6e('0x2f6', 'i58(') + GetHitboxName(hitbox) + nfmhvu6e('0x3fe', 'l1WZ') + hitchance + nfmhvu6e('0xd0', 'd9R5') + safepoint + nfmhvu6e('0x1a1', 'WUka') + exploit + nfmhvu6e('0x3c3', '5gvH') + info[target];
    log += '\x0a';
    Cheat[nfmhvu6e('0xc1', 'piRi')]([0x0, 0xff, 0x0, 0xff], log);
}

function SafepointOnLimbs() {
    if (!UI[nfmhvu6e('0x11b', '[3Yt')](nfmhvu6e('0x357', 'd9R5'), nfmhvu6e('0x28a', '43eQ'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x2da', '2o5F'))) return;
    Ragebot[nfmhvu6e('0x44b', 'G!uN')](0xc);
    Ragebot[nfmhvu6e('0x5f', 'kH)7')](0xb);
    Ragebot[nfmhvu6e('0x3f9', 'lUAx')](0xa);
    Ragebot[nfmhvu6e('0x3e6', 'i58(')](0x9);
}

function OverrideMinimumDamage() {
    if (!UI[nfmhvu6e('0x28b', '2o5F')](nfmhvu6e('0x374', 'gFlY'), nfmhvu6e('0xcb', 'G!uN'), nfmhvu6e('0x29c', '2Nh3'), nfmhvu6e('0x13b', '4K7r'))) return;
    var yd2QBbsq = Entity[nfmhvu6e('0x453', 'j#Hm')]();
    value = UI[nfmhvu6e('0x2ff', 'l1WZ')](nfmhvu6e('0x354', 'jG7w'), nfmhvu6e('0x33c', 'hUIv'), nfmhvu6e('0x342', 'jG7w'), nfmhvu6e('0x2de', 'piRi'));
    for (i = 0x0; i < yd2QBbsq[nfmhvu6e('0x381', 'EWd6')]; i++) {
        Ragebot[nfmhvu6e('0x400', '4K7r')](yd2QBbsq[i], value);
        info[yd2QBbsq[i]] = nfmhvu6e('0x487', 'j#Hm');
    }
}

function ForceConditions() {
    AimForHeadIfShooting();
    if (!UI[nfmhvu6e('0x39', 'p*Ju')](nfmhvu6e('0x32c', '4arR'), nfmhvu6e('0x111', ')7!]'), nfmhvu6e('0x1e0', ')7!]'), nfmhvu6e('0x23d', 'kH)7'))) return;
    if (UI[nfmhvu6e('0x4c', 'H]mc')](nfmhvu6e('0x391', 'JO&F'), nfmhvu6e('0x3c9', 'm@IA'), nfmhvu6e('0x40d', 'vc&n'), nfmhvu6e('0x472', 'o4jw'))) return;
    if (UI[nfmhvu6e('0x3b7', '5J(r')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x32f', '5J(r'), nfmhvu6e('0x192', 'H]mc'), nfmhvu6e('0x407', 'H]mc'))) return;
    var qkRV5bkq = Entity[nfmhvu6e('0x45d', 'i58(')](),
        rlVZdwyq = UI[nfmhvu6e('0x264', 'S*9Q')](nfmhvu6e('0x368', 'H]mc'), nfmhvu6e('0x1bf', 'SH9y'), nfmhvu6e('0x29c', '2Nh3'), nfmhvu6e('0x1b3', 'lUAx')),
        udU2Xk2y = UI[nfmhvu6e('0x3e4', '2N^L')](nfmhvu6e('0x29', 'WUka'), nfmhvu6e('0x5e', 'j#Hm'), nfmhvu6e('0x219', 'KYKP'), nfmhvu6e('0x2b5', 'baA2')),
        nxVXzhnf = UI[nfmhvu6e('0x12c', '2sQP')](nfmhvu6e('0x172', 'kH)7'), nfmhvu6e('0x111', ')7!]'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x479', ')7!]')),
        kgMVlada = UI[nfmhvu6e('0x6f', 'lUAx')](nfmhvu6e('0x139', 'woG['), nfmhvu6e('0x25f', 'fj0c'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x1c', 'gFlY'));
    for (i = 0x0; i < qkRV5bkq[nfmhvu6e('0x1e9', 'hUIv')]; i++) {
        if (!Entity[nfmhvu6e('0x8', 'zBb8')](qkRV5bkq[i])) continue;
        if (!Entity[nfmhvu6e('0x211', 'Dm$W')](qkRV5bkq[i])) continue;
        if (Entity[nfmhvu6e('0x133', '2o5F')](qkRV5bkq[i])) continue;
        mode = '';
        info[qkRV5bkq[i]] = nfmhvu6e('0x390', '2Nh3');
        safeTargets[qkRV5bkq[i]] = ![];
        var usSHc9cv = Ragebot[nfmhvu6e('0x22e', 'i58(')]();
        getDropdownValue(kgMVlada, 0x0) && IsLethal(qkRV5bkq[i]) && (safeTargets[qkRV5bkq[i]] = !![], Ragebot[nfmhvu6e('0x273', 'baA2')](qkRV5bkq[i]));
        if (getDropdownValue(kgMVlada, 0x1) && IsSlowWalking(qkRV5bkq[i])) {
            if (nfmhvu6e('0x3b6', 's3n@') !== nfmhvu6e('0x64', '5J(r')) safeTargets[qkRV5bkq[i]] = !![], Ragebot[nfmhvu6e('0x35f', 'vc&n')](qkRV5bkq[i]);
            else {
                function qtYChczh() {
                    if (!UI[nfmhvu6e('0x114', 'JO&F')](nfmhvu6e('0x11f', 'G83^'), nfmhvu6e('0x224', 'KYKP'), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0x4b', 'hGOu'))) return;
                    usSHc9cv = Event[nfmhvu6e('0x402', 'X$GI')](nfmhvu6e('0x395', '$%Jm'));
                    targetName = Entity[nfmhvu6e('0x157', 'baA2')](usSHc9cv);
                    hitbox = Event[nfmhvu6e('0x18f', 'xdk%')](nfmhvu6e('0x77', 'piRi'));
                    hitchance = Event[nfmhvu6e('0x39d', 'G83^')](nfmhvu6e('0x3d3', 'd9R5'));
                    safepoint = Event[nfmhvu6e('0x1db', 'b(Lo')](nfmhvu6e('0x1da', '8rvd'));
                    exploit = Event[nfmhvu6e('0x3be', '5gvH')](nfmhvu6e('0x385', 'Dm$W'));
                    log = nfmhvu6e('0xa', '2N^L') + targetName + ' (' + usSHc9cv + ')' + nfmhvu6e('0x2a7', 'JO&F') + GetHitboxName(hitbox) + nfmhvu6e('0x1eb', '5gvH') + hitchance + nfmhvu6e('0x2fe', 'i58(') + safepoint + nfmhvu6e('0x21e', '4arR') + exploit + nfmhvu6e('0x425', 'piRi') + info[usSHc9cv];
                    log += '\x0a';
                    Cheat[nfmhvu6e('0x1c2', ')7!]')]([0x0, 0xff, 0x0, 0xff], log);
                }
            }
        }
        if (getDropdownValue(kgMVlada, 0x3) && IsInAir(qkRV5bkq[i])) {
            if (nfmhvu6e('0x3fd', 'baA2') !== nfmhvu6e('0x40', 'Dm$W')) safeTargets[qkRV5bkq[i]] = !![], Ragebot[nfmhvu6e('0x144', 'b(Lo')](qkRV5bkq[i]);
            else {
                function UsSHc9cv() {
                    if (Entity[nfmhvu6e('0x2af', 'G!uN')](Entity[nfmhvu6e('0x25e', 'l1WZ')](entity_id)) == nfmhvu6e('0x1a0', 'WN@u') || Entity[nfmhvu6e('0x36e', '23qz')](Entity[nfmhvu6e('0x226', 'WN@u')](entity_id)) == nfmhvu6e('0x36b', 'kH)7') || Entity[nfmhvu6e('0x2af', 'G!uN')](Entity[nfmhvu6e('0x321', 'H]mc')](entity_id)) == nfmhvu6e('0x35c', '23qz')) return !![];
                    return ![];
                }
            }
        }
        getDropdownValue(kgMVlada, 0x2) && IsStanding(qkRV5bkq[i]) && !IsInAir(qkRV5bkq[i]) && (safeTargets[qkRV5bkq[i]] = !![], Ragebot[nfmhvu6e('0x2e3', '8rvd')](qkRV5bkq[i]));
        getDropdownValue(kgMVlada, 0x4) && IsCrouch(qkRV5bkq[i]) && (safeTargets[qkRV5bkq[i]] = !![], Ragebot[nfmhvu6e('0x2d2', 'fj0c')](qkRV5bkq[i]));
        if (AttemptTwoShotKill(qkRV5bkq[i]) == !![] && UI[nfmhvu6e('0x415', 'b(Lo')](nfmhvu6e('0x2bb', '8rvd'), nfmhvu6e('0x28a', '43eQ'), nfmhvu6e('0x366', 'H]mc'))) {
            if (nfmhvu6e('0x1ce', 'p*Ju') !== nfmhvu6e('0x2a8', 's3n@')) {
                info[qkRV5bkq[i]] = 'X2';
                continue;
            } else {
                function Cf7QRc2d() {
                    firedThisTick[qkRV5bkq[i]] = ![];
                }
            }
        }
        if (getDropdownValue(nxVXzhnf, 0x0) && IsLethal(qkRV5bkq[i])) {
            if (usSHc9cv == qkRV5bkq[i]) ForceBaim(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x405', '2N^L');
            continue;
        }
        if (getDropdownValue(udU2Xk2y, 0x3) && firedThisTick[qkRV5bkq[i]] == !![]) {
            ForceHead(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x1e8', 'xdk%');
            continue;
        }
        if (getDropdownValue(nxVXzhnf, 0x1) && IsSlowWalking(qkRV5bkq[i])) {
            if (usSHc9cv == qkRV5bkq[i]) ForceBaim(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x22f', 'G!uN');
            continue;
        }
        if (getDropdownValue(nxVXzhnf, 0x3) && IsInAir(qkRV5bkq[i])) {
            if (usSHc9cv == qkRV5bkq[i]) ForceBaim(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x8f', '5gvH');
            continue;
        }
        if (getDropdownValue(nxVXzhnf, 0x2) && IsStanding(qkRV5bkq[i]) && !IsInAir(qkRV5bkq[i])) {
            if (usSHc9cv == qkRV5bkq[i]) ForceBaim(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x1ef', 'hGOu');
            continue;
        }
        if (getDropdownValue(nxVXzhnf, 0x4) && IsCrouch(qkRV5bkq[i])) {
            if (nfmhvu6e('0x33b', 'o4jw') !== nfmhvu6e('0x3b4', 'JO&F')) {
                function Z3zMCqg3() {
                    var Sd8JDhml = Math['PI'];
                    return radians * (0xb4 / Sd8JDhml);
                }
            } else {
                if (usSHc9cv == qkRV5bkq[i]) ForceBaim(qkRV5bkq[i]);
                info[qkRV5bkq[i]] = nfmhvu6e('0x3bc', '5J(r');
                continue;
            }
        }
        if (getDropdownValue(udU2Xk2y, 0x1) && IsInAir(qkRV5bkq[i])) {
            ForceHead(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x1d8', '%)yI');
            continue;
        }
        if (getDropdownValue(udU2Xk2y, 0x0) && GetMaxDesync(qkRV5bkq[i]) < rlVZdwyq && !IsInAir(qkRV5bkq[i])) {
            ForceHead(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x1b1', '$%Jm');
            continue;
        }
        if (getDropdownValue(udU2Xk2y, 0x2) && IsCrouchTerrorist(qkRV5bkq[i])) {
            ForceHead(qkRV5bkq[i]);
            info[qkRV5bkq[i]] = nfmhvu6e('0x244', 'piRi');
            continue;
        }
        DisableBaim();
    }
}

function Draw() {
    font == null && (font = Render[nfmhvu6e('0x43c', '5J(r')](nfmhvu6e('0x1f8', 'lUAx'), 0x7, 0x2bc));
    if (UI[nfmhvu6e('0x44', 'o4jw')]()) {
        if (getDropdownValue(UI[nfmhvu6e('0x2d3', 'woG[')](nfmhvu6e('0x45c', 'i58('), nfmhvu6e('0x32f', '5J(r'), nfmhvu6e('0x178', 'gFlY'), nfmhvu6e('0xd2', 'S*9Q')), 0x1)) UI[nfmhvu6e('0x67', 'vc&n')](nfmhvu6e('0x373', '[3Yt'), nfmhvu6e('0x294', '23qz'), nfmhvu6e('0x34a', 'JO&F'), nfmhvu6e('0xaf', 'vc&n'), setDropdownValue(UI[nfmhvu6e('0xbd', 'd9R5')](nfmhvu6e('0x1a5', 'KYKP'), nfmhvu6e('0x1cd', '2N^L'), nfmhvu6e('0x3d', 'baA2'), nfmhvu6e('0x9b', '$%Jm')), 0x3, ![]));
        if (getDropdownValue(UI[nfmhvu6e('0x19f', 'hUIv')](nfmhvu6e('0x1a5', 'KYKP'), nfmhvu6e('0x3c0', 'S*9Q'), nfmhvu6e('0x9f', 'xdk%'), nfmhvu6e('0x5c', 'i58(')), 0x2)) UI[nfmhvu6e('0x212', '4arR')](nfmhvu6e('0x43d', 'hUIv'), nfmhvu6e('0x462', '[3Yt'), nfmhvu6e('0x7c', 'X$GI'), nfmhvu6e('0x3f2', 'l1WZ'), setDropdownValue(UI[nfmhvu6e('0x12c', '2sQP')](nfmhvu6e('0xe0', 'xdk%'), nfmhvu6e('0x23b', 'p*Ju'), nfmhvu6e('0x1e0', ')7!]'), nfmhvu6e('0xde', 'gFlY')), 0x4, ![]));
        UI[nfmhvu6e('0xa1', '5J(r')](nfmhvu6e('0x163', ']iue'), nfmhvu6e('0x215', '2Nh3'), nfmhvu6e('0x310', '8rvd'), nfmhvu6e('0x88', '$%Jm'), UI[nfmhvu6e('0x2ff', 'l1WZ')](nfmhvu6e('0x346', '2sQP'), nfmhvu6e('0x6b', 'hGOu'), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0x33e', '[3Yt')) ? !![] : ![]), UI[nfmhvu6e('0x47d', '%)yI')](nfmhvu6e('0x45c', 'i58('), nfmhvu6e('0x6b', 'hGOu'), nfmhvu6e('0x192', 'H]mc'), nfmhvu6e('0x34b', 'xdk%'), UI[nfmhvu6e('0xbd', 'd9R5')](nfmhvu6e('0x1a5', 'KYKP'), nfmhvu6e('0x3c8', 'woG['), nfmhvu6e('0x393', 'SH9y'), nfmhvu6e('0xa9', 'd9R5')) ? !![] : ![]), UI[nfmhvu6e('0x245', 'G!uN')](nfmhvu6e('0x284', 'piRi'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x69', '5gvH'), UI[nfmhvu6e('0x261', 'G83^')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x3d9', 'Dm$W'), nfmhvu6e('0x35d', 'kH)7'), nfmhvu6e('0x194', '4arR')) ? !![] : ![]), UI[nfmhvu6e('0xcc', 'b(Lo')](nfmhvu6e('0x93', '43eQ'), nfmhvu6e('0x19', 'JO&F'), nfmhvu6e('0x265', 'fj0c'), nfmhvu6e('0x18a', '2Nh3'), UI[nfmhvu6e('0xf8', 'fj0c')](nfmhvu6e('0x2bb', '8rvd'), nfmhvu6e('0x5e', 'j#Hm'), nfmhvu6e('0x2e2', 'S*9Q'), nfmhvu6e('0x23d', 'kH)7')) ? !![] : ![]), UI[nfmhvu6e('0x3d5', 'zBb8')](nfmhvu6e('0x11f', 'G83^'), nfmhvu6e('0xed', 'd9R5'), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0x2d5', '43eQ'), UI[nfmhvu6e('0x14', ')7!]')](nfmhvu6e('0x346', '2sQP'), nfmhvu6e('0x3c0', 'S*9Q'), nfmhvu6e('0x98', '4K7r'), nfmhvu6e('0x13', '[3Yt')) ? !![] : ![]), UI[nfmhvu6e('0x2f2', '4arR')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x404', '5gvH'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x2ad', 'WUka'), UI[nfmhvu6e('0x123', 'zBb8')](nfmhvu6e('0x76', '2N^L'), nfmhvu6e('0x19', 'JO&F'), nfmhvu6e('0x34a', 'JO&F'), nfmhvu6e('0x2c', 'xdk%')) ? !![] : ![]), UI[nfmhvu6e('0x130', 'vc&n')](nfmhvu6e('0x354', 'jG7w'), nfmhvu6e('0x382', 'baA2'), nfmhvu6e('0x270', 'm@IA'), nfmhvu6e('0x189', 'KYKP'), UI[nfmhvu6e('0x234', '4arR')](nfmhvu6e('0x40c', 'l1WZ'), nfmhvu6e('0x32f', '5J(r'), nfmhvu6e('0x2e2', 'S*9Q'), nfmhvu6e('0x1cb', 'X$GI')) ? !![] : ![]), UI[nfmhvu6e('0x27', '4K7r')](nfmhvu6e('0x93', '43eQ'), nfmhvu6e('0x5e', 'j#Hm'), nfmhvu6e('0x393', 'SH9y'), nfmhvu6e('0x22b', '5gvH'), UI[nfmhvu6e('0x446', 'H]mc')](nfmhvu6e('0x166', 'G!uN'), nfmhvu6e('0x3d9', 'Dm$W'), nfmhvu6e('0x2ab', 'hGOu'), nfmhvu6e('0x31c', ')7!]')) ? !![] : ![]), delta = ![], getDropdownValue(UI[nfmhvu6e('0x39', 'p*Ju')](nfmhvu6e('0xe0', 'xdk%'), nfmhvu6e('0x16b', 'G83^'), nfmhvu6e('0x393', 'SH9y'), nfmhvu6e('0x2f5', 'lUAx')), 0x0) && UI[nfmhvu6e('0x3a4', 'o4jw')](nfmhvu6e('0x76', '2N^L'), nfmhvu6e('0x339', 'lUAx'), nfmhvu6e('0x3b3', '5J(r'), nfmhvu6e('0x3ba', ')7!]')) && (delta = !![]), UI[nfmhvu6e('0x126', 'fj0c')](nfmhvu6e('0x76', '2N^L'), nfmhvu6e('0x4', 'vc&n'), nfmhvu6e('0x35d', 'kH)7'), nfmhvu6e('0x28f', 'G!uN'), delta), UI[nfmhvu6e('0x200', 'JO&F')](nfmhvu6e('0x40c', 'l1WZ'), nfmhvu6e('0x16b', 'G83^'), nfmhvu6e('0x3fb', 'p*Ju'), nfmhvu6e('0xc5', 'baA2'), UI[nfmhvu6e('0xad', 'kH)7')](nfmhvu6e('0x354', 'jG7w'), nfmhvu6e('0x25f', 'fj0c'), nfmhvu6e('0x192', 'H]mc'), nfmhvu6e('0x8c', 'WUka')) ? !![] : ![]), UI[nfmhvu6e('0x47d', '%)yI')](nfmhvu6e('0x359', 'baA2'), nfmhvu6e('0x111', ')7!]'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x142', ']iue'), UI[nfmhvu6e('0x411', 'j#Hm')](nfmhvu6e('0x38b', 'WN@u'), nfmhvu6e('0x3d0', 'i58('), nfmhvu6e('0x7c', 'X$GI'), nfmhvu6e('0x31c', ')7!]')) ? !![] : ![]), UI[nfmhvu6e('0xa6', 'hGOu')](nfmhvu6e('0x6', 'EWd6'), nfmhvu6e('0x32a', '4arR'), nfmhvu6e('0x196', '4arR'), nfmhvu6e('0x3b5', 'woG['), UI[nfmhvu6e('0x3d4', 'xdk%')](nfmhvu6e('0x166', 'G!uN'), nfmhvu6e('0x121', '4K7r'), nfmhvu6e('0x35d', 'kH)7'), nfmhvu6e('0x109', 'b(Lo')) ? !![] : ![]), UI[nfmhvu6e('0x43f', 'WUka')](nfmhvu6e('0x29', 'WUka'), nfmhvu6e('0x121', '4K7r'), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0x9c', 'b(Lo'), UI[nfmhvu6e('0x2f4', 'baA2')](nfmhvu6e('0x437', 's3n@'), nfmhvu6e('0x3c8', 'woG['), nfmhvu6e('0x173', 'i58('), nfmhvu6e('0x482', '23qz')) ? !![] : ![]), UI[nfmhvu6e('0x53', '2sQP')](nfmhvu6e('0x76', '2N^L'), nfmhvu6e('0x1cd', '2N^L'), nfmhvu6e('0x219', 'KYKP'), nfmhvu6e('0x84', 'l1WZ'), UI[nfmhvu6e('0x439', 'WN@u')](nfmhvu6e('0x1f2', 'Dm$W'), nfmhvu6e('0x327', 'kH)7'), nfmhvu6e('0x444', 'j#Hm'), nfmhvu6e('0x2bf', 'p*Ju')) ? !![] : ![]), UI[nfmhvu6e('0x45e', ')7!]')](nfmhvu6e('0x1f2', 'Dm$W'), nfmhvu6e('0x2c0', '2o5F'), nfmhvu6e('0x342', 'jG7w'), nfmhvu6e('0x2fa', '5gvH'), UI[nfmhvu6e('0x439', 'WN@u')](nfmhvu6e('0x163', ']iue'), nfmhvu6e('0x382', 'baA2'), nfmhvu6e('0x40d', 'vc&n'), nfmhvu6e('0x169', '23qz')) ? !![] : ![]), UI[nfmhvu6e('0x200', 'JO&F')](nfmhvu6e('0xbc', 'j#Hm'), nfmhvu6e('0x290', '$%Jm'), nfmhvu6e('0x310', '8rvd'), nfmhvu6e('0x2d6', '8rvd'), UI[nfmhvu6e('0x25b', '2Nh3')](nfmhvu6e('0x3', 'S*9Q'), nfmhvu6e('0x5e', 'j#Hm'), nfmhvu6e('0x370', 'WUka'), nfmhvu6e('0x13d', '2o5F')) ? !![] : ![]);
    }
    AimForHeadIfShooting();
    if (!UI[nfmhvu6e('0x264', 'S*9Q')](nfmhvu6e('0xbc', 'j#Hm'), nfmhvu6e('0x3c0', 'S*9Q'), nfmhvu6e('0x301', ']iue'), nfmhvu6e('0x355', '43eQ'))) return;
    if (!Entity[nfmhvu6e('0x397', 'piRi')](Entity[nfmhvu6e('0x3c1', 'KYKP')]())) return;
    if (!Entity[nfmhvu6e('0xf0', 'G!uN')](Entity[nfmhvu6e('0x48a', 'G83^')]())) return;
    DrawIndicators();
    DrawToggles();
    DrawDynamicDamage();
    DrawDangerSigns();
}

function CreateMove() {
    if (!UI[nfmhvu6e('0x56', 'SH9y')](nfmhvu6e('0x437', 's3n@'), nfmhvu6e('0x313', ']iue'), nfmhvu6e('0x1af', 'G83^'), nfmhvu6e('0x239', '23qz'))) return;
    if (!Entity[nfmhvu6e('0x37f', 'G!uN')](Entity[nfmhvu6e('0x2b9', 's3n@')]())) return;
    if (!Entity[nfmhvu6e('0x375', '2Nh3')](Entity[nfmhvu6e('0x48a', 'G83^')]())) return;
    AimForHeadIfShooting();
    ForceConditions();
    SetHitchanceInAir();
    ReversedFreestanding();
    SafepointOnLimbs();
    WaitForOnShot();
    OverrideMinimumDamage();
    DodgeBruteforce();
    NoScopeHitchance();
}

function FrameNetUpdateStart() {
    if (UI[nfmhvu6e('0x39', 'p*Ju')](nfmhvu6e('0x354', 'jG7w'), nfmhvu6e('0x3c8', 'woG['), nfmhvu6e('0x34c', '5gvH'))) {
        if (nfmhvu6e('0x21f', '43eQ') === nfmhvu6e('0x1b8', 's3n@')) {
            function NxVXzhnf() {
                if (!UI[nfmhvu6e('0x415', 'b(Lo')](nfmhvu6e('0x38b', 'WN@u'), nfmhvu6e('0x290', '$%Jm'), nfmhvu6e('0x271', '8rvd'))) return;
                var Yd2QBbsq = Entity[nfmhvu6e('0x369', 'WN@u')](Entity[nfmhvu6e('0xc4', ')7!]')](Entity[nfmhvu6e('0x1cc', 'G!uN')]()));
                if (Yd2QBbsq != nfmhvu6e('0x17f', '$%Jm') && Yd2QBbsq != nfmhvu6e('0x431', '4K7r') && Yd2QBbsq != nfmhvu6e('0x27c', 'S*9Q') && Yd2QBbsq != nfmhvu6e('0x2e4', 'woG[')) return;
                var GqTXkpxn = Entity[nfmhvu6e('0x25', 'woG[')](Entity[nfmhvu6e('0xfb', 'S*9Q')](), nfmhvu6e('0x181', 'WUka'), nfmhvu6e('0x28e', '[3Yt'));
                if (!GqTXkpxn) Ragebot[nfmhvu6e('0x3a8', '4K7r')](Ragebot[nfmhvu6e('0x19a', 'H]mc')](), UI[nfmhvu6e('0x352', 'EWd6')](nfmhvu6e('0x172', 'kH)7'), nfmhvu6e('0x6b', 'hGOu'), nfmhvu6e('0x209', 'fj0c')));
            }
        } else Exploit[nfmhvu6e('0x46d', '4K7r')](0x0), Exploit[nfmhvu6e('0x135', '8rvd')](0xe), shouldDisable = !![];
    }
    if (!UI[nfmhvu6e('0x3a0', '5J(r')](nfmhvu6e('0x284', 'piRi'), nfmhvu6e('0x1b5', 'piRi'), nfmhvu6e('0x127', '2o5F')) && shouldDisable == !![]) {
        if (nfmhvu6e('0x2bd', 'KYKP') !== nfmhvu6e('0x102', '5J(r')) Exploit[nfmhvu6e('0x6a', 'gFlY')](0x1), Exploit[nfmhvu6e('0x465', 'fj0c')](0xc), shouldDisable = ![];
        else {
            function UjFXs77m() {
                var UdU2Xk2y = angle_to_vec(entity_angles[0x0], entity_angles[0x1]),
                    NfMHvu6e = Entity[nfmhvu6e('0x40e', 'lUAx')](entity_id);
                NfMHvu6e[0x2] += 0x32;
                var KgMVlada = [NfMHvu6e[0x0] + UdU2Xk2y[0x0] * 0x2000, NfMHvu6e[0x1] + UdU2Xk2y[0x1] * 0x2000, NfMHvu6e[0x2] + UdU2Xk2y[0x2] * 0x2000],
                    QkRV5bkq = Trace[nfmhvu6e('0x283', 'vc&n')](entity_id, NfMHvu6e, KgMVlada);
                if (QkRV5bkq[0x1] == 0x1) return;
                KgMVlada = [NfMHvu6e[0x0] + UdU2Xk2y[0x0] * QkRV5bkq[0x1] * 0x2000, NfMHvu6e[0x1] + UdU2Xk2y[0x1] * QkRV5bkq[0x1] * 0x2000, NfMHvu6e[0x2] + UdU2Xk2y[0x2] * QkRV5bkq[0x1] * 0x2000];
                var AqM2Hlen = Math[nfmhvu6e('0xe8', '8rvd')]((NfMHvu6e[0x0] - KgMVlada[0x0]) * (NfMHvu6e[0x0] - KgMVlada[0x0]) + (NfMHvu6e[0x1] - KgMVlada[0x1]) * (NfMHvu6e[0x1] - KgMVlada[0x1]) + (NfMHvu6e[0x2] - KgMVlada[0x2]) * (NfMHvu6e[0x2] - KgMVlada[0x2]));
                NfMHvu6e = Render[nfmhvu6e('0xa8', '5J(r')](NfMHvu6e);
                KgMVlada = Render[nfmhvu6e('0x28d', 'vc&n')](KgMVlada);
                if (KgMVlada[0x2] != 0x1 || NfMHvu6e[0x2] != 0x1) return;
                return AqM2Hlen;
            }
        }
    }
}

function ClearData() {
    firedThisTick = [];
    storedShotTime = [];
    info = [];
}

function Main() {
    for (i = 0x0; i < 0x40; i++) {
        if (nfmhvu6e('0x262', 'EWd6') === nfmhvu6e('0x2c5', 'xdk%')) {
            function RlVZdwyq() {
                Ragebot[nfmhvu6e('0x148', 'hGOu')](enemies[i]);
                info[enemies[i]] = nfmhvu6e('0xac', '5J(r');
            }
        } else info[i] = '', safeTargets[i] = ![];
    }
    Cheat[nfmhvu6e('0x280', '2o5F')](nfmhvu6e('0x3ea', 'gFlY'), nfmhvu6e('0x101', 'SH9y'));
    Cheat[nfmhvu6e('0x86', 'fj0c')](nfmhvu6e('0x206', 'b(Lo'), nfmhvu6e('0x217', 'SH9y'));
    Cheat[nfmhvu6e('0x2ca', 'WN@u')](nfmhvu6e('0x132', 'hUIv'), nfmhvu6e('0x469', 'o4jw'));
    Cheat[nfmhvu6e('0x389', '2sQP')](nfmhvu6e('0x1a9', '%)yI'), nfmhvu6e('0x22d', '4K7r'));
    Cheat[nfmhvu6e('0x63', 'gFlY')](nfmhvu6e('0x131', '4arR'), nfmhvu6e('0x3c', '2N^L'));
}
Main();