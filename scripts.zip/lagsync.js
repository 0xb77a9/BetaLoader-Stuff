var side = 0;
var type,fakeamount,masteryaw,fake = 0;
function ui()
{
    UI.AddCheckbox( "Override AA" );
    UI.AddDropdown( "Lagsync mode:", [ "Off","CT Weapon", "Lagsync V1", "Lagsync V2", "Lagsync V3" ] );
} 

function yawhandles(type,fakeamount,masteryaw,fake)
{
    var localplayer_index = Entity.GetLocalPlayer( );
    var velocity = Entity.GetProp( localplayer_index, "CBasePlayer", "m_vecVelocity[0]" );
    var currentspeed = Math.round(Math.sqrt(Math.pow(velocity[0],2)+ Math.pow(velocity[1],2)));

       if(currentspeed <= 0 && type == 1 )//standing
        {
            
            AntiAim.SetLBYOffset(fakeamount);
            AntiAim.SetRealOffset(fake);
            AntiAim.SetFakeOffset(masteryaw);
        }
    else if(currentspeed > 0 && type == 2 )
        {
            Cheat.Print(currentspeed + "\n");
            AntiAim.SetLBYOffset(fakeamount);
            AntiAim.SetRealOffset(fake);
            AntiAim.SetFakeOffset(masteryaw);
        }
    
    
}

function getRndInteger(min, max) {
  return Math.ceil(Math.random() * (max - min) ) + min;
}

function Initialize()
{ 
    
    var lagsyncmode = UI.GetString("MISC", "JAVASCRIPT", "Script items", "Lagsync mode:");
    
    if(UI.GetValue( "MISC", "JAVASCRIPT", "Script items", "Override AA" ))
        {
            AntiAim.SetOverride(1);
            
            //side = 0.55 * Math.sin((Globals.Realtime()-(-1.9))/0.1) + 0.5;
            side = getRndInteger(0,4);
            Cheat.Print(side + "\n");
            if(lagsyncmode == "CT Weapon")
                {
                    if(side  == 4)
                        {
                            Cheat.Print("side" + "\n");
                            type = 2;
                            masteryaw = 25;
                            fakeamount = -70;
                            fake = 70;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 1;
                            masteryaw = -2;
                            fakeamount = -70;
                            fake = 70;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                        }
                        else if (side  == 1)
                        {
                            Cheat.Print("!side" + "\n");
                            type = 1;
                            masteryaw = -17;
                            fakeamount = -75;
                            fake = 75;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 2;
                            masteryaw = -15;
                            fakeamount = -65;
                            fake = 65;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                    
                        }
                }
            if(lagsyncmode == "Lagsync V1")
                {
                    if(side  == 4)
                        {
                            Cheat.Print("side" + "\n");
                            type = 2;
                            masteryaw = 25;
                            fakeamount = -70;
                            fake = 70;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 1;
                            masteryaw = -30;
                            fakeamount = -70;
                            fake = 70;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                        }
                        else if (side  == 1)
                        {
                            Cheat.Print("!side" + "\n");
                            type = 2;
                            masteryaw = -25;
                            fakeamount = -65;
                            fake = 65;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 1;
                            masteryaw = -25;
                            fakeamount = -65;
                            fake = 65;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                    
                        }
                    
                }
            if(lagsyncmode == "Lagsync V2")
                {
                    if(side  == 4)
                        {
                            Cheat.Print("side" + "\n");
                            type = 2;
                            masteryaw = 25;
                            fakeamount = 100;
                            fake = -100;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 1;
                            masteryaw = 25;
                            fakeamount = 100;
                            fake = -100;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                        }
                        else if (side  == 1)
                        {
                            Cheat.Print("!side" + "\n");
                            type = 1;
                            masteryaw = -15;
                            fakeamount = 100;
                            fake = -100;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 2;
                            masteryaw = -15;
                            fakeamount = 100;
                            fake = -100;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                    
                        }
                    
                }
            if(lagsyncmode == "Lagsync V3")
                {
                    if(side  == 4)
                        {
                            Cheat.Print("side" + "\n");
                            type = 2;
                            masteryaw = 25;
                            fakeamount = -70;
                            fake = 70;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 1;
                            masteryaw = 25;
                            fakeamount = -70;
                            fake = 70;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                        }
                        else if (side  == 1)
                        {
                            Cheat.Print("!side" + "\n");
                            type = 1;
                            masteryaw = -15;
                            fakeamount = -65;
                            fake = 65;
                            
                            yawhandles(type,fakeamount,masteryaw,fake);
                            
                            type = 2;
                            masteryaw = -15;
                            fakeamount = -65;
                            fake = 65;
                            
                           yawhandles(type,fakeamount,masteryaw,fake);
                            
                    
                        }
                    
                }
            
            
        }
    else
        AntiAim.SetOverride(0);
    
}


function Renders()
{
    
}

ui();
Cheat.RegisterCallback("CreateMove", "Initialize");