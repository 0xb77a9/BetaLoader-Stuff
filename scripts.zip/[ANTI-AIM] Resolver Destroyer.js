
/***************************************************************************/
/*    Resolver Break                                                                    */
/*  This is the public version and may not match results of the alpha.*/
/*  For onetap v3              */
/*  Created by Ominous#7262                                         */
/*  Join our discord for updates.                                              */
/*   Website = Ominousware.com                                                                            */
/* If you purchased this you got scammed!!!!!!! this is a free and public script!!!!    */      
/***************************************************************************/

var _$_c024=["\x4D\x69\x73\x63","\x4A\x41\x56\x41\x53\x43\x52\x49\x50\x54","\x53\x63\x72\x69\x70\x74\x20\x69\x74\x65\x6D\x73","\x42\x61\x73\x65\x20\x79\x61\x77\x3A","\x47\x65\x74\x56\x61\x6C\x75\x65","\x75\x73\x65\x72\x69\x64","\x47\x65\x74\x49\x6E\x74","\x47\x65\x74\x45\x6E\x74\x69\x74\x79\x46\x72\x6F\x6D\x55\x73\x65\x72\x49\x44","\x47\x65\x74\x4C\x6F\x63\x61\x6C\x50\x6C\x61\x79\x65\x72","\x4A\x41\x56\x53\x43\x52\x49\x50\x54","\x43\x68\x61\x74\x20\x69\x6E\x66\x6F\x3A","\x59\x61\x77\x20\x66\x6C\x69\x70\x3A","\x52\x65\x73\x6F\x6C\x76\x65\x72\x20\x42\x72\x65\x61\x6B","\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x52\x61\x67\x65\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x59\x61\x77\x20\x6F\x66\x66\x73\x65\x74","\x53\x65\x74\x56\x61\x6C\x75\x65","\x61\x74\x74\x61\x63\x6B\x65\x72","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x52\x65\x73\x6F\x6C\x76\x65\x72\x20\x42\x72\x65\x61\x6B\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x4C\x61\x62\x65\x6C","\x20\x20\x20\x20\x20\x20\x20\x43\x72\x65\x61\x74\x65\x64\x20\x62\x79\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x23\x37\x32\x36\x32\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x43\x68\x65\x63\x6B\x62\x6F\x78","\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x53\x69\x74\x65\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x57\x61\x72\x65\x2E\x63\x6F\x6D\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x44\x69\x73\x63\x6F\x72\x64\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x20\x20\x20\x20\x20\x20\x20\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x67\x67\x2F\x55\x32\x46\x6D\x4B\x4A\x4E","\x66\x6C\x6F\x6F\x72","\x72\x6F\x75\x6E\x64","\x4D\x49\x53\x43","\x49\x73\x4D\x65\x6E\x75\x4F\x70\x65\x6E","\x52\x65\x61\x6C\x74\x69\x6D\x65","\x53\x63\x72\x69\x70\x74\x20\x49\x74\x65\x6D\x73","\x47\x72\x61\x64\x69\x65\x6E\x74\x20\x53\x70\x65\x65\x64","\x4C\x61\x74\x65\x6E\x63\x79","\x46\x72\x61\x6D\x65\x74\x69\x6D\x65","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x78","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x79","\x67\x65\x74\x48\x6F\x75\x72\x73","\x67\x65\x74\x4D\x69\x6E\x75\x74\x65\x73","\x67\x65\x74\x53\x65\x63\x6F\x6E\x64\x73","\x30","\x3A","\x54\x69\x63\x6B\x72\x61\x74\x65","\x56\x65\x72\x64\x61\x6E\x61","\x41\x64\x64\x46\x6F\x6E\x74","\x53\x69\x74\x65","\x53\x74\x72\x69\x6E\x67\x43\x75\x73\x74\x6F\x6D","\x4F\x6D\x69\x6E\x6F\x75\x73\x57\x61\x72\x65\x2E\x63\x6F\x6D","\x43\x72\x65\x61\x74\x65\x64\x20\x62\x79\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x23\x37\x32\x36\x32","\x47\x65\x74\x53\x63\x72\x65\x65\x6E\x53\x69\x7A\x65","\x70\x6C\x61\x79\x65\x72\x5F\x64\x65\x61\x74\x68","\x70\x6C\x61\x79\x65\x72\x44\x65\x61\x74\x68\x46\x75\x6E\x63","\x77\x61\x74\x65\x72\x6D\x61\x72\x6B","\x52\x65\x67\x69\x73\x74\x65\x72\x43\x61\x6C\x6C\x62\x61\x63\x6B","\x44\x72\x61\x77","\x77\x65\x61\x70\x6F\x6E\x5F\x66\x69\x72\x65","\x77\x65\x61\x70\x6F\x6E\x46\x69\x72\x65","\x63\x65\x69\x6C","\x72\x61\x6E\x64\x6F\x6D"];
currShot= 0;currentYaw= 0;function weaponFire()
{
	ogYawOffset= UI[_$_c024[4]](_$_c024[0],_$_c024[1],_$_c024[2],_$_c024[3]);UID= Event[_$_c024[6]](_$_c024[5]);entityID= Entity[_$_c024[7]](UID);localEntityID= Entity[_$_c024[8]]();if(entityID== localEntityID)
	{
		desiredYaw= 0;if(currShot== 1)
		{
			desiredYaw= ogYawOffset;currShot= 0;if(UI[_$_c024[4]](_$_c024[0],_$_c024[9],_$_c024[2],_$_c024[10]))
			{
				
			}
			
		}
		else 
		{
			desiredYaw= UI[_$_c024[4]](_$_c024[0],_$_c024[9],_$_c024[2],_$_c024[11]);if(UI[_$_c024[4]](_$_c024[0],_$_c024[1],_$_c024[2],_$_c024[12]))
			{
				desiredYaw= getRandomInt(180,180)
			}
			//26
			currShot++
		}
		//15
		UI[_$_c024[16]](_$_c024[13],_$_c024[14],_$_c024[15],desiredYaw)
	}
	
}
function playerDeathFunc()
{
	attackerUID= Event[_$_c024[6]](_$_c024[17]);victimUID= Event[_$_c024[6]](_$_c024[5]);attackerEntity= Entity[_$_c024[7]](attackerUID);victimEntity= Entity[_$_c024[7]](victimUID);localEntity= Entity[_$_c024[8]]();if(UI[_$_c024[4]](_$_c024[0],_$_c024[1],_$_c024[2],_$_c024[12])&& attackerEntity== localEntity)
	{
		resetYaw()
	}
	//47
	if(UI[_$_c024[4]](_$_c024[0],_$_c024[1],_$_c024[2],_$_c024[12])&& victimEntity== localEntity)
	{
		resetYaw()
	}
	
}
function resetYaw()
{
	if(UI[_$_c024[4]](_$_c024[0],_$_c024[1],_$_c024[2],_$_c024[10]))
	{
		
	}
	//58
	currShot= 0;UI[_$_c024[16]](_$_c024[13],_$_c024[14],_$_c024[15],ogYawOffset)
}
ogYawOffset= 0;function drawUI()
{
	UI[_$_c024[19]](_$_c024[18]);UI[_$_c024[19]](_$_c024[20]);UI[_$_c024[19]](_$_c024[21]);UI[_$_c024[22]](_$_c024[12]);UI[_$_c024[19]](_$_c024[23]);UI[_$_c024[19]](_$_c024[23]);UI[_$_c024[19]](_$_c024[23]);UI[_$_c024[19]](_$_c024[24]);UI[_$_c024[19]](_$_c024[25]);UI[_$_c024[19]](_$_c024[21]);UI[_$_c024[19]](_$_c024[26]);UI[_$_c024[19]](_$_c024[27]);UI[_$_c024[19]](_$_c024[21])
}
function HSVtoRGB(h,m,o)
{
	var l,g,e,i,f,j,k,n;//88
	i= Math[_$_c024[28]](h* 6);f= h* 6- i;j= o* (1- m);k= o* (1- f* m);n= o* (1- (1- f)* m);switch(i% 6)
	{
		case 0:l= 255,g= 0,e= 0;break//98
		case 1:l= 255,g= 0,e= 0;break//99
		case 2:l= 255,g= 0,e= 0;break//100
		case 3:l= 255,g= 0,e= 0;break//101
		case 4:l= 255,g= 0,e= 0;break//102
		case 5:l= 255,g= 0,e= 0;break
	}
	//96
	return {r:Math[_$_c024[29]](l* 255),g:Math[_$_c024[29]](g* 255),b:Math[_$_c024[29]](e* 255)}
}
function getCustomValue(b)
{
	var a=UI[_$_c024[4]](_$_c024[30],_$_c024[1],_$_c024[2],b);//109
	return a
}
var position={x1:0,y1:0};//111
function watermark()
{
	if(UI[_$_c024[31]]())
	{
		var w=HSVtoRGB(Global[_$_c024[32]]()* UI[_$_c024[4]](_$_c024[30],_$_c024[1],_$_c024[33],_$_c024[34]),1,1);//122
		const C=Math[_$_c024[28]](Global[_$_c024[35]]()* 1000/ 1.5);//124
		const x=Math[_$_c024[28]](1/ Global[_$_c024[36]]());//125
		x1= getCustomValue(_$_c024[37]);y1= getCustomValue(_$_c024[38]);var G= new Date();//130
		var z=G[_$_c024[39]]();//131
		var B=G[_$_c024[40]]();//132
		var E=G[_$_c024[41]]();//133
		var y=z<= 9?_$_c024[42]+ G[_$_c024[39]]()+ _$_c024[43]:G[_$_c024[39]]()+ _$_c024[43];//134
		var A=B<= 9?_$_c024[42]+ G[_$_c024[40]]()+ _$_c024[43]:G[_$_c024[40]]()+ _$_c024[43];//135
		var D=E<= 9?_$_c024[42]+ G[_$_c024[41]]():G[_$_c024[41]]();//136
		var F=Global[_$_c024[44]]();//143
		font= Render[_$_c024[46]](_$_c024[45],28,800);font2= Render[_$_c024[46]](_$_c024[45],25,600);font3= Render[_$_c024[46]](_$_c024[45],20,500);font4= Render[_$_c024[46]](_$_c024[45],8,600);font5= Render[_$_c024[46]](_$_c024[45],6,600);Render[_$_c024[48]](x1+ 126,y1+ 745,0,_$_c024[47],[5,5,5,255],font2);Render[_$_c024[48]](x1+ 125,y1+ 744,0,_$_c024[47],[255,255,255,255],font2);Render[_$_c024[48]](x1+ 126,y1+ 781,0,_$_c024[49],[5,5,5,255],font2);Render[_$_c024[48]](x1+ 125,y1+ 780,0,_$_c024[49],[15,72,255,255],font2);Render[_$_c024[48]](x1+ 126,y1+ 501,0,_$_c024[50],[5,5,5,255],font3);Render[_$_c024[48]](x1+ 125,y1+ 500,0,_$_c024[50],[255,255,255,255],font3);Render[_$_c024[48]](x1+ 126,y1+ 301,0,_$_c024[12],[5,5,5,255],font3);Render[_$_c024[48]](x1+ 125,y1+ 300,0,_$_c024[12],[255,255,255,255],font3)
	}
	
}
function main()
{
	var u=Global[_$_c024[51]]()
}
function main()
{
	ogYawOffset= UI[_$_c024[4]](_$_c024[13],_$_c024[14],_$_c024[15]);drawUI();Cheat[_$_c024[55]](_$_c024[52],_$_c024[53],_$_c024[54]);Global[_$_c024[55]](_$_c024[56],_$_c024[54],_$_c024[45]);Cheat[_$_c024[55]](_$_c024[57],_$_c024[58])
}
function getRandomInt(d,c)
{
	d= Math[_$_c024[59]](d);c= Math[_$_c024[28]](c);return Math[_$_c024[28]](Math[_$_c024[60]]()* ((c+ 1)- d))+ d
}
main()